// Oyun kuralı birim testleri (ağ yok, sahte zaman): node test/rules.js
const assert = require('assert');
const G = require('../shared/game-core');

let t = Date.UTC(2026, 9, 31, 9, 0, 0); // 31 Eki 2026 12:00 TR
const q = [];
const setTimer = (fn, ms) => { const h = { at: t + ms, fn }; q.push(h); return h; };
const clearTimer = (h) => { const i = q.indexOf(h); if (i >= 0) q.splice(i, 1); };
function make(config = {}, wallet = new G.MemoryWallet(1e9), rng) {
  q.length = 0;
  const e = new G.RoundEngine({ wallet, config, now: () => t, setTimer, clearTimer, rng });
  e.start();
  return e;
}
async function step() { q.sort((a, b) => a.at - b.at); const h = q.shift(); t = h.at; await h.fn(); await new Promise(setImmediate); }
async function untilPhase(e, phase) { let n = 0; while (e.phase !== phase) { await step(); if (++n > 20) throw new Error('faz gelmedi: ' + phase); } }
const user = { id: 'u1', name: 'Test' };
let passed = 0;
async function test(name, fn) { await fn(); passed++; console.log('ok  ', name); }

(async () => {
  await test('Kol sınırı: aynı turda en fazla 7 farklı yiyeceğe bahis, 8.si reddedilir', async () => {
    const e = make();
    await untilPhase(e, 'betting');
    const ids = e.config.items.map((i) => i.id);
    for (let k = 0; k < 7; k++) assert.ok((await e.placeBet(user, ids[k], 200)).ok, 'kol ' + (k + 1));
    assert.deepStrictEqual(e.armsState('u1'), { max: 7, used: 7, left: 0 });
    const r8 = await e.placeBet(user, ids[7], 200);
    assert.deepStrictEqual([r8.ok, r8.error], [false, 'ARM_LIMIT']);
    assert.strictEqual(await e.wallet.balance('u1'), 1e9 - 7 * 200, 'reddedilen bahis bakiyeden düşmemeli');
    assert.ok((await e.placeBet(user, ids[0], 500)).ok, 'bahis koyduğu koldan artırabilir');
    assert.ok((await e.placeBet({ id: 'u2', name: 'Başka' }, ids[7], 200)).ok, 'başka oyuncu etkilenmez');
  });

  await test('Kol sınırı yeni turda sıfırlanır', async () => {
    const e = make();
    await untilPhase(e, 'betting');
    const ids = e.config.items.map((i) => i.id);
    for (let k = 0; k < 7; k++) await e.placeBet(user, ids[k], 200);
    await untilPhase(e, 'result'); await untilPhase(e, 'betting');
    assert.strictEqual(e.armsState('u1').used, 0);
    assert.ok((await e.placeBet(user, ids[7], 200)).ok);
  });

  await test('Eşzamanlı bahislerde sınır aşılmaz, kayıt kaybolmaz, fazla bahis iade edilir', async () => {
    const e = make({ maxItemsPerRound: 3 });
    await untilPhase(e, 'betting');
    const ids = e.config.items.map((i) => i.id);
    const res = await Promise.all(ids.slice(0, 6).map((id) => e.placeBet(user, id, 1000)));
    const ok = res.filter((r) => r.ok), bad = res.filter((r) => !r.ok);
    assert.strictEqual(ok.length, 3); assert.ok(bad.every((r) => r.error === 'ARM_LIMIT'));
    assert.strictEqual(Object.keys(e.bets.get('u1')).length, 3, 'kabul edilen 3 bahis da kayıtlı');
    assert.strictEqual(await e.wallet.balance('u1'), 1e9 - 3000, 'reddedilenler iade edilmiş');
  });

  await test('Sınır panelden değişir (1–8), 8 = sınırsız', async () => {
    const e = make();
    await untilPhase(e, 'betting');
    const ids = e.config.items.map((i) => i.id);
    e.updateConfig({ maxItemsPerRound: 2 });
    await e.placeBet(user, ids[0], 200); await e.placeBet(user, ids[1], 200);
    assert.strictEqual((await e.placeBet(user, ids[2], 200)).error, 'ARM_LIMIT');
    e.updateConfig({ maxItemsPerRound: 8 });
    for (const id of ids) assert.ok((await e.placeBet(user, id, 200)).ok);
    assert.throws(() => e.updateConfig({ maxItemsPerRound: 0 }));
    assert.throws(() => e.updateConfig({ maxItemsPerRound: 9 }));
  });

  await test('Bakım modunda bahis alınmaz', async () => {
    const e = make();
    e.updateConfig({ bettingEnabled: false });
    assert.strictEqual((await e.placeBet(user, 'corn', 200)).error, 'GAME_PAUSED');
  });

  await test('Panel ayarı doğrulanır, varsayılan yapılandırma kirlenmez', async () => {
    const e = make();
    assert.throws(() => e.updateConfig({ winControl: { houseShare: 1.5 } }));
    e.updateConfig({ winControl: { houseShare: 0.5 }, maxItemsPerRound: 3 });
    assert.strictEqual(G.DEFAULT_CONFIG.winControl.houseShare, 0.8);
    assert.strictEqual(G.DEFAULT_CONFIG.maxItemsPerRound, 7);
  });

  await test('Kasa payı: bütçeyi aşan sonuç seçilmez, bütçe yetmezse en az ödeyen seçilir', async () => {
    // Tek oyuncu mısıra 1000 basıyor: mısır çıkarsa 5000 ödenir. Bütçe = 0.2 × 1000 = 200 → mısır seçilemez.
    for (let k = 0; k < 200; k++) {
      const e = make({ winControl: { houseShare: 0.8 } });
      await e.placeBet(user, 'corn', 1000);
      await untilPhase(e, 'drawing');
      assert.notStrictEqual(e.outcome, 'corn');
      assert.notStrictEqual(e.outcome, 'salad'); // mısır bir sebze → salata da mısırı öder
    }
    // Her kaleme bahis: hiçbiri bütçeye sığmaz → en az ödeyen (x5 kalemlerden biri) seçilir
    const e = make({ winControl: { houseShare: 0.8 } });
    for (const it of e.config.items) await e.placeBet(user, it.id, 1000);
    await untilPhase(e, 'drawing');
    assert.ok(['tomato', 'pepper', 'carrot', 'corn'].includes(e.outcome), e.outcome);
  });

  await test('Birikmiş bütçe büyük ödemeye izin verir', async () => {
    const e = make({ winControl: { houseShare: 0.8 } }, undefined, () => 0.0000001); // rng: en küçük ağırlık dilimi → ilk aday
    e.ctl.bet = 1e6; e.ctl.pay = 0; // kasa zaten 1M topladı; oyuncular için 200K bütçe var
    await e.placeBet(user, 'chicken', 1000); // x45 = 45K ≤ bütçe
    await untilPhase(e, 'drawing');
    assert.strictEqual(e.outcome, 'chicken');
    assert.ok(e.lastDecision.budget >= 45000);
  });

  await test('Geç biten debit, sonuç seçilmeden önce işlenir ve kontrole dahil edilir', async () => {
    let release;
    const slow = new G.MemoryWallet(1e9);
    const origDebit = slow.debit.bind(slow);
    slow.debit = (...a) => new Promise((res) => { release = () => res(origDebit(...a)); });
    const e = make({ winControl: { houseShare: 0.8 } }, slow);
    const pBet = e.placeBet(user, 'corn', 1000); // debit askıda
    // bahis süresi bitiyor
    q.sort((a, b) => a.at - b.at); const h = q.shift(); t = h.at; const nextP = h.fn();
    await new Promise(setImmediate);
    assert.strictEqual(e.phase, 'betting', 'bekleyen debit varken çekilişe geçilmemeli');
    release(); await nextP; await pBet;
    assert.strictEqual(e.phase, 'drawing');
    assert.strictEqual(e.totals.corn, 1000, 'bahis kontrole dahil');
    assert.notStrictEqual(e.outcome, 'corn');
  });

  await test('Ödenemeyen kazanç kuyruğa alınır ve yeniden denenince ödenir', async () => {
    const w = new G.MemoryWallet(1e9);
    const origCredit = w.credit.bind(w);
    let fail = true;
    w.credit = async (...a) => { if (fail && String(a[2]).endsWith(':win')) throw new Error('ağ'); return origCredit(...a); };
    const e = make({ winControl: { enabled: false } }, w, () => 0.0000001); // kontrol kapalı → ilk aday (tavuk) çıkar
    await e.placeBet(user, 'chicken', 1000);
    await untilPhase(e, 'result');
    assert.strictEqual(e.unpaid.size, 1);
    const before = await w.balance('u1');
    fail = false;
    const r = await e.retryUnpaid();
    assert.deepStrictEqual(r, { paid: 1, left: 0 });
    assert.strictEqual((await w.balance('u1')) - before, 45000);
  });

  await test('Durum dışa/içe aktarma: kasa sayaçları ve tur kaydı korunur', async () => {
    const e = make();
    await e.placeBet(user, 'corn', 200);
    await untilPhase(e, 'result');
    const snap = JSON.parse(JSON.stringify(e.exportState()));
    const e2 = make();
    e2.importState(snap);
    assert.strictEqual(e2.ctl.bet, 200);
    assert.strictEqual(e2.roundLog.length, 1);
  });

  console.log(`\n${passed} test geçti`);
})().catch((e) => { console.error('BAŞARISIZ:', e); process.exit(1); });
