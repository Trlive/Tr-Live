// Sahte Tr-Live cüzdanı + JWT ile üretim yolunu uçtan uca dener.
const http = require('http'), crypto = require('crypto'), { spawn } = require('child_process');
const WebSocket = require('../server/node_modules/ws');
const SECRET = 'jwt-test', WSEC = 'wallet-test';
const bal = new Map(), seen = new Map(); const calls = [];
http.createServer((req, res) => {
  let body = ''; req.on('data', (c) => (body += c)); req.on('end', () => {
    const sig = crypto.createHmac('sha256', WSEC).update(body).digest('hex');
    if (sig !== req.headers['x-signature']) { res.writeHead(401); return res.end('{}'); }
    const b = JSON.parse(body); calls.push(req.url + ' ' + (b.txId || '') + ' ' + (b.amount || ''));
    const cur = bal.has(b.userId) ? bal.get(b.userId) : 5000;
    let out;
    if (b.txId && seen.has(b.txId)) out = seen.get(b.txId);
    else if (req.url === '/balance') out = { ok: true, balance: cur };
    else if (req.url === '/debit') out = cur < b.amount ? { ok: false, error: 'INSUFFICIENT_FUNDS', balance: cur } : { ok: true, balance: cur - b.amount };
    else out = { ok: true, balance: cur + b.amount };
    if (out.ok && b.txId) bal.set(b.userId, out.balance);
    if (b.txId) seen.set(b.txId, out);
    res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify(out));
  });
}).listen(9099);
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const h = b64({ alg: 'HS256', typ: 'JWT' }), p = b64({ sub: 'u42', name: 'Test', exp: Math.floor(Date.now() / 1000) + 600 });
const jwt = h + '.' + p + '.' + crypto.createHmac('sha256', SECRET).update(h + '.' + p).digest('base64url');
const srv = spawn('node', ['server/index.js'], { env: { ...process.env, PORT: '8091', TRLIVE_JWT_SECRET: SECRET, TRLIVE_WALLET_URL: 'http://127.0.0.1:9099', TRLIVE_WALLET_SECRET: WSEC, NO_PROXY: '127.0.0.1,localhost' }, stdio: 'inherit' });
setTimeout(() => {
  const bad = new WebSocket('ws://127.0.0.1:8091/ws?token=dev:1:x');
  bad.on('close', (c) => console.log('dev token in prod mode -> close code', c));
  const ws = new WebSocket('ws://127.0.0.1:8091/ws?token=' + jwt);
  let n = 0; const send = (m) => ws.send(JSON.stringify({ reqId: ++n, ...m }));
  ws.on('message', (raw) => {
    const m = JSON.parse(raw);
    if (m.type === 'hello') { console.log('hello balance', m.balance, 'phase', m.state.phase); send({ type: 'bet', item: 'corn', amount: 1000, round: m.state.round }); send({ type: 'bet', item: 'corn', amount: 100000, round: m.state.round }); send({ type: 'bet', item: 'corn', amount: 123 }); }
    if (m.type === 'ack') console.log('ack', m.op, m.ok, m.error || '', m.balance ?? '');
  });
  setTimeout(() => { console.log('wallet calls:', calls); srv.kill(); process.exit(0); }, 2500);
}, 800);
