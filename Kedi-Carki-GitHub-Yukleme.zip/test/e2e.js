// Gerçek sunucuyu hızlı fazlarla başlatır; WebSocket oyuncusu + yönetim API'sini uçtan uca dener.
//   cd server && npm install && cd .. && node test/e2e.js
const assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path'), { spawn } = require('child_process');
const WebSocket = require('../server/node_modules/ws');
const PORT = 8093, KEY = 'test-admin-key';
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kc-e2e-'));
const cfgFile = path.join(dir, 'cfg.json');
fs.writeFileSync(cfgFile, JSON.stringify({ phases: { betting: 1200, drawing: 200, result: 200 }, betCloseGuardMs: 50 }));
const env = { ...process.env, PORT: String(PORT), DEV_AUTH: '1', ADMIN_KEY: KEY, GAME_CONFIG: cfgFile, DATA_DIR: path.join(dir, 'data'), NO_PROXY: '127.0.0.1,localhost' };
const start = () => spawn('node', ['server/index.js'], { env, stdio: ['ignore', 'ignore', 'inherit'] });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const adm = async (p, body, key = KEY) => {
  const r = await fetch(`http://127.0.0.1:${PORT}/admin/api/${p}`, { method: body === undefined ? 'GET' : 'POST', headers: { 'x-admin-key': key, 'content-type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: r.status, json: await r.json() };
};
function player(id) {
  const ws = new WebSocket(`ws://127.0.0.1:${PORT}/ws?token=dev:${id}:Oyuncu${id}`);
  let n = 0; const waiters = new Map(); let phase = null;
  ws.on('message', (raw) => {
    const m = JSON.parse(raw);
    if (m.type === 'ack' && waiters.has(m.reqId)) { waiters.get(m.reqId)(m); waiters.delete(m.reqId); }
    if (m.type === 'hello' || m.type === 'phase') phase = m;
  });
  return {
    ws, req: (msg) => new Promise((res) => { const reqId = ++n; waiters.set(reqId, res); ws.send(JSON.stringify({ reqId, ...msg })); }),
    ready: () => new Promise((r) => ws.once('open', r)),
    async untilBetting() { for (let i = 0; i < 100; i++) { await sleep(60); if (phase && (phase.phase === 'betting' || (phase.state && phase.state.phase === 'betting')) && (phase.endsAt || phase.state.endsAt) - Date.now() > 500) return; } throw new Error('betting gelmedi'); },
    // 'hello' içindeki state ve 'phase' farklı şekilde: yeni tura geçişi bekle
    async nextBetting() { const cur = (phase.round != null ? phase.round : phase.state.round); for (let i = 0; i < 100; i++) { await sleep(60); if (phase.type === 'phase' && phase.phase === 'betting' && phase.round !== cur) return; } throw new Error('yeni tur gelmedi'); },
  };
}

(async () => {
  let srv = start();
  try {
    await sleep(900);
    // --- yetkilendirme
    assert.strictEqual((await adm('overview', undefined, 'yanlis')).status, 401);
    assert.strictEqual((await fetch(`http://127.0.0.1:${PORT}/admin/api/overview`)).status, 401);
    const page = await fetch(`http://127.0.0.1:${PORT}/admin`);
    assert.strictEqual(page.status, 200); assert.ok((await page.text()).includes('Yönetim Paneli'));
    console.log('ok   panel sayfası açılıyor, anahtarsız/yanlış anahtar 401');

    // --- ayar doğrulama + kalıcılık
    assert.strictEqual((await adm('settings', { winControl: { houseShare: 2 } })).status, 400);
    let s = await adm('settings', { winControl: { houseShare: 0.7 }, maxItemsPerRound: 3 });
    assert.strictEqual(s.json.settings.winControl.houseShare, 0.7);
    assert.strictEqual(s.json.settings.maxItemsPerRound, 3);
    console.log('ok   ayar güncelleme + doğrulama');

    // --- panelden verilen 3 kol sınırı WebSocket üzerinden
    const p = player('7001'); await p.ready(); await p.untilBetting();
    for (const [i, item] of ['corn', 'fish', 'goat'].entries()) {
      const a = await p.req({ type: 'bet', item, amount: 200 });
      assert.ok(a.ok, `${item}: ${a.error}`); assert.strictEqual(a.me.arms.used, i + 1);
    }
    const more = await p.req({ type: 'bet', item: 'corn', amount: 200 });
    assert.ok(more.ok, 'aynı koldan artırma serbest');
    const denied = await p.req({ type: 'bet', item: 'chicken', amount: 200 });
    assert.strictEqual(denied.error, 'ARM_LIMIT'); assert.strictEqual(denied.me.arms.left, 0);
    console.log('ok   3 kol sonra ARM_LIMIT, istemciye kol bilgisi gidiyor');
    await p.nextBetting();
    assert.ok((await p.req({ type: 'bet', item: 'chicken', amount: 200 })).ok, 'yeni turda sınır sıfırlanır');
    console.log('ok   yeni turda kol sınırı sıfırlanıyor');

    // --- oyuncu listesi
    const pl = (await adm('players')).json.players.find((x) => x.id === '7001');
    assert.ok(pl && pl.online && pl.arms.max === 3);
    console.log('ok   oyuncu listesi');

    // --- bakım modu
    await adm('settings', { bettingEnabled: false });
    await p.nextBetting();
    assert.strictEqual((await p.req({ type: 'bet', item: 'corn', amount: 200 })).error, 'GAME_PAUSED');
    await adm('settings', { bettingEnabled: true });
    console.log('ok   bakım modu');

    // --- istemci hello'da gizli ayar sızmıyor
    const hello = await new Promise((res) => { const w = new WebSocket(`ws://127.0.0.1:${PORT}/ws?token=dev:7002:X`); w.on('message', (r) => { const m = JSON.parse(r); if (m.type === 'hello') { w.close(); res(m); } }); });
    assert.ok(!JSON.stringify(hello).includes('houseShare'), 'kasa payı istemciye sızmamalı');
    console.log('ok   kasa payı ayarı istemciye gönderilmiyor');

    // --- yeniden başlatma: ayarlar ve kol sayacı korunuyor
    await sleep(5500); // otomatik kayıt 5 sn'de bir
    p.ws.close(); srv.kill('SIGTERM'); await sleep(500);
    srv = start(); await sleep(900);
    const ov = (await adm('overview')).json;
    assert.strictEqual(ov.settings.winControl.houseShare, 0.7);
    assert.strictEqual(ov.settings.maxItemsPerRound, 3);
    assert.ok(ov.ledger.rounds > 0, 'tur kayıtları korunmalı');
    console.log('ok   yeniden başlatmada ayarlar ve istatistik korunuyor');
    console.log('\ne2e tamam');
  } finally { srv.kill(); fs.rmSync(dir, { recursive: true, force: true }); }
})().catch((e) => { console.error('BAŞARISIZ:', e); process.exit(1); });
