// Hızlı zamanlayıcıyla binlerce tur simüle eder; kasa payı / RTP ve sonuç dağılımını raporlar.
//   node test/simulate.js [houseShare=0.8] [rounds=20000] [off]
const G = require('../shared/game-core');
let t = 0; const q = [];
const setTimer = (fn, ms) => { const h = { at: t + ms, fn }; q.push(h); return h; };
const clearTimer = (h) => { const i = q.indexOf(h); if (i >= 0) q.splice(i, 1); };
const share = process.argv[2] === 'off' ? null : Number(process.argv[2] || 0.8);
const ROUNDS = Number(process.argv[3] || 20000);
const eng = new G.RoundEngine({ wallet: new G.MemoryWallet(1e12), now: () => t, setTimer, clearTimer,
  config: share == null ? { winControl: { enabled: false } } : { winControl: { enabled: true, houseShare: share } } });
G.attachBots(eng, 30);
eng.start();
const counts = {}; let rounds = 0;
eng.on('result', (r) => { counts[r.outcome] = (counts[r.outcome] || 0) + 1; rounds++; });
(async () => {
  while (rounds < ROUNDS) {
    q.sort((a, b) => a.at - b.at); const h = q.shift(); t = h.at; await h.fn();
    await new Promise(setImmediate);
  }
  const rtp = eng.ledger.win / eng.ledger.bet;
  const roundsWithBets = eng.roundLog.length;
  console.log('hedef kasa payı', share == null ? 'kapalı' : (share * 100).toFixed(0) + '%', '| tur', rounds);
  console.log('gerçekleşen kasa payı', ((1 - rtp) * 100).toFixed(2) + '%', '| RTP', (rtp * 100).toFixed(2) + '%', '| havuz', Math.round(eng.pool));
  for (const [k, v] of Object.entries(counts).sort((a, b) => b[1] - a[1])) console.log(k.padEnd(8), (v / rounds * 100).toFixed(2) + '%');
  const recent = eng.roundLog.slice(0, 200);
  console.log('son', recent.length, 'turda oyuncu-kazançlı tur oranı', (recent.filter((r) => r.pay > r.bet).length / recent.length * 100).toFixed(1) + '%');
  // birim test: ödeme
  const cfg = eng.config;
  console.assert(G.payoutFor(cfg, { corn: 1000, chicken: 200 }, 'corn') === 5000);
  console.assert(G.payoutFor(cfg, { corn: 1000, tomato: 500, chicken: 200 }, 'salad') === 7500);
  console.assert(G.payoutFor(cfg, { corn: 1000, chicken: 200, fish: 100 }, 'pizza') === 9000 + 2500);
  console.log('payout asserts ok');
  if (share != null && Math.abs((1 - rtp) - share) > 0.02) { console.error('HEDEF TUTMADI'); process.exit(1); }
})();
