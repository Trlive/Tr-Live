# Güvenlik güncellemesi

- `admin123` varsayılan yönetici anahtarı kaldırıldı.
- `npm run dev` artık en az 32 karakterlik `ADMIN_KEY` ister.
- Test botları varsayılan kapalıdır; yalnızca `DEV_BOTS` ile açıkça etkinleştirilebilir.
- Geliştirme başlatıcısı production ortamında çalışmayı reddeder.
- TR Live Coin entegrasyonunun canlı kabul edilmesi için gereken backend sözleşmesi `docs/COIN-INTEGRATION-STATUS.md` içinde açıklanmıştır.

Not: Bu arşiv kaynak güncellemesidir; üretim derlemesi ve uçtan uca testler ayrıca çalıştırılmalıdır.
