// İstemciyi tek bir HTML dosyasına gömer (CSS + JS inline).
// Çıktı: dist/kedi-carki.html — Tr-Live CDN'ine tek dosya olarak yüklenebilir.
//   Sunucuya bağlanmak için:  kedi-carki.html?server=wss://oyun.trlive.com/ws&token=<JWT>
//   Sunucusuz demo için:      kedi-carki.html?demo=1   (veya server parametresi olmadan)
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
let html = fs.readFileSync(path.join(root, 'client/index.html'), 'utf8');
html = html.replace(/<link rel="stylesheet" href="([^"]+)">/g, (_, href) =>
  `<style>\n${fs.readFileSync(path.join(root, 'client', href), 'utf8')}\n</style>`);
html = html.replace(/<script src="([^"]+)"><\/script>/g, (_, src) => {
  const file = src.startsWith('shared/') ? path.join(root, src) : path.join(root, 'client', src);
  return `<script>\n${fs.readFileSync(file, 'utf8').replace(/<\/script/gi, '<\\/script')}\n</script>`;
});
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist/kedi-carki.html'), html);
console.log('dist/kedi-carki.html', (html.length / 1024).toFixed(1) + ' KB');
