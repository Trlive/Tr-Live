// Basit, bağımlılıksız kalıcılık: JSON dosyası (atomik yazım).
// Ayarlar (panelden değişenler) ve oyun durumu (kol sayaçları, kasa kayıtları, sandıklar…) burada tutulur.
// Çok sunuculu kurulumda Redis/PostgreSQL ile değiştirin (docs/INTEGRATION.md §5).
const fs = require('fs');
const path = require('path');

const DIR = process.env.DATA_DIR || path.join(__dirname, 'data');

function file(name) { return path.join(DIR, name + '.json'); }

function load(name) {
  try { return JSON.parse(fs.readFileSync(file(name), 'utf8')); } catch (e) { return null; }
}

function save(name, data) {
  fs.mkdirSync(DIR, { recursive: true });
  const tmp = file(name) + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data));
  fs.renameSync(tmp, file(name));
}

module.exports = { load, save, DIR };
