// Yönetim paneli: statik sayfa (/admin) + JSON API (/admin/api/*).
// Kimlik doğrulama: ADMIN_KEY ortam değişkeni, her istekte `x-admin-key` başlığı. ADMIN_KEY yoksa panel kapalıdır.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PAGE = path.join(__dirname, '..', 'admin', 'index.html');
const fails = new Map(); // ip -> { n, reset }

function sha(s) { return crypto.createHash('sha256').update(String(s)).digest(); }
function keyOk(given) {
  const key = process.env.ADMIN_KEY;
  return !!key && !!given && crypto.timingSafeEqual(sha(given), sha(key));
}

function json(res, code, body) {
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(JSON.stringify(body));
}

function readBody(req, max = 8192) {
  return new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', (c) => { n += c.length; if (n > max) { reject(new Error('TOO_LARGE')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (e) { reject(new Error('BAD_JSON')); } });
    req.on('error', reject);
  });
}

/**
 * ctx: { engine, persistSettings(), online() -> Set<userId> }
 * İstek işlendiyse true döner.
 */
function handleAdmin(req, res, url, ctx) {
  const p = url.pathname;
  if (p !== '/admin' && p !== '/admin/' && !p.startsWith('/admin/api/') && p !== '/admin/stats') return false;

  if (p === '/admin' || p === '/admin/') {
    fs.readFile(PAGE, (err, buf) => {
      if (err) { res.writeHead(404); return res.end('admin sayfası bulunamadı'); }
      res.writeHead(200, {
        'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store',
        'x-frame-options': 'DENY', 'referrer-policy': 'no-referrer', 'x-content-type-options': 'nosniff',
      });
      res.end(buf);
    });
    return true;
  }

  // ---- kimlik doğrulama (deneme sınırı: IP başına dakikada 8 hatalı giriş)
  const ip = req.socket.remoteAddress || '?';
  const f = fails.get(ip);
  if (f && f.reset > Date.now() && f.n >= 8) { json(res, 429, { ok: false, error: 'TOO_MANY_ATTEMPTS' }); return true; }
  if (!process.env.ADMIN_KEY) { json(res, 503, { ok: false, error: 'ADMIN_DISABLED' }); return true; }
  const given = req.headers['x-admin-key'] || url.searchParams.get('key'); // ?key= yalnız eski /admin/stats için
  if (p !== '/admin/stats' && !req.headers['x-admin-key']) { json(res, 401, { ok: false, error: 'UNAUTHORIZED' }); return true; }
  if (!keyOk(given)) {
    const cur = f && f.reset > Date.now() ? f : { n: 0, reset: Date.now() + 60000 };
    cur.n += 1; fails.set(ip, cur);
    json(res, 401, { ok: false, error: 'UNAUTHORIZED' });
    return true;
  }
  fails.delete(ip);

  const { engine } = ctx;
  (async () => {
    try {
      if (p === '/admin/stats' && req.method === 'GET') { // eski uç nokta
        const l = engine.ledger;
        return json(res, 200, { ledger: l, rtp: l.bet ? l.win / l.bet : null, pool: engine.pool, trend: engine.trend() });
      }
      if (p === '/admin/api/overview' && req.method === 'GET') {
        const online = ctx.online();
        return json(res, 200, Object.assign({ ok: true, online: online.size }, engine.adminOverview()));
      }
      if (p === '/admin/api/players' && req.method === 'GET') {
        const online = ctx.online();
        return json(res, 200, { ok: true, players: engine.playersReport(200).map((r) => Object.assign(r, { online: online.has(r.id) })) });
      }
      if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'METHOD' });
      const body = await readBody(req);

      if (p === '/admin/api/settings') {
        let settings;
        try { settings = engine.updateConfig(body); } catch (e) { return json(res, 400, { ok: false, error: 'INVALID', detail: e.message }); }
        ctx.persistSettings();
        console.log('[admin] ayar güncellendi', JSON.stringify(body));
        return json(res, 200, { ok: true, settings });
      }
      if (p === '/admin/api/reset-control') {
        engine.resetControl();
        console.log('[admin] kasa payı sayaçları sıfırlandı');
        return json(res, 200, { ok: true });
      }
      if (p === '/admin/api/retry-unpaid') return json(res, 200, Object.assign({ ok: true }, await engine.retryUnpaid()));
      return json(res, 404, { ok: false, error: 'NOT_FOUND' });
    } catch (e) {
      return json(res, e.message === 'TOO_LARGE' || e.message === 'BAD_JSON' ? 400 : 500, { ok: false, error: e.message });
    }
  })();
  return true;
}

module.exports = { handleAdmin };
