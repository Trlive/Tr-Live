'use strict';
// Yerel geliştirme başlatıcısı: varsayılan yönetici anahtarı veya otomatik bot yok.
if (process.env.APP_ENV === 'production' || process.env.NODE_ENV === 'production') {
  console.error('Geliştirme sunucusu production ortamında çalıştırılamaz.'); process.exit(1);
}
if (!process.env.ADMIN_KEY || process.env.ADMIN_KEY.length < 32) {
  console.error('En az 32 karakterlik ADMIN_KEY tanımlayın. Örnek: openssl rand -hex 32'); process.exit(1);
}
process.env.APP_ENV = 'development';
process.env.DEV_AUTH = '1';
if (process.env.DEV_BOTS !== undefined) {
  const n = Number(process.env.DEV_BOTS);
  if (!Number.isInteger(n) || n < 0 || n > 30) throw new Error('DEV_BOTS 0–30 arasında tam sayı olmalı.');
  process.env.BOTS = String(n);
} else delete process.env.BOTS;
require('../index.js');
