// Tr-Live oturum doğrulama.
// Üretim: Tr-Live backend'i oyunu açarken kısa ömürlü bir HS256 JWT üretir
//   payload: { sub: "<userId>", name: "<görünen ad>", avatar: "<url>", anon?: bool, exp: <unix sn> }
//   ve WebView URL'ine ?token=<jwt> olarak ekler.
// Geliştirme: DEV_AUTH=1 iken "dev:<userId>:<ad>" biçimindeki token'lar kabul edilir.
const crypto = require('crypto');

function b64urlDecode(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  return Buffer.from(s, 'base64');
}

function verifyJwt(token, secret) {
  const parts = token.split('.');
  if (parts.length !== 3) throw new Error('BAD_TOKEN');
  const [h, p, sig] = parts;
  const header = JSON.parse(b64urlDecode(h).toString('utf8'));
  if (header.alg !== 'HS256') throw new Error('BAD_ALG');
  const expected = crypto.createHmac('sha256', secret).update(h + '.' + p).digest();
  const given = b64urlDecode(sig);
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) throw new Error('BAD_SIGNATURE');
  const payload = JSON.parse(b64urlDecode(p).toString('utf8'));
  if (payload.exp && payload.exp * 1000 < Date.now()) throw new Error('TOKEN_EXPIRED');
  return payload;
}

function authenticate(token) {
  if (!token) throw new Error('NO_TOKEN');
  if (process.env.DEV_AUTH === '1' && token.startsWith('dev:')) {
    const [, id, ...rest] = token.split(':');
    const name = decodeURIComponent(rest.join(':') || 'Misafir_' + id);
    return { id: String(id), name, avatar: null };
  }
  const secret = process.env.TRLIVE_JWT_SECRET;
  if (!secret) throw new Error('JWT_SECRET_MISSING');
  const p = verifyJwt(token, secret);
  return { id: String(p.sub), name: String(p.name || 'Oyuncu').slice(0, 24), avatar: p.avatar || null, anon: !!p.anon };
}

module.exports = { authenticate, verifyJwt };
