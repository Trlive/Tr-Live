// Kedi Çarkı oyun sunucusu
//   HTTP : istemci dosyalarını sunar (/, /shared/*), /health, /admin/stats
//   WS   : /ws?token=...   — tüm oyuncular aynı turu paylaşır (canlı yayın odası bağımsız, global tur)
const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');
const G = require('../shared/game-core');
const { authenticate } = require('./auth');
const { createWallet } = require('./wallet');
const store = require('./store');
const { handleAdmin } = require('./admin');

const PORT = Number(process.env.PORT || 8080);
const ROOT = path.join(__dirname, '..');
const CONFIG_FILE = process.env.GAME_CONFIG; // isteğe bağlı JSON ile DEFAULT_CONFIG'i ezer
const config = CONFIG_FILE ? JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) : {};
if (process.env.RTP_CONTROL) config.rtpControl = process.env.RTP_CONTROL;
if (process.env.TARGET_RTP) config.targetRtp = Number(process.env.TARGET_RTP);
if (process.env.MAX_ROUND_PAYOUT) config.maxRoundPayout = Number(process.env.MAX_ROUND_PAYOUT);
// İlk açılış varsayılanları (panelden kaydedilen ayarlar bunların üzerine yazar)
if (process.env.HOUSE_SHARE) config.winControl = Object.assign(config.winControl || {}, { houseShare: Number(process.env.HOUSE_SHARE) });
if (process.env.MAX_ITEMS) config.maxItemsPerRound = Number(process.env.MAX_ITEMS);

const wallet = createWallet(config.gameId || G.DEFAULT_CONFIG.gameId);
const engine = new G.RoundEngine({ config, wallet, log: (...a) => console.error('[engine]', ...a) });
if (Number(process.env.BOTS || 0) > 0) {
  console.warn('[bots] test botları açık:', process.env.BOTS);
  G.attachBots(engine, Number(process.env.BOTS));
}

// Kalıcı durum + panelden kaydedilmiş ayarlar
engine.importState(store.load('state'));
const savedSettings = store.load('settings');
if (savedSettings) { try { engine.updateConfig(savedSettings); } catch (e) { console.error('[settings] yüklenemedi:', e.message); } }
const persistSettings = () => store.save('settings', engine.editableConfig());
function persistState() {
  if (!engine.dirty) return;
  engine.dirty = false;
  try { store.save('state', engine.exportState()); } catch (e) { engine.dirty = true; console.error('[state] yazılamadı:', e.message); }
}
setInterval(persistState, 5000).unref();
setInterval(() => { if (engine.unpaid.size) engine.retryUnpaid().catch(() => {}); }, 30000).unref();
function shutdown() { engine.dirty = true; persistState(); process.exit(0); }
process.on('SIGINT', shutdown); process.on('SIGTERM', shutdown);

engine.start();

// ---------------------------------------------------------------------------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.json': 'application/json' };
function serveStatic(req, res) {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (p === '/' || p === '') p = '/client/index.html';
  else if (!p.startsWith('/shared/') && !p.startsWith('/client/')) p = '/client' + p;
  const file = path.normalize(path.join(ROOT, p));
  if (!file.startsWith(ROOT + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404); return res.end('not found'); }
    res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-cache' });
    res.end(buf);
  });
}

const connsPerUser = new Map(); // userId -> aktif WebSocket
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/health') {
    res.writeHead(200, { 'content-type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, round: engine.round, phase: engine.phase, players: wss.clients.size }));
  }
  if (handleAdmin(req, res, url, { engine, persistSettings, online: () => new Set(connsPerUser.keys()) })) return;
  serveStatic(req, res);
});

// ---------------------------------------------------------------------------
const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 4096 });

wss.on('connection', (ws, req) => {
  const url = new URL(req.url, 'http://x');
  let user;
  try {
    user = authenticate(url.searchParams.get('token'));
  } catch (e) {
    ws.send(JSON.stringify({ type: 'error', error: 'AUTH_FAILED', detail: e.message }));
    return ws.close(4001, 'auth');
  }

  // Aynı kullanıcının eski bağlantısını kapat (tek oturum)
  const prev = connsPerUser.get(user.id);
  if (prev && prev.readyState === prev.OPEN) prev.close(4002, 'replaced');
  connsPerUser.set(user.id, ws);

  const send = (m) => { if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(m)); };
  const session = G.createSession(engine, user, send);

  // Basit hız sınırı: saniyede en fazla 15 mesaj
  let bucket = 15, last = Date.now();
  ws.on('message', (raw) => {
    const now = Date.now();
    bucket = Math.min(15, bucket + ((now - last) / 1000) * 15); last = now;
    if (bucket < 1) return send({ type: 'error', error: 'RATE_LIMIT' });
    bucket -= 1;
    let msg; try { msg = JSON.parse(raw); } catch { return; }
    if (!msg || typeof msg.type !== 'string') return;
    session.handle(msg);
  });

  const alive = setInterval(() => { if (ws.readyState === ws.OPEN) ws.ping(); }, 25000);
  ws.on('close', () => {
    clearInterval(alive);
    session.close();
    if (connsPerUser.get(user.id) === ws) connsPerUser.delete(user.id);
  });
});

server.listen(PORT, () => console.log(`[kedi-carki] http://localhost:${PORT}  (ws: /ws)`));
