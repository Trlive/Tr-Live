// Tr-Live cüzdan adaptörü.
// Oyun servisi bakiyeyi ASLA kendisi tutmaz; her bahis ve kazanç Tr-Live cüzdanına
// idempotent (txId) çağrılarla yazılır. Sözleşme için docs/INTEGRATION.md'ye bakın.
const crypto = require('crypto');
const { MemoryWallet } = require('../shared/game-core');

class TrLiveWallet {
  constructor({ baseUrl, apiKey, secret, gameId, timeoutMs = 4000 }) {
    this.baseUrl = baseUrl.replace(/\/$/, '');
    this.apiKey = apiKey;
    this.secret = secret;
    this.gameId = gameId;
    this.timeoutMs = timeoutMs;
  }

  async _call(path, body, { retries = 0 } = {}) {
    const payload = JSON.stringify(Object.assign({ gameId: this.gameId, ts: Date.now() }, body));
    const sig = crypto.createHmac('sha256', this.secret).update(payload).digest('hex');
    let lastErr;
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const ctrl = new AbortController();
        const to = setTimeout(() => ctrl.abort(), this.timeoutMs);
        const res = await fetch(this.baseUrl + path, {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-api-key': this.apiKey, 'x-signature': sig },
          body: payload,
          signal: ctrl.signal,
        });
        clearTimeout(to);
        const json = await res.json().catch(() => ({}));
        if (res.status >= 500) throw new Error('WALLET_' + res.status);
        return json; // { ok, balance, error? }
      } catch (e) {
        lastErr = e;
        await new Promise((r) => setTimeout(r, 300 * (attempt + 1)));
      }
    }
    throw lastErr;
  }

  async balance(userId) {
    const r = await this._call('/balance', { userId }, { retries: 2 });
    return r.balance;
  }
  // Bahis: tek deneme. Zaman aşımında Tr-Live tarafı aynı txId'yi tekrar görürse
  // aynı sonucu döndürmelidir; belirsiz durumda bahis reddedilir.
  async debit(userId, amount, txId, meta) {
    return this._call('/debit', { userId, amount, txId, meta });
  }
  // Kazanç: idempotent olduğu için güvenle tekrar denenir.
  async credit(userId, amount, txId, meta) {
    return this._call('/credit', { userId, amount, txId, meta }, { retries: 5 });
  }
}

function createWallet(gameId) {
  if (process.env.TRLIVE_WALLET_URL) {
    return new TrLiveWallet({
      baseUrl: process.env.TRLIVE_WALLET_URL,
      apiKey: process.env.TRLIVE_API_KEY || '',
      secret: process.env.TRLIVE_WALLET_SECRET || '',
      gameId,
    });
  }
  console.warn('[wallet] TRLIVE_WALLET_URL yok -> bellek içi cüzdan (yalnızca geliştirme)');
  return new MemoryWallet(Number(process.env.DEV_START_BALANCE || 1000000));
}

module.exports = { TrLiveWallet, createWallet };
