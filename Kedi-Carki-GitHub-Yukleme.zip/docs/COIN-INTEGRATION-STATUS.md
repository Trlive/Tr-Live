# TR Live Coin entegrasyon durumu

Bu arşiv Kedi Çarkı oyun servisidir; TR Live ana backend kaynak kodu değildir. Gerçek kullanıcı Coin bakiyesine bağlantı bu ZIP ile tek başına tamamlanmış sayılmaz.

Oyun sunucusundaki cüzdan adaptörünün gerçek TR Live servisiyle çalışması için TR Live backend tarafında imzalı ve idempotent bakiye, debit ve credit uç noktaları uygulanmalı; gerçek JWT issuer/audience/imza sözleşmesi eşleştirilmelidir. Debit ve credit işlemleri DB transaction içinde yapılmalı ve benzersiz txId tekrarlandığında ikinci kez bakiye değiştirmemelidir.

Canlıya geçiş öncesi: gerçek API sözleşmesi, HMAC/replay koruması, atomik Coin düşme/yükleme, işlem geçmişi mutabakatı ve WebSocket uçtan uca testleri tamamlanmalıdır. Bunlar doğrulanmadan gerçek kullanıcı Coin bakiyesiyle bahis açılmamalıdır.
