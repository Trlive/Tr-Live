# Kedi Çarkı — Tr-Live Entegrasyon Rehberi

Kedi Çarkı, Tr-Live canlı yayın ekranında alt panel (WebView / iframe) olarak açılan,
**sunucu otoriter** bir çok oyunculu tur oyunudur. Tüm oyuncular aynı turu paylaşır.

```
┌──────────────┐  ?token=JWT   ┌──────────────────┐   WS /ws    ┌───────────────────┐
│ Tr-Live App  │ ────────────▶ │ Oyun istemcisi   │ ──────────▶ │ Oyun sunucusu     │
│ (WebView)    │ ◀── bridge ── │ (client/ veya    │ ◀────────── │ (server/, Node)   │
└──────────────┘               │  dist/*.html)    │             └─────────┬─────────┘
        ▲                      └──────────────────┘                       │ HMAC imzalı
        │                                                                 ▼ HTTP
        └──────────────────────────── Tr-Live Backend: auth + cüzdan (debit/credit/balance)
```

## 1. Oyun kuralları (videodaki oyunun mantığı)

| Faz | Süre | Ne olur |
|---|---|---|
| `betting` — "Zamanı Seç" | 30 sn | Oyuncu çip seçer, yiyeceğe dokunur. Bakiye anında düşülür (debit). |
| `drawing` — "Sonuçlar geliyor…" | 5 sn | Bahis kapanır, sunucu sonucu belirler; çarkta ışık döner ve kazanana iner. |
| `result` — "Show Time" | 5 sn | Kazançlar ödenir (credit), sonuç paneli + en yüksek 3 kazanan gösterilir. |

Çark (saat yönünde): 🐔 x45 · 🍅 x5 · 🐐 x15 · 🫑 x5 · 🐟 x25 · 🥕 x5 · 🦐 x10 · 🌽 x5

- Kazanç = o yiyeceğe yatırılan miktar × çarpan.
- **Salata** çıkarsa tüm sebze bahisleri (🍅🫑🥕🌽), **Pizza** çıkarsa tüm et bahisleri (🐔🐐🐟🦐) kendi çarpanıyla kazanır.
  Bu iki sonuç **ödül havuzundan** ödenir; havuz, her bahsin `%2`'siyle büyür ve büyüdükçe çıkma şansı artar.
- Bir oyuncu aynı turda en fazla **7 farklı yiyeceğe** bahis yapabilir (8 kolun 7'si).
- Çipler: 200 · 500 · 1.000 · 4.000 · 10.000 · 30.000 · 100.000
- **BET** düğmesi önceki turun bahislerini tekrarlar.
- Günlük bahis sandıkları: 2M · 8M · 18M · 40M · 80M (ödüller `shared/game-core.js` → `chests`).
- "Hot" etiketi: son 20 turda beklenenden belirgin şekilde sık çıkan yiyecek.

### Kasa payı (genel %80 / %20) ve sonuç seçimi

Varsayılan: oyuncuların yatırdığı **toplam** paranın **%80'i kasada kalır, %20'si oyunculara ödenir**
(`winControl.houseShare = 0.80`). Oran panelden canlı değiştirilir; tek tek turlara değil, toplama uygulanır.

Her çekilişte (bekleyen tüm bahisler işlendikten sonra):

1. Her sonucun bu turdaki toplam ödemesi hesaplanır (Salata/Pizza yalnızca havuz yetiyorsa aday olur).
2. `maxRoundPayout` aşan sonuçlar elenir.
3. **Bütçe** = `(1 − kasaPayı) × (şimdiye kadarki bahis + bu turun bahsi) − şimdiye kadarki ödeme`.
   Ödemesi bütçeyi aşan sonuçlar elenir; kalanlar arasından `1/çarpan` ağırlığıyla rastgele seçilir.
   Bütçe hiçbirine yetmiyorsa en az ödeyen sonuç seçilir.

Sonuç: ödeme hedef geri ödeme oranının (%20) üzerine çıkmaz; bütçe birikince büyük kazançlar mümkün olur.
`node test/simulate.js 0.8 20000` ile doğrulanır (5.000 turda gerçekleşen kasa payı ≈ %80,1).

> Bu oranda oyuncular nadiren kazanır: x5 bir kaleme tek başına oynayan oyuncu, uzun vadede yaklaşık 25 turda 1 kez kazanır.
> Kasa payını düşürmek (ör. %50) kazanma sıklığını hızla artırır.

`winControl.enabled = false` yapılırsa eski davranış geçerlidir (`rtpControl: none | adaptive`, saf ağırlıklı rastgele, RTP ≈ %97).

### Kol sınırı

Çarkta 8 kol (yiyecek) var. Bir oyuncu **aynı turda en fazla 7 farklı kola** bahis yapabilir (`maxItemsPerRound: 7`);
bahis koyduğu koldan istediği kadar artırabilir. Sınır her yeni turda sıfırlanır. Sunucu 8. kolda `ARM_LIMIT` döner,
bakiyeden düşmez; eşzamanlı isteklerde fazla gelen bahis otomatik iade edilir. İstemci "Kalan Kol x/7" gösterir ve
dolunca boş kolları soluklaştırır. Panelden 1–8 arası değiştirilir (8 = sınırsız).

## 2. Tr-Live backend'inin sağlaması gerekenler

### 2.1 Oturum token'ı (JWT, HS256)

Oyunu açarken Tr-Live backend kısa ömürlü (ör. 10 dk) bir token üretir ve WebView URL'ine ekler:

```
https://oyun.trlive.com/?token=<JWT>&roomId=<yayınId>
```

Payload:
```json
{ "sub": "12647342", "name": "Derman", "avatar": "https://cdn.trlive.com/a/123.jpg", "anon": false, "exp": 1760000000 }
```
`anon: true` ise kullanıcı sıralamalarda "Gizli Kullanıcı" olarak görünür.
İmzalama anahtarı oyun sunucusunda `TRLIVE_JWT_SECRET` olarak tanımlanır.

### 2.2 Cüzdan API'si

Oyun sunucusu bakiye **tutmaz**; her işlem Tr-Live cüzdanına yazılır. Tüm çağrılar `POST`,
gövde JSON, başlıklar:

```
x-api-key:   <TRLIVE_API_KEY>
x-signature: hex(HMAC-SHA256(TRLIVE_WALLET_SECRET, ham_gövde))
```

| Uç nokta | Gövde | Yanıt |
|---|---|---|
| `/balance` | `{gameId, ts, userId}` | `{ok:true, balance}` |
| `/debit` | `{gameId, ts, userId, amount, txId, meta:{round,item}}` | `{ok:true, balance}` veya `{ok:false, error:"INSUFFICIENT_FUNDS", balance}` |
| `/credit` | `{gameId, ts, userId, amount, txId, meta:{round,outcome}}` | `{ok:true, balance}` |

**Zorunlu kurallar**
1. **İdempotens:** Aynı `txId` ikinci kez gelirse işlem tekrar uygulanmaz, ilk sonucun aynısı döner.
   (Kazanç ödemesi ağ hatasında 5 kez yeniden denenir.)
2. `txId` biçimleri: bahis `kedi-carki:<epoch>:<tur>:<userId>:b<sıra>`, kazanç `kedi-carki:<epoch>:<tur>:<userId>:win`
   (`epoch` = sunucu açılış zamanı, yeniden başlatmalarda çakışmayı önler),
   iade `...:refund`, sandık `kedi-carki:chest:<gün>:<userId>:<index>`.
3. `ts` 60 sn'den eskiyse reddedin (replay koruması). İmzayı sabit zamanlı karşılaştırın.
4. 5xx yanıtlar "geçici hata" sayılır; 4xx ve `{ok:false}` kesin red sayılır.

### 2.3 Uygulama köprüsü (WebView ↔ oyun)

Oyun, host'a şu kanallardan biriyle mesaj gönderir (ilk bulunan kullanılır):

- **Android:** `webView.addJavascriptInterface(obj, "TrLiveBridge")` → `obj.postMessage(String json)`
- **iOS:** `WKUserContentController.add(handler, name: "trlive")`
- **Web (iframe):** `window.parent.postMessage({source:'kedi-carki', type, data}, hostOrigin)`
  (`?hostOrigin=https://trlive.com` verilirse yalnız o origin'den gelen mesajlar kabul edilir)

| Oyun → Host | data | Beklenen davranış |
|---|---|---|
| `ready` | `{gameId}` | Yükleniyor göstergesini kapat |
| `close` | `{}` | Paneli kapat |
| `recharge` | `{need}` | Coin yükleme ekranını aç |
| `balance` | `{balance}` | Uygulamadaki bakiye göstergesini güncelle |
| `bigWin` | `{win, outcome, round}` | (İsteğe bağlı) yayında efekt / duyuru |
| `haptic` | `{style}` | Titreşim |

Host → oyun: `window.KediCarki.onHostMessage({type, data})`
(veya `postMessage({target:'kedi-carki', type, data})`)

| Tür | Ne zaman |
|---|---|
| `balanceRefresh` | Kullanıcı coin yükledikten sonra |
| `mute` `{muted}` | Yayın sesi ile senkron |
| `pause` / `resume` | Uygulama arka plana gidip geldiğinde |

## 3. İstemci ↔ sunucu protokolü (WebSocket, JSON)

Sunucu → istemci: `hello` · `phase` · `totals` (250 ms'de bir toplanır) · `result` (kişiye özel) · `ticker` · `error`
İstemci → sunucu (`reqId` ile, yanıt `{type:'ack', reqId, ok, ...}`):
`bet {item, amount, round}` (hata kodları: `BETTING_CLOSED`, `INSUFFICIENT_FUNDS`, `ARM_LIMIT`, `GAME_PAUSED`…) · `repeat` · `leaderboard {which: today|yesterday}` · `trend` · `claimChest {index}` · `balance` · `ping`

Kapanış kodları: `4001` kimlik doğrulama hatası, `4002` aynı hesap başka cihazda açıldı.

## 4. Kurulum

```bash
cd server && npm install
# geliştirme (bellek içi cüzdan, test botları, dev token):
ADMIN_KEY="$(openssl rand -hex 32)" npm run dev   # http://localhost:8080; botlar varsayılan kapalı
# üretim:
TRLIVE_JWT_SECRET=... TRLIVE_WALLET_URL=https://api.trlive.com/games/wallet \
TRLIVE_API_KEY=... TRLIVE_WALLET_SECRET=... ADMIN_KEY=... \
RTP_CONTROL=none MAX_ROUND_PAYOUT=50000000 node index.js
```

| Ortam değişkeni | Açıklama |
|---|---|
| `PORT` | HTTP/WS portu (8080) |
| `TRLIVE_JWT_SECRET` | Token imza anahtarı |
| `TRLIVE_WALLET_URL`, `TRLIVE_API_KEY`, `TRLIVE_WALLET_SECRET` | Cüzdan API'si. Yoksa bellek içi cüzdan kullanılır (yalnız geliştirme). |
| `GAME_CONFIG` | Varsayılan ayarları ezen JSON dosyası (çarpanlar, çipler, süreler, sandıklar…) |
| `HOUSE_SHARE`, `MAX_ITEMS` | İlk açılış değerleri (kasa payı 0–1, aynı turda en fazla kol). Panelden kaydedilen ayarlar bunları ezer. |
| `RTP_CONTROL`, `TARGET_RTP`, `MAX_ROUND_PAYOUT` | Sonuç seçimi ayarları (`RTP_CONTROL` yalnızca kasa payı kontrolü kapalıyken etkilidir) |
| `ADMIN_KEY` | Yönetim paneli anahtarı (§4.1). Tanımlı değilse panel kapalıdır. Uzun ve rastgele seçin. |
| `DATA_DIR` | Kalıcı durum klasörü (varsayılan `server/data`): ayarlar, kol sayaçları, kasa kayıtları, sandıklar |
| `DEV_AUTH=1` | `dev:<id>:<ad>` token'larını kabul et — **üretimde kapalı** |
| `BOTS=n` | Test botları — **üretimde kapalı** |

Tek dosyalık istemci: `node tools/build-standalone.js` → `dist/kedi-carki.html`
(`?server=wss://…/ws&token=…` ile sunucuya bağlanır; parametresiz açılırsa demo modunda çalışır).

### 4.1 Yönetim paneli

`https://<sunucu>/admin` — `ADMIN_KEY` ile giriş (anahtar tarayıcı oturumunda tutulur, her istekte `x-admin-key` başlığıyla gider).
Panelde: gerçekleşen/hedef kasa payı, kâr, RTP, oyuncu kazanma sıklığı, havuz; **kasa payı kaydırıcısı**, kol sınırı,
bakım modu (yeni bahis almaz), tur başı bahis/ödeme sınırları; son turlar tablosu; oyuncular;
sonuç dağılımı; ödenemeyen kazançlar ve yeniden deneme.

| API (`x-admin-key` gerekir) | Açıklama |
|---|---|
| `GET /admin/api/overview` | Tüm özet |
| `GET /admin/api/players` | Bugünkü oyuncular, açık kol sayısı, çevrimiçi mi |
| `POST /admin/api/settings` | Kısmi ayar: `{winControl:{enabled,houseShare}, maxItemsPerRound, bettingEnabled, maxBetPerRound, maxRoundPayout}` |
| `POST /admin/api/reset-control` | Kasa payı sayaçlarını sıfırlar (ölçüm baştan başlar) |
| `POST /admin/api/retry-unpaid` | Ödenemeyen kazançları yeniden dener |

Hatalı girişler IP başına dakikada 8 ile sınırlıdır. Panel yalnızca HTTPS arkasında, mümkünse IP kısıtıyla yayınlanmalıdır.
Eski `GET /admin/stats?key=` ucu geriye dönük uyumluluk için duruyor.

## 5. Üretime çıkmadan önce yapılacaklar

- [ ] Kalıcı depolama: durum şu an yerel JSON dosyasında (`DATA_DIR`, 5 sn'de bir). Tek sunucu için yeterli;
      çok sunucu / felaket kurtarma için Redis/PostgreSQL'e taşınmalı. Ödenemeyen kazançlar bellekte kuyruğa alınır ve
      otomatik denenir; yine de cüzdan tarafında txId ile mutabakat raporu önerilir.
- [ ] Çoklu sunucu: tek tur motoru (lider) + WS düğümleri arasında Redis pub/sub.
- [ ] Görseller: yiyecekler şu an emoji (Noto Color Emoji ile tüm cihazlarda aynı görünür). Tasarımcı PNG/SVG'leri
      `items[].icon` yerine görsel URL'si olarak verilecekse `app.js` → `buildWheel` güncellenmeli.
- [ ] Ses efektleri şu an sentezleniyor; gerçek ses dosyaları eklenebilir.
- [ ] Yasal uygunluk: Coin'ler gerçek paraya veya nakde çevrilebilen bir birime dönüşebiliyorsa, şans oyunu
      mevzuatı (Türkiye'de 7258 sayılı Kanun) açısından hukuk görüşü alınmalı.
