# Kedi Çarkı 🐱🎡

Tr-Live canlı yayın uygulaması için çok oyunculu yiyecek çarkı oyunu.

```
shared/game-core.js     Ortak çekirdek: tur motoru, sonuç seçimi, ödeme, oturum protokolü
server/                 Node.js oyun sunucusu (WebSocket, JWT auth, Tr-Live cüzdan adaptörü)
client/                 Mobil arayüz (HTML/CSS/JS, framework yok) + Tr-Live köprüsü
tools/build-standalone  İstemciyi tek HTML dosyasına gömer → dist/kedi-carki.html
admin/index.html        Yönetim paneli (/admin): kasa payı, kol sınırı, istatistik, oyuncular
test/simulate.js        Kasa payı / RTP / dağılım simülasyonu
test/rules.js           Kural birim testleri (kol sınırı, kasa payı, iade, kalıcılık)
test/e2e.js             Gerçek sunucuda uçtan uca test (WebSocket + yönetim API'si)
docs/INTEGRATION.md     Tr-Live ekibi için entegrasyon sözleşmesi
```

Hızlı başlangıç:

```bash
cd server && npm install && ADMIN_KEY="$(openssl rand -hex 32)" npm run dev   # http://localhost:8080
node test/rules.js && node test/e2e.js    # testler
node test/simulate.js 0.8                 # %80 kasa payı simülasyonu
# Yönetim paneli: http://localhost:8080/admin  (yönetici anahtarı: ADMIN_KEY ortam değişkeni; en az 32 karakter)
node tools/build-standalone.js            # dist/kedi-carki.html (demo: ?demo=1)
```

Ayrıntılar: [docs/INTEGRATION.md](docs/INTEGRATION.md)

**Varsayılan kurallar:** aynı turda en fazla **7 farklı kola** bahis · oyuncuların toplam bahsinin **%80'i kasada, %20'si oyunculara** (panelden değişir).
