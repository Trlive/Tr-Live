import { cpLevelFor } from './levels.js';

// Kullanıcıyı dışarıya nasıl göstereceğimizi tek yerde toplar.
// Diğer kullanıcılara ASLA bakiye (coin/diamond) verilmez.
export const HIDDEN_NAME = 'Gizli Kullanıcı';

// "u" takma adlı users tablosu ile kullanılır.
export const USER_PUBLIC_COLUMNS = `u.id, u.username, u.public_id, u.display_name, u.avatar_url, u.is_hidden, u.hidden_alias, u.wip_hidden,
  u.coin_level, u.gift_level, u.created_at AS u_created_at, u.kyc_status AS u_kyc_status, uw.level AS wip_level, wt.features AS wip_features,
  (SELECT COALESCE(fr.image_url, fi.metadata->>'assetUrl') FROM inventory_items fi
     LEFT JOIN frames fr ON fr.id::text = fi.item_key
    WHERE fi.user_id = u.id AND fi.item_type = 'frame' AND fi.is_active = TRUE
      AND (fi.expires_at IS NULL OR fi.expires_at > NOW()) AND COALESCE(fi.metadata->>'equipped' = 'true', FALSE)
    ORDER BY fi.created_at DESC LIMIT 1) AS frame_url,
  u.cp_partner_id,
  (SELECT jsonb_object_agg(c.item_type, c.url) FROM (
     SELECT DISTINCT ON (ci.item_type) ci.item_type, ci.metadata->>'assetUrl' AS url FROM inventory_items ci
      WHERE ci.user_id = u.id AND ci.item_type IN ('chat_bubble', 'mic_wave', 'mini_card', 'room_card')
        AND ci.item_key NOT LIKE 'wip:%' AND ci.is_active = TRUE AND (ci.expires_at IS NULL OR ci.expires_at > NOW())
        AND COALESCE(ci.metadata->>'equipped' = 'true', FALSE) AND ci.metadata->>'assetUrl' IS NOT NULL
      ORDER BY ci.item_type, ci.created_at DESC) c) AS cosmetics,
  (SELECT jsonb_object_agg(wi.item_type, (wi.metadata->>'wipLevel')::int) FROM inventory_items wi
    WHERE wi.user_id = u.id AND wi.item_key LIKE 'wip:%' AND wi.is_active = TRUE
      AND (wi.expires_at IS NULL OR wi.expires_at > NOW()) AND COALESCE(wi.metadata->>'equipped' = 'true', FALSE)) AS wip_items,
  (SELECT si.special_id FROM special_ids si WHERE si.user_id = u.id AND si.expires_at > NOW()) AS special_id,
  (SELECT hb.badge FROM host_badges hb WHERE hb.user_id = u.id AND hb.expires_at > NOW()) AS host_badge,
  (SELECT substring(ci.item_key FROM 5) FROM inventory_items ci
    WHERE ci.user_id = u.id AND ci.item_type = 'colored_id' AND ci.is_active = TRUE AND (ci.expires_at IS NULL OR ci.expires_at > NOW())
      AND COALESCE(ci.metadata->>'equipped' = 'true', FALSE) ORDER BY ci.created_at DESC LIMIT 1) AS id_color,
  CASE WHEN u.cp_partner_id IS NULL THEN NULL ELSE (SELECT cp.exp FROM cp_pairs cp
    WHERE cp.user_a = LEAST(u.id, u.cp_partner_id) AND cp.user_b = GREATEST(u.id, u.cp_partner_id) AND cp.relation = 'cp') END AS cp_exp`;
export const USER_PUBLIC_JOINS = `LEFT JOIN user_wip uw ON uw.user_id = u.id AND uw.is_active = TRUE AND uw.expires_at > NOW()
  LEFT JOIN wip_tiers wt ON wt.level = uw.level`;

/** Takılı (ayrıca verilmiş) WIP öğesi; yoksa üyelik öğesi kapatıldıysa 0, değilse null (uygulama üyelik kademesini kullanır). */
const wipItem = (row, type) => row.wip_items?.[type] ?? (row.wip_hidden?.[type] === true ? 0 : null);

/**
 * Gizli kullanıcı (Yoho "gizemli kişi") YALNIZCA oda bağlamında, odadan çıkan yayınlarda ve sıralamalarda gizlenir:
 *  - roomUser: oda içi (üyeler, koltuk, oda sohbeti, hediye, çanta, PK, oyun, oda katkı listesi) → "Gizli Kullanıcı" + gizli ID.
 *  - anonUser: sıralamalar, destekçiler, etkinlik sıralamaları, tüm uygulamaya giden hediye / şans şeritleri → "Gizli Kullanıcı"
 *    (gizli ID yok: oda dışı listede gizli kimlik ID'siyle eşleştirilemesin).
 *  - publicUser: mesajlar, akış, yorumlar, profil, arkadaş, takip, aile, CP, koruyucu… → kişinin KENDİ kimliği. Gizli modda
 *    olduğu bildirilmez (isHidden: false) ve gizli ID hiç gönderilmez; hangi odada olduğu da hiçbir yerde gösterilmez
 *    (çevrimiçi / odada bilgisi gizli kullanıcı için kapalı), böylece odadaki gizli kimlikle eşleştirilemez.
 */
export function publicUser(row, viewerId = null) {
  if (!row) return null;
  void viewerId;
  return {
    id: row.id,
    publicId: row.public_id ?? null,
    // Maaş ödülü / yönetimce verilen özel ID (süslü kimlik) ve yayıncı rozeti (Bronz … Özel).
    specialId: row.special_id ?? null,
    hostBadge: row.host_badge ?? null,
    // Takılı renkli ID (Görünüm): bronz / gumus / altin.
    idColor: row.id_color ?? null,
    username: row.username,
    displayName: row.display_name,
    avatarUrl: row.avatar_url,
    coinLevel: row.coin_level,
    giftLevel: row.gift_level,
    wipLevel: row.wip_level ?? null,
    nameColor: row.wip_features?.nameColor ?? null,
    frameUrl: row.frame_url ?? null,
    // Mağazadan alınıp takılan görünüm öğeleri: sohbet balonu, mikrofon dalgası, profil kartı, oda kartı.
    chatBubbleUrl: row.cosmetics?.chat_bubble ?? null,
    micWaveUrl: row.cosmetics?.mic_wave ?? null,
    profileCardUrl: row.cosmetics?.mini_card ?? null,
    roomCardUrl: row.cosmetics?.room_card ?? null,
    // Oda dışında gizli mod bildirilmez (kişi kendi kimliğiyle görünür).
    isHidden: false,
    // Yönetimden ayrı verilen ve takılı WIP öğeleri (WIP üyeliğinden bağımsız): çerçeve, sohbet balonu, rozet, giriş efekti.
    // Kullanıcı üyeliğin verdiği öğeyi Görünüm'den çıkardıysa 0 gelir (uygulama 0'ı "yok" sayar, üyelik
    // kademesine geri düşmez).
    wipFrame: wipItem(row, 'frame'),
    wipBubble: wipItem(row, 'chat_bubble'),
    wipBadge: wipItem(row, 'badge'),
    wipEntrance: wipItem(row, 'entrance_effect'),
    // CP: odada yan yana oturunca kalp efekti için (yalnızca onaylı CP ilişkisi).
    cpPartnerId: row.cp_exp != null ? row.cp_partner_id : null,
    cpLevel: row.cp_exp != null ? cpLevelFor(row.cp_exp) : null,
    // Sohbette "yakın zamanda kayıt oldu" kartı (son 3 gün) ve "Doğrulanmış" rozeti.
    isNew: row.u_created_at ? Date.now() - new Date(row.u_created_at).getTime() < 3 * 86400e3 : false,
    verified: row.u_kyc_status === 'approved',
  };
}

// Gizli kimlik: ad "Gizli Kullanıcı", gerçek ID yerine (oda içinde) gizli ID; seviyeler ve görünüm öğeleri de gösterilmez
// (kim olduğu seviyesinden / çerçevesinden tahmin edilmesin). Gizli kullanıcı kendini de odada böyle görür.
function maskedUser(row, alias) {
  return {
    id: row.id, publicId: null, hiddenId: alias ? (row.hidden_alias ?? null) : null, username: HIDDEN_NAME, displayName: HIDDEN_NAME, avatarUrl: null,
    coinLevel: null, giftLevel: null, wipLevel: null, nameColor: null, frameUrl: null, isHidden: true,
    chatBubbleUrl: null, micWaveUrl: null, profileCardUrl: null, roomCardUrl: null, specialId: null, hostBadge: null, idColor: null,
  };
}

/** Oda içi gösterim: gizli kullanıcı "Gizli Kullanıcı" ve gizli ID'siyle görünür. */
export const roomUser = (row, viewerId = null) => (!row ? null : row.is_hidden ? maskedUser(row, true) : publicUser(row, viewerId));

/** Sıralama / destekçi / tüm uygulamaya giden şerit: gizli kullanıcı "Gizli Kullanıcı" (gizli ID'siz). */
export const anonUser = (row, viewerId = null) => (!row ? null : row.is_hidden ? maskedUser(row, false) : publicUser(row, viewerId));

export function selfUser(row) {
  return {
    id: row.id,
    publicId: row.public_id ?? null,
    username: row.username,
    displayName: row.display_name,
    avatarUrl: row.avatar_url,
    coverUrl: row.cover_url ?? null,
    bio: row.bio,
    language: row.language,
    gender: row.gender ?? null,
    birthDate: row.birth_date ? String(row.birth_date).slice(0, 10) : null,
    country: row.country ?? null,
    city: row.city ?? null,
    coins: String(row.coins),
    diamonds: String(row.diamonds),
    totalSentCoins: String(row.total_sent_coins),
    totalReceivedDiamonds: String(row.total_received_diamonds),
    coinLevel: row.coin_level,
    giftLevel: row.gift_level,
    isHidden: Boolean(row.is_hidden),
    // Gizli moddayken odalarda görünen gizli ID (Ayarlar'da kişiye gösterilir).
    hiddenId: row.is_hidden ? (row.hidden_alias ?? null) : null,
    whoCanDm: row.who_can_dm ?? 'everyone',
    showPresence: row.show_presence !== false,
    hideCountry: row.hide_country === true,
    hideVisits: row.hide_visits !== false,
    termsVersion: row.terms_version ?? null,
    ghostMode: row.ghost_mode === true,
    chatRestrictedUntil: row.chat_restricted_until && new Date(row.chat_restricted_until) > new Date() ? row.chat_restricted_until : null,
    systemRole: row.system_role,
    kycStatus: row.kyc_status ?? 'none',
    phone: row.phone ?? null,
    // Google/Facebook ile açılan hesapların şifresi yoktur (silme onayı ve şifre belirleme buna göre).
    hasPassword: Boolean(row.password_hash),
    createdAt: row.created_at,
  };
}
