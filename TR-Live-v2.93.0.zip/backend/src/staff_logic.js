// Yardımcı admin ("support") yetkileri ve süreli ban hesapları (saf mantık, test edilebilir).
// Yardımcı admin YALNIZCA: kullanıcı arama / listeleme / ayrıntı (bakiyesiz), nick değiştirme, profil fotoğrafı değiştirme/kaldırma, süreli/süresiz ban ve ban kaldırma,
// sohbet kısıtı koyma/kaldırma.
const SUPPORT_ROUTES = [
  ['GET', /^\/users$/],
  ['GET', /^\/users\/list$/],
  ['GET', /^\/users\/[^/]+\/detail$/],
  ['GET', /^\/overview\/pending$/],
  // v2.71: Coin yükleme (en fazla 100.000, düşemez), WIP verme / alma, öğe verme, seviye verme (en fazla 100).
  ['POST', /^\/users\/[^/]+\/coins$/],
  ['POST', /^\/users\/[^/]+\/wip$/],
  ['DELETE', /^\/users\/[^/]+\/wip$/],
  ['GET', /^\/grantables$/],
  ['POST', /^\/users\/[^/]+\/grant$/],
  ['POST', /^\/users\/[^/]+\/level$/],
  ['POST', /^\/users\/[^/]+\/ban$/],
  ['POST', /^\/users\/[^/]+\/unban$/],
  ['POST', /^\/users\/[^/]+\/display-name$/],
  ['POST', /^\/users\/[^/]+\/avatar$/],
  ['POST', /^\/users\/[^/]+\/chat-restriction$/],
  ['GET', /^\/me\/permissions$/],
  ['GET', /^\/support\/threads$/],
  ['GET', /^\/support\/[^/]+$/],
  ['POST', /^\/support\/[^/]+\/reply$/],
];

export function supportMayCall(method, path) {
  const p = path.replace(/\/+$/, '') || '/';
  return SUPPORT_ROUTES.some(([m, re]) => m === method.toUpperCase() && re.test(p));
}

/**
 * Oda içi komutlar (mikten alma, atma, engelleme, susturma, rol, koltuk kilidi ile indirme):
 * yönetici hesabına kimse (oda sahibi dahil) uygulayamaz; yardımcı admine yalnızca yönetici uygulayabilir.
 * Dönüş: engel varsa kullanıcıya gösterilecek mesaj, yoksa null.
 */
export function roomStaffShield(actorSystemRole, targetSystemRole) {
  if (targetSystemRole === 'admin') return 'Yönetim hesabına komut uygulanamaz.';
  if (targetSystemRole === 'support' && actorSystemRole !== 'admin') return 'Yardımcı admine yalnızca yönetim komut uygulayabilir.';
  return null;
}

export const MAX_BAN_HOURS = 24 * 365;

// hours: sayı (saat) veya null/0 = süresiz. Dönüş: bitiş zamanı (Date) veya null (süresiz).
export function banEnd(hours, now = new Date()) {
  if (hours === null || hours === undefined || hours === 0 || hours === '0') return null;
  const h = Number(hours);
  if (!Number.isFinite(h) || h <= 0 || h > MAX_BAN_HOURS) return undefined; // geçersiz
  return new Date(now.getTime() + Math.round(h * 3600e3));
}

export const banExpired = (user, now = new Date()) =>
  user.account_status === 'banned' && user.banned_until != null && new Date(user.banned_until) <= now;

export function banMessage(user) {
  if (user.banned_until) {
    const d = new Date(user.banned_until);
    const tr = new Date(d.getTime() + 3 * 3600e3).toISOString().replace('T', ' ').slice(0, 16);
    return `Hesabınız ${tr} (TSİ) tarihine kadar askıya alındı.${user.ban_reason ? ` Neden: ${user.ban_reason}` : ''}`;
  }
  return `Hesabınız askıya alındı.${user.ban_reason ? ` Neden: ${user.ban_reason}` : ''}`;
}

/**
 * ADMIN_USERNAMES (sunucu açılışı): listedeki ada sahip aktif hesap yönetici yapılsın mı?
 *  'other': bu ad daha önce BAŞKA bir hesaba yönetici yetkisi verdi (o hesap silinince / adı değişince boşa çıkan adı
 *           biri almış olabilir) → hayır.
 *  'late':  hesap, ad listeye ilk eklendikten SONRA açıldı (listede olup henüz alınmamış adı biri kapmış olabilir) → hayır.
 *  'grant': evet.
 */
export function bootstrapDecision({ grantedTo = null, accountId, accountCreatedAt, firstListedAt }) {
  if (grantedTo) return grantedTo === accountId ? 'grant' : 'other';
  if (new Date(accountCreatedAt).getTime() >= new Date(firstListedAt).getTime()) return 'late';
  return 'grant';
}

// Hedef üzerinde işlem yetkisi:
//  - Yönetici (admin) hesabına HİÇBİR komut uygulanamaz (başka bir yönetici dahil).
//  - Yardımcı admine yalnızca yönetici işlem yapabilir.
//  - Yardımcı admin yalnızca normal kullanıcıları yönetir.
export function mayActOnUser(actorRole, targetRole, self = false) {
  if (self && actorRole === 'admin') return true; // yönetici kendi hesabını düzenleyebilir (ad, fotoğraf)
  if (targetRole === 'admin') return false;
  if (actorRole === 'admin') return true;
  if (actorRole === 'support') return targetRole === 'user';
  return false;
}
