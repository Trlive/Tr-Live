import { Router } from 'express';
import { query, tx } from '../database.js';
import { getConfig } from '../services/app_config.js';
import { requireAuth } from '../auth.js';
import { fail, uuid, positiveInt } from '../http.js';
import { userLimit } from '../firewall.js';
import { hub } from '../realtime.js';
import { cleanLine } from '../text_safety.js';
import { screenText } from '../services/moderation.js';
import { canManage } from '../room_permissions.js';
import { featuresFor } from '../services/wip.js';
import { noteTask } from '../services/daily.js';
import { loadPublicRow } from '../services/users.js';
import { roomStaffShield } from '../staff_logic.js';
import { publicUser, USER_PUBLIC_COLUMNS, USER_PUBLIC_JOINS, roomUser } from '../views.js';

export const router = Router();
router.use(requireAuth);

const MANAGERS = ['owner', 'cohost', 'moderator'];

async function roomAndMember(roomId, userId) {
  const room = (await query(`SELECT id, chat_enabled FROM rooms WHERE id = $1 AND is_active = TRUE`, [roomId])).rows[0];
  if (!room) throw fail('Oda bulunamadı.', 404);
  // Susturma odadan çıkıp girince kaybolmasın: kalıcı kayıt (room_mutes) ile üyelikteki süre birleştirilir.
  const member = (await query(
    `SELECT m.role, m.joined_at, GREATEST(m.chat_muted_until, mu.until) AS chat_muted_until
     FROM room_members m LEFT JOIN room_mutes mu ON mu.room_id = m.room_id AND mu.user_id = m.user_id
     WHERE m.room_id = $1 AND m.user_id = $2`, [roomId, userId])).rows[0];
  if (!member) throw fail('Önce odaya girin.', 403);
  return { room, member };
}

router.post('/:roomId/messages', userLimit('chat10s', 8, 10e3), userLimit('chat1m', 40, 60e3), async (req, res) => {
  const roomId = uuid(req.params.roomId, 'Oda');
  const { room, member } = await roomAndMember(roomId, req.user.id);
  if (room.chat_enabled === false && !MANAGERS.includes(member.role)) throw fail('Bu odada sohbet kapalı.', 403);
  if (member.chat_muted_until && new Date(member.chat_muted_until) > new Date()) throw fail('Bu odada sohbette susturuldunuz.', 403);

  const fly = req.body?.fly === true;
  const body = cleanLine(req.body?.text, fly ? 80 : 300);
  if (!body) throw fail('Mesaj boş olamaz.');
  // "Hoş geldin" mesajı: yeni gelen kişiye selam (odada uçan yazı olarak da görünür).
  let welcomeTo = null;
  if (req.body?.welcome != null) {
    const wid = uuid(req.body.welcome, 'Kullanıcı');
    if (wid === req.user.id) throw fail('Kendinize hoş geldin diyemezsiniz.');
    const w = await loadPublicRow(wid);
    if (!w) throw fail('Kullanıcı bulunamadı.', 404);
    welcomeTo = roomUser(w, null);
  }
  await screenText(req.user, body, 'room_chat');

  let balance = null;
  const insert = async (run) => (await run(
    `INSERT INTO room_messages(room_id, user_id, body, sender_hidden, sender_alias) VALUES($1,$2,$3,$4,$5) RETURNING id, created_at`,
    [roomId, req.user.id, body, Boolean(req.user.is_hidden), req.user.is_hidden ? (req.user.hidden_alias ?? null) : null],
  )).rows[0];
  let m;
  if (fly) {
    // Uçan yazı ücretli: Coin düşülür ve kayda geçer; mesaj aynı işlemde yazılır (yarım kalmaz).
    const cost = BigInt((await getConfig()).flyTextCoins ?? 0);
    m = await tx(async (c) => {
      if (cost > 0n) {
        const u = (await c.query(`UPDATE users SET coins = coins - $2, updated_at = NOW() WHERE id = $1 AND coins >= $2 RETURNING coins`, [req.user.id, cost.toString()])).rows[0];
        if (!u) throw fail(`Uçan yazı için ${cost} Coin gerekiyor.`, 402);
        balance = String(u.coins);
        await c.query(
          `INSERT INTO wallet_transactions(user_id, transaction_type, coin_amount, reference_id, description) VALUES($1,'fly_text',$2,$3,'Uçan yazı')`,
          [req.user.id, (-cost).toString(), roomId],
        );
      }
      return insert((sql, params) => c.query(sql, params));
    });
  } else {
    m = await insert(query);
  }
  const row = await loadPublicRow(req.user.id);
  const message = { id: m.id, roomId, user: roomUser(row, null), text: body, createdAt: m.created_at, fly, welcomeTo };
  hub.broadcastRoom(roomId, { type: 'room_message', ...message });
  noteTask(req.user.id, 'chat');
  res.status(201).json({ message, balance });
});

router.get('/:roomId/messages', async (req, res) => {
  const roomId = uuid(req.params.roomId, 'Oda');
  const { member } = await roomAndMember(roomId, req.user.id);
  const limit = req.query.limit ? positiveInt(req.query.limit, 'Limit', 100) : 50;
  // Yalnızca odaya girdiği andan sonraki mesajlar: girmeden önce konuşulanlar yeni gelene gösterilmez (herkes için aynı).
  const r = await query(
    `SELECT m.id AS message_id, m.body, m.created_at AS message_at, m.sender_hidden, m.sender_alias, ${USER_PUBLIC_COLUMNS}
     FROM room_messages m JOIN users u ON u.id = m.user_id ${USER_PUBLIC_JOINS}
     WHERE m.room_id = $1 AND m.deleted = FALSE AND m.created_at >= $3 ORDER BY m.created_at DESC LIMIT $2`,
    [roomId, limit, member.joined_at],
  );
  res.json({
    // Gönderirken gizliyse o anki gizli kimliğiyle; şu an gizliyse de maskeli (eski mesajlardan kim olduğu çıkarılamasın).
    messages: r.rows.reverse().map((x) => ({
      id: x.message_id, roomId, text: x.body, createdAt: x.message_at,
      user: roomUser(x.sender_hidden ? { ...x, is_hidden: true, hidden_alias: x.sender_alias } : x, req.user.id),
    })),
  });
});

// Sohbeti temizle: yalnızca oda sahibi, yardımcı sahip ve moderatör.
router.delete('/:roomId/messages', userLimit('chat_clear', 10, 60e3), async (req, res) => {
  const roomId = uuid(req.params.roomId, 'Oda');
  const { member } = await roomAndMember(roomId, req.user.id);
  if (!MANAGERS.includes(member.role)) throw fail('Sohbeti yalnızca oda yetkilileri temizleyebilir.', 403);
  const r = await query(`UPDATE room_messages SET deleted = TRUE WHERE room_id = $1 AND deleted = FALSE`, [roomId]);
  hub.broadcastRoom(roomId, { type: 'room_chat_cleared', roomId, by: req.user.id });
  res.json({ ok: true, cleared: r.rowCount });
});

router.delete('/:roomId/messages/:messageId', async (req, res) => {
  const roomId = uuid(req.params.roomId, 'Oda');
  const messageId = uuid(req.params.messageId, 'Mesaj');
  const { member } = await roomAndMember(roomId, req.user.id);
  const msg = (await query(`SELECT user_id FROM room_messages WHERE id = $1 AND room_id = $2 AND deleted = FALSE`, [messageId, roomId])).rows[0];
  if (!msg) throw fail('Mesaj bulunamadı.', 404);
  if (msg.user_id !== req.user.id && !MANAGERS.includes(member.role)) throw fail('Bu mesajı silme yetkiniz yok.', 403);
  await query(`UPDATE room_messages SET deleted = TRUE WHERE id = $1`, [messageId]);
  hub.broadcastRoom(roomId, { type: 'room_message_deleted', roomId, messageId });
  res.json({ ok: true });
});

// Sohbette susturma: 0 = susturmayı kaldır, en fazla 24 saat.
router.post('/:roomId/members/:userId/chat-mute', userLimit('moderate', 60, 60e3), async (req, res) => {
  const roomId = uuid(req.params.roomId, 'Oda');
  const targetId = uuid(req.params.userId, 'Kullanıcı');
  const minutes = Number(req.body?.minutes);
  if (!Number.isInteger(minutes) || minutes < 0 || minutes > 1440) throw fail('Süre 0-1440 dakika arasında olmalı.');
  if (targetId === req.user.id) throw fail('Kendinizi susturamazsınız.');
  const { member } = await roomAndMember(roomId, req.user.id);
  const target = (await query(`SELECT role FROM room_members WHERE room_id = $1 AND user_id = $2`, [roomId, targetId])).rows[0];
  if (!target) throw fail('Kullanıcı odada değil.', 404);
  if (!canManage(member.role, target.role, 'moderate')) throw fail('Bu işlem için yetkiniz yok.', 403);
  const shield = roomStaffShield(req.user.system_role, (await query(`SELECT system_role FROM users WHERE id = $1`, [targetId])).rows[0]?.system_role);
  if (shield) throw fail(shield, 403);
  if (member.role !== 'owner') {
    const f = await featuresFor(targetId);
    if (f.muteImmunity || f.kickImmunity) throw fail('Bu kullanıcı susturulamaz (WIP ayrıcalığı).', 403);
  }
  await query(
    `UPDATE room_members SET chat_muted_until = CASE WHEN $3::int = 0 THEN NULL ELSE NOW() + ($3::int * INTERVAL '1 minute') END WHERE room_id = $1 AND user_id = $2`,
    [roomId, targetId, minutes],
  );
  if (minutes === 0) await query(`DELETE FROM room_mutes WHERE room_id = $1 AND user_id = $2`, [roomId, targetId]);
  else await query(
    `INSERT INTO room_mutes(room_id, user_id, until) VALUES($1,$2, NOW() + ($3::int * INTERVAL '1 minute'))
     ON CONFLICT (room_id, user_id) DO UPDATE SET until = EXCLUDED.until`, [roomId, targetId, minutes]);
  hub.sendToUser(targetId, { type: 'room_chat_muted', roomId, minutes });
  res.json({ ok: true, minutes });
});
