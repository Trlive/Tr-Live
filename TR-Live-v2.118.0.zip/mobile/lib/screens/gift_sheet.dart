import 'dart:async';
import '../l10n/l10n.dart';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api.dart';
import '../services/media_cache.dart';
import '../services/session.dart';
import '../widgets/app_theme.dart';
import '../widgets/common.dart';
import '../widgets/lucky_win_fx.dart';
import 'misc_screens.dart';

/// Hediye gönderme penceresi (Figma): üstte alıcı avatarları, sekmeler, 4'lü hediye ızgarası, adet ve Gönder.
/// Tek kişi, birden çok kişi (her birine tam adet), "Tüm Koltuk" ve "Tüm Oda" seçilebilir.
Future<void> showGiftSheet(
  BuildContext context, {
  required String roomId,
  required List<Map<String, dynamic>> members,
  String? recipientId,
}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    // Arkası kararmaz: koltuklar ve reaksiyonlar hediye seçerken de görünür.
    barrierColor: Colors.transparent,
    builder: (c) => _GiftSheet(roomId: roomId, members: members, recipientId: recipientId),
  );
}

class _GiftSheet extends StatefulWidget {
  final String roomId;
  final List<Map<String, dynamic>> members;
  final String? recipientId;
  const _GiftSheet({required this.roomId, required this.members, this.recipientId});

  @override
  State<_GiftSheet> createState() => _GiftSheetState();
}

class _GiftSheetState extends State<_GiftSheet> with SingleTickerProviderStateMixin {
  static List<(String, String)> get _tabs => [('event', tx('Etkinlik')), ('popular', tx('Popüler')), ('lucky', tx('Şanslı')), ('cp', 'CP'), ('private', tx('Kişiye Özel')), ('vip', 'Vip')];
  static const _quantities = [1, 5, 10, 20, 50, 100, 500, 1000];
  // Şanslı hediyede Yoho / Tinni tarzı adetler (her adet ayrı çekiliş).
  static const _luckyQuantities = [1, 9, 19, 49, 99, 199, 520, 999];
  List<int> get _qtyOptions => _gift?['category'] == 'lucky' ? _luckyQuantities : _quantities;
  static const _perPage = 8;

  List<Map<String, dynamic>> _gifts = [];
  BigInt _globalMin = BigInt.from(1000);
  bool _loading = true;
  String? _error;
  Map<String, dynamic>? _gift;
  int _quantity = 1;
  String _tab = 'popular';
  int _page = 0;
  String? _scope; // null | 'mic' | 'room'
  bool _expanded = false;
  final Set<String> _picked = {};
  // Son gönderim (koltuk numaraları + hediye + kapsam): pencere yeniden açılınca aynı seçim hazır gelir.
  Map<String, dynamic>? _last;
  bool _sending = false;
  final _pages = PageController();
  // Combo (Yoho): gönderimden sonra 5 sn boyunca "Combo" düğmesi aynı hediyeyi tek dokunuşla tekrar gönderir.
  late final AnimationController _comboCtl;
  int _combo = 0;
  // Combo sırasında hızlı dokunuşlar kaybolmaz: gönderim sürerken gelen dokunuşlar sıraya alınır ve art arda gönderilir.
  int _queued = 0;
  // Ağ hatasında aynı işlem tekrar denenirse aynı anahtar kullanılır: sunucu ilk istek işlendiyse tekrar ödetmez.
  String? _pendingKey;
  String? _pendingSig;
  // Şanslı hediye: alıcı payı (baz puan) ve son kazanç bildirimi.
  int _luckyReceiverBps = 1000;
  List<int> _luckyMultipliers = const [1000, 500, 100, 50, 10, 5, 3, 2, 1];
  // Şanslı combo: son gönderimden sonra düğme bu kadar saniye açık kalır (sunucu combo penceresiyle aynı).
  int _luckyComboSec = 12;
  // Combo boyunca toplam kazanç ve kazanan adet (Yoho: "Combo toplamı").
  BigInt _luckyTotal = BigInt.zero;
  // Şanslı hediye olasılıkları (çarpan, olasılık 0–1) ve tek gönderimde en fazla kazanç (Coin). Kullanıcıya gösterilir.
  // (çarpan, olasılık, yalnızca büyük ödül havuzu doluyken mi)
  List<(int, double, bool)> _luckyOdds = const [];
  // Hediye başına büyük ödül havuzu: {giftId: {jackpot, openAt, open}} (Coin). Dolunca x100 ve üstü açılır.
  final Map<String, Map<String, dynamic>> _pools = {};
  String? _luckyMaxWin;
  Map<String, dynamic>? _luckyWin;
  int _luckySeq = 0;
  Timer? _luckyTimer;

  @override
  void initState() {
    super.initState();
    _comboCtl = AnimationController(vsync: this, duration: const Duration(seconds: 5))
      ..addStatusListener((st) {
        if (st == AnimationStatus.completed && mounted) {
          setState(() {
            _combo = 0;
            _luckyTotal = BigInt.zero;
          });
        }
      });
    final first = widget.recipientId ?? (_onMic.isNotEmpty ? _onMic.first['userId'] as String : (widget.members.isNotEmpty ? widget.members.first['userId'] as String : null));
    if (first != null) _picked.add(first);
    _expanded = first != null && !_onMic.any((m) => m['userId'] == first);
    _load();
  }

  static const _lastKey = 'gift_last_selection';

  Future<void> _loadLast() async {
    try {
      final raw = (await SharedPreferences.getInstance()).getString(_lastKey);
      if (raw != null) {
        final d = jsonDecode(raw);
        if (d is Map) _last = Map<String, dynamic>.from(d);
      }
    } catch (_) {}
  }

  Future<void> _saveLast(Map<String, dynamic> gift, List<String> targets) async {
    // Koltuktaki kişiler değişebileceği için kişi değil koltuk numarası saklanır.
    final seats = <int>[
      for (final id in targets)
        for (final m in widget.members)
          if (m['userId'] == id && m['microphone'] == true && m['seatIndex'] != null) (m['seatIndex'] as num).toInt(),
    ];
    _last = {'giftId': gift['id'], 'seats': seats, 'scope': _scope};
    try {
      await (await SharedPreferences.getInstance()).setString(_lastKey, jsonEncode(_last));
    } catch (_) {}
  }

  /// Kayıtlı son seçimi uygular: hediye (sekmesiyle) ve koltuklar. Koltuk boşaldıysa o koltuk atlanır.
  void _applyLast() {
    final l = _last;
    if (l == null) return;
    final g = _gifts.where((x) => '${x['id']}' == '${l['giftId']}').toList();
    if (g.isNotEmpty) {
      _tab = (g.first['category'] ?? 'popular').toString();
      _gift = g.first;
    }
    final scope = l['scope'];
    if (scope == 'mic' || scope == 'room') {
      _scope = scope as String;
      return;
    }
    final seats = (l['seats'] is List ? l['seats'] as List : const []).whereType<num>().map((e) => e.toInt()).toSet();
    final ids = [for (final m in _onMic) if (seats.contains((m['seatIndex'] as num).toInt())) m['userId'] as String];
    if (ids.isNotEmpty) {
      _picked
        ..clear()
        ..addAll(ids);
      _expanded = false;
    }
  }

  @override
  void dispose() {
    _luckyTimer?.cancel();
    _comboCtl.dispose();
    _pages.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await _loadLast();
      final r = await Api.get('/api/gifts');
      if (!mounted) return;
      setState(() {
        _gifts = listOf(r['gifts']);
        MediaCache.prefetch([for (final g in _tabGifts.take(16)) Api.absoluteUrl(g['animationUrl'] as String?)], first: true);
        _globalMin = BigInt.tryParse((r['globalMinCoins'] ?? '1000').toString()) ?? BigInt.from(1000);
        final lucky = mapOf(r['lucky']);
        _luckyReceiverBps = (lucky?['receiverBps'] as num?)?.toInt() ?? _luckyReceiverBps;
        final mult = lucky?['multipliers'];
        if (mult is List && mult.isNotEmpty) _luckyMultipliers = [for (final m in mult) if (m is num) m.toInt()];
        final odds = lucky?['odds'];
        if (odds is List) {
          _luckyOdds = [
            for (final o in odds)
              if (o is Map && o['multiplier'] is num && o['probability'] is num)
                ((o['multiplier'] as num).toInt(), (o['probability'] as num).toDouble(), o['jackpot'] == true),
          ];
        }
        final pools = lucky?['pools'];
        if (pools is List) {
          for (final p in pools) {
            if (p is Map && p['giftId'] != null) _pools['${p['giftId']}'] = Map<String, dynamic>.from(p);
          }
        }
        _luckyMaxWin = lucky?['maxWin']?.toString();
        _luckyComboSec = ((lucky?['comboSeconds'] as num?)?.toInt() ?? _luckyComboSec).clamp(3, 30);
        final shown = _tabGifts;
        if (shown.isEmpty) {
          // Boş sekmede takılı kalmamak için dolu ilk sekmeye geç.
          for (final t in _tabs) {
            if (_gifts.any((g) => (g['category'] ?? 'popular') == t.$1)) {
              _tab = t.$1;
              break;
            }
          }
        }
        _gift = _tabGifts.isNotEmpty ? _tabGifts.first : null;
        _applyLast();
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = errorText(e);
        _loading = false;
      });
    }
  }

  List<Map<String, dynamic>> get _tabGifts => _gifts.where((g) => (g['category'] ?? 'popular') == _tab).toList();

  List<Map<String, dynamic>> get _onMic {
    final l = widget.members.where((m) => m['microphone'] == true && m['seatIndex'] != null).toList();
    l.sort((a, b) => ((a['seatIndex'] as num).toInt()).compareTo((b['seatIndex'] as num).toInt()));
    return l;
  }

  /// Hediyeyi alacak kişilerin kimlikleri (seçime göre).
  List<String> get _targets {
    if (_scope == 'mic') return [for (final m in _onMic) if (m['userId'] != Session.id) m['userId'] as String];
    if (_scope == 'room') return [for (final m in widget.members) if (m['userId'] != Session.id) m['userId'] as String];
    return _picked.where((id) => widget.members.any((m) => m['userId'] == id)).toList();
  }

  BigInt get _total {
    final price = BigInt.tryParse((_gift?['coinPrice'] ?? '0').toString()) ?? BigInt.zero;
    return price * BigInt.from(_quantity) * BigInt.from(_targets.length);
  }

  Future<void> _send() async {
    final gift = _gift;
    if (gift == null) return;
    if (_sending) {
      if (_combo > 0 && _queued < 50) {
        setState(() => _queued++);
        _comboCtl.forward(from: 0);
      }
      return;
    }
    final targets = _targets;
    if (targets.isEmpty) return toast(context, _scope == null ? tx('Alıcı seçin.') : tx('Bu seçimde başka kimse yok.'), error: true);
    setState(() => _sending = true);
    final String dist = _scope == 'mic' ? 'all_mic' : (_scope == 'room' ? 'all_room' : (targets.length == 1 ? 'single' : 'each'));
    final body = <String, dynamic>{
      'giftId': gift['id'],
      'quantity': _quantity,
      'distribution': dist,
      if (dist == 'single') 'recipientId': targets.first,
      if (dist == 'each') 'recipientIds': targets,
    };
    final sig = jsonEncode(body);
    final key = (_pendingKey != null && _pendingSig == sig) ? _pendingKey! : Api.newIdempotencyKey();
    _pendingKey = key;
    _pendingSig = sig;
    Map<String, dynamic>? r;
    try {
      r = await Api.postOnce('/api/rooms/${widget.roomId}/gifts/send', body, key: key);
      _pendingKey = null; // sonuç kesin: sonraki dokunuş yeni işlem
    } catch (e) {
      // Anahtar yalnızca başarıda bırakılır. Sunucu hatalı isteğin anahtarını zaten siler; "işlem sürüyor" (409)
      // veya ağ hatasında aynı anahtarla tekrar denenmeli ki ilk istek işlendiyse ikinci kez ödenmesin.
      if (mounted) toast(context, errorText(e), error: true);
    }
    if (!mounted) return;
    setState(() => _sending = false);
    if (r == null) {
      setState(() => _queued = 0);
      return;
    }
    Session.setCoins((r['balance'] ?? Session.coins).toString());
    unawaited(_saveLast(gift, targets));
    // Pencere açık kalır (Yoho): combo düğmesi 5 sn (şanslı hediyede daha uzun) görünür, her dokunuşta süre yeniden başlar.
    final combo = (r['combo'] as num?)?.toInt() ?? 1;
    if (combo <= 1) _luckyTotal = BigInt.zero;
    setState(() => _combo = combo);
    _comboCtl.duration = gift['category'] == 'lucky' ? Duration(seconds: _luckyComboSec) : const Duration(seconds: 5);
    _comboCtl.forward(from: 0);
    final lucky = mapOf(r['lucky']);
    if (lucky != null) _showLucky(lucky);
    // Sıradaki combo dokunuşu.
    if (_queued > 0) {
      _queued--;
      scheduleMicrotask(_send);
    }
  }

  /// Şanslı hediye sonucu: kazanç varsa pencerede kısa bir kutlama, yoksa "Bu sefer çıkmadı".
  void _showLucky(Map<String, dynamic> lucky) {
    _luckyTimer?.cancel();
    setState(() {
      _luckyWin = lucky;
      _luckySeq++;
    });
    final w = BigInt.tryParse('${lucky['win'] ?? 0}') ?? BigInt.zero;
    final won = w > BigInt.zero;
    final pool = mapOf(lucky['pool']);
    if (pool != null && pool['giftId'] != null) _pools['${pool['giftId']}'] = pool;
    _luckyTotal += w;
    _luckyTimer = Timer(Duration(milliseconds: won ? 2600 : 1400), () {
      if (mounted) setState(() => _luckyWin = null);
    });
  }

  /// Şanslı hediye sonucu: kazançta büyük çarpan, coin ve kazanılan miktar (kutlama); boşta kısa not.
  /// Combo sürerken toplam kazanç da yazar (Yoho).
  Widget _luckyBanner() {
    final l = _luckyWin;
    if (l == null) return const SizedBox.shrink(key: ValueKey('none'));
    final win = BigInt.tryParse('${l['win'] ?? 0}') ?? BigInt.zero;
    final best = (l['best'] as num?)?.toInt() ?? 0;
    final wins = (l['wins'] as num?)?.toInt() ?? 0;
    final units = (l['units'] as num?)?.toInt() ?? 0;
    final won = win > BigInt.zero;
    final showTotal = _combo > 1 && _luckyTotal > win;
    final total = showTotal
        ? Text(tx('Combo toplamı: +{v1} Coin', {'v1': fmtNumber(_luckyTotal.toString())}),
            style: const TextStyle(color: Pal.gold, fontWeight: FontWeight.w800, fontSize: 11.5))
        : null;
    if (!won) {
      return Center(
        key: ValueKey(_luckySeq),
        child: Container(
          margin: const EdgeInsets.only(top: 6),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          decoration: BoxDecoration(
            color: Pal.surfaceHi.withValues(alpha: 0.94),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Pal.outline),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(tx('Bu sefer çıkmadı, şansını tekrar dene!'), style: const TextStyle(color: Pal.text, fontWeight: FontWeight.w700, fontSize: 13)),
            if (total != null) total,
          ]),
        ),
      );
    }
    final big = best >= 100;
    return Center(
      key: ValueKey(_luckySeq),
      child: Container(
        margin: const EdgeInsets.only(top: 4),
        padding: const EdgeInsets.fromLTRB(14, 8, 18, 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: big ? const [Pal.orange, Pal.amber, Color(0xFFFF3D8B)] : const [Pal.purple, Pal.amber]),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Pal.gold, width: 1.5),
          boxShadow: [BoxShadow(color: Pal.amber.withValues(alpha: big ? 0.7 : 0.45), blurRadius: 18)],
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.3, end: 1),
            duration: const Duration(milliseconds: 600),
            curve: Curves.elasticOut,
            builder: (_, k, child) => Transform.scale(scale: k, child: child),
            child: Image.asset('assets/images/lucky_coin.png', width: 44, height: 44),
          ),
          const SizedBox(width: 10),
          Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(
              'x$best',
              style: TextStyle(
                fontSize: big ? 30 : 24,
                height: 1.0,
                fontWeight: FontWeight.w900,
                fontStyle: FontStyle.italic,
                color: Colors.white,
                shadows: const [Shadow(color: Color(0xAA000000), blurRadius: 4)],
              ),
            ),
            if (l['jackpot'] == true)
              Text(tx('BÜYÜK ÖDÜL!'), style: const TextStyle(color: Pal.onBright, fontWeight: FontWeight.w900, fontSize: 12, letterSpacing: 0.6)),
            Text(tx('+{v1} Coin kazandın!', {'v1': fmtNumber(win.toString())}), style: const TextStyle(color: Pal.onBright, fontWeight: FontWeight.w900, fontSize: 13.5)),
            // Çok adetli gönderimde kaç adedin kazandırdığı (her adet ayrı çekiliş).
            if (units > 1 && wins > 0)
              Text(tx('{wins}/{units} adet kazandırdı', {'wins': wins, 'units': units}), style: const TextStyle(color: Pal.onBright, fontWeight: FontWeight.w700, fontSize: 11)),
            if (showTotal)
              Text(tx('Combo toplamı: +{v1} Coin', {'v1': fmtNumber(_luckyTotal.toString())}),
                  style: const TextStyle(color: Pal.onBright, fontWeight: FontWeight.w800, fontSize: 11.5)),
          ]),
        ]),
      ),
    );
  }

  String get _luckyShare {
    final pct = _luckyReceiverBps / 100;
    return _luckyReceiverBps % 100 == 0 ? pct.toStringAsFixed(0) : pct.toStringAsFixed(1);
  }

  /// Hediye, adet veya alıcı değişince combo biter (combo yalnızca aynı gönderimin tekrarıdır).
  void _stopCombo() {
    _queued = 0;
    _luckyTotal = BigInt.zero;
    if (_combo == 0) return;
    _comboCtl.stop();
    _combo = 0;
  }

  void _togglePerson(String id) {
    setState(() {
      _stopCombo();
      if (_scope != null) {
        // Toplu seçimden tek tek seçime geçerken seçili kişilerden başla.
        _picked
          ..clear()
          ..addAll(_targets);
        _scope = null;
      }
      if (!_picked.add(id)) _picked.remove(id);
    });
  }

  String _pct(double p) {
    final v = p * 100;
    final txt = v >= 1 ? v.toStringAsFixed(2) : (v >= 0.01 ? v.toStringAsFixed(3) : v.toStringAsFixed(4));
    return '%${txt.replaceAll('.', ',')}';
  }

  /// Şanslı hediye olasılık tablosu: her adet için çarpanların çıkma ihtimali. Büyük çarpanlar yalnızca o hediyenin
  /// büyük ödül havuzu doluyken çıkar; ödüller havuzdan ödenir (havuz yetmezse daha küçük çarpan verilir).
  Future<void> _showLuckyOdds() async {
    final gp = BigInt.tryParse((_gift?['coinPrice'] ?? '0').toString()) ?? BigInt.zero;
    final maxMult = gp >= BigInt.from(5000) ? 1000 : 500; // 5.000 Coin altı hediyeler en fazla x500
    final odds = [for (final o in _luckyOdds) if (o.$1 <= maxMult) o]..sort((a, b) => b.$1.compareTo(a.$1));
    final big = odds.where((o) => o.$3).toList();
    final small = odds.where((o) => !o.$3).toList();
    final none = 1 - small.fold<double>(0, (t, o) => t + o.$2);
    Widget row(String a, String b, {bool bold = false}) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(children: [
            Expanded(child: Text(a, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w700))),
            Text(b),
          ]),
        );
    Widget head(String t) => Padding(
          padding: const EdgeInsets.only(top: 10, bottom: 2),
          child: Text(t, style: const TextStyle(color: Pal.amber, fontWeight: FontWeight.w800, fontSize: 13)),
        );
    await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: Pal.surface,
        title: Text(tx('Kurallar')),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            for (final t in [
              tx('Şanslı hediye göndererek Coin kazanma şansı yakala; alıcı Elmas kazanır.'),
              tx('1000 kata kadar ödül: değeri 5.000 Coin altındaki hediyeler değerinin en fazla 500 katını, 5.000 Coin ve üstü hediyeler en fazla 1.000 katını kazandırır.'),
              tx('Büyük ödül havuzu dolunca x100 ve üstü çarpanlar açılır; ödüller havuzdan ödenir.'),
              tx('Ödüller rastgeledir; hediye göndermek kazanmayı garanti etmez. Ne kadar çok hediye, o kadar çok şans.'),
            ])
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Padding(padding: EdgeInsets.only(top: 6, right: 8), child: Icon(Icons.circle, size: 6, color: Color(0xFFFFD54F))),
                  Expanded(child: Text(t, style: const TextStyle(fontSize: 13, height: 1.35))),
                ]),
              ),
            const Divider(),
            Text(tx('Gönderdiğin her şanslı hediye adedi için ayrı bir çekiliş yapılır. Çıkan çarpan × hediye fiyatı kadar Coin hesabına eklenir.'),
                style: const TextStyle(fontSize: 13, height: 1.35)),
            const SizedBox(height: 6),
            Text(tx('Kazançlar ödül havuzundan ödenir: her gönderimin bir payı o hediyenin havuzuna girer. Havuz yetmezse daha küçük çarpan verilir.'),
                style: const TextStyle(fontSize: 12, height: 1.35, color: Pal.textDim)),
            const SizedBox(height: 6),
            Text(tx('Şanslı hediyenin değeri fiyatının %{luckyShare} kadarıdır: alıcıya bu kadar Elmas geçer; koltuk puanı, PK, sıralamalar ve seviyen de bu değerle sayılır.', {'luckyShare': _luckyShare}),
                style: const TextStyle(fontSize: 12, height: 1.35, color: Pal.textDim)),
            if (odds.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(tx('Olasılık bilgisi şu an alınamadı. Lütfen daha sonra tekrar dene.'), style: const TextStyle(fontSize: 13)),
              )
            else ...[
              if (big.isNotEmpty) ...[
                head(tx('Büyük ödül (havuz dolunca açılır)')),
                for (final o in big) row('x${o.$1} Coin', _pct(o.$2)),
              ],
              head(tx('Her zaman')),
              for (final o in small) row('x${o.$1} Coin', _pct(o.$2)),
              const Divider(),
              row(tx('Ödül çıkmaması'), _pct(none < 0 ? 0 : none), bold: true),
            ],
            const SizedBox(height: 12),
            Text(
              tx('Sonuçlar rastgeledir ve garanti edilmez. Kazanılan ödüller yalnızca Coin olarak verilir; nakde çevrilemez.') +
              '${_luckyMaxWin != null ? tx(' Tek gönderimde en fazla {v1} Coin kazanılabilir.', {'v1': fmtNumber(_luckyMaxWin)}) : ''}',
              style: const TextStyle(fontSize: 12, color: Colors.white60, height: 1.35),
            ),
          ]),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: Text(tx('Tamam')))],
      ),
    );
  }

  /// Seçili şanslı hediyenin büyük ödül havuzu: doluluk çubuğu; dolunca "AÇIK".
  Widget _luckyInfo() {
    final g = _gift;
    final pool = g != null && g['category'] == 'lucky' ? _pools['${g['id']}'] : null;
    if (pool == null) {
      return Text(
        tx('Her adet bir şans: x1 – x{v1} Coin geri kazan. Hediye değeri %{luckyShare} sayılır (Elmas, puan, sıralama).', {'v1': _luckyMultipliers.isEmpty ? 1000 : _luckyMultipliers.reduce(math.max), 'luckyShare': _luckyShare}),
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 11, color: Colors.white60, height: 1.25),
      );
    }
    final have = BigInt.tryParse('${pool['jackpot'] ?? 0}') ?? BigInt.zero;
    final need = BigInt.tryParse('${pool['openAt'] ?? 0}') ?? BigInt.zero;
    final open = pool['open'] == true || (need > BigInt.zero && have >= need);
    final frac = need <= BigInt.zero ? 1.0 : (have.toDouble() / need.toDouble()).clamp(0.0, 1.0);
    return Column(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Text(luckyEmojiOf(g?['name']?.toString()), style: const TextStyle(fontSize: 11)),
        const SizedBox(width: 4),
        Expanded(
          child: Text(
            open
                ? tx('Büyük ödül havuzu DOLU: x100 – x1000 açık! ({v1} Coin)', {'v1': fmtNumber(have.toString())})
                : tx('Büyük ödül havuzu: {v1} / {v2} Coin · dolunca x100+ açılır', {'v1': fmtNumber(have.toString()), 'v2': fmtNumber(need.toString())}),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 11, color: open ? Pal.gold : Colors.white70, fontWeight: open ? FontWeight.w800 : FontWeight.w600),
          ),
        ),
      ]),
      const SizedBox(height: 4),
      ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: Container(
          height: 6,
          color: Pal.surfaceHi,
          alignment: AlignmentDirectional.centerStart,
          child: FractionallySizedBox(
            widthFactor: frac,
            heightFactor: 1,
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: open ? const [Pal.orange, Pal.gold] : const [Pal.purple, Pal.amber]),
              ),
            ),
          ),
        ),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    return SafeArea(
      child: Container(
        // Sabit yükseklik, içeriğe göre hesaplanır (boşluk kalmaz): kişi satırı + sekmeler + 2 satır hediye + alt satır.
        // İçerik kaymaz, alttaki Coin / Gönder satırı her zaman görünür.
        height: _sheetHeight(mq) + mq.viewInsets.bottom,
        padding: EdgeInsets.fromLTRB(12, 10, 12, 8 + mq.viewInsets.bottom),
        decoration: const BoxDecoration(color: Color(0xFF0D1626), borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
        child: _loading
            ? const SizedBox(height: 220, child: Center(child: CircularProgressIndicator()))
            : _error != null
                ? SizedBox(height: 220, child: LoadError(message: _error!, onRetry: _load))
                : _body(),
      ),
    );
  }

  /// Pencere yüksekliği: üst/alt boşluk 18 + kişi satırı 52 + 6 + sekmeler 34 + 6 + ızgara + 4 + alt satır 36 (+ birkaç px pay).
  double _sheetHeight(MediaQueryData mq) {
    const gap = 8.0;
    final tileW = (mq.size.width - 24 - gap * 3) / 4;
    final grid = tileW * _tileRatio * 2 + gap + 14;
    // Kişi listesi açıldıysa (en fazla 112 px) fazlası kadar uzar; yatay ekranda üst sınır alt sınırın altına düşebilir.
    final maxH = mq.size.height * 0.6;
    final want = 162 + grid + (_expanded ? 60 : 0);
    return want.clamp(math.min(280.0, maxH), maxH).toDouble();
  }

  /// Hediye kutusu yüksekliği / genişliği.
  static const _tileRatio = 0.92;

  Widget _body() {
    // Kaydırma yok: kişi satırı, sekmeler ve alt satır sabit; hediye ızgarası kalan alanı doldurur.
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _recipientRow(),
        const SizedBox(height: 6),
        _tabRow(),
        const SizedBox(height: 6),
        // Şanslı sekmesinin açıklaması (yalnızca o sekmede yer kaplar).
        if (_tab == 'lucky') SizedBox(
          height: 30,
          child: Row(children: [
            Expanded(child: _luckyInfo()),
            // Olasılıklar: rastgele ödüllerin ihtimalleri açıkça gösterilir.
            InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: _showLuckyOdds,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.info_outline, size: 15, color: Color(0xFFFFD54F)),
                  SizedBox(width: 3),
                  Text(tx('Kurallar'), style: TextStyle(fontSize: 11, color: Color(0xFFFFD54F), fontWeight: FontWeight.w700)),
                ]),
              ),
            ),
          ]),
        ),
        // Şanslı hediye sonucu ızgaranın üstünde belirir (pencereyi büyütmez).
        Expanded(child: Stack(children: [
          Positioned.fill(child: ClipRect(child: _giftPages())),
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              transitionBuilder: (child, anim) => ScaleTransition(scale: anim, child: FadeTransition(opacity: anim, child: child)),
              child: _luckyBanner(),
            ),
          ),
        ])),
        const SizedBox(height: 4),
        _bottomRow(),
      ]);
  }

  // ---------- Alıcılar ----------
  Widget _person(Map<String, dynamic> m) {
    final id = m['userId'] as String;
    final selected = _scope == 'mic'
        ? (m['microphone'] == true && id != Session.id)
        : _scope == 'room'
            ? id != Session.id
            : _picked.contains(id);
    final seat = m['seatIndex'] == null ? null : (m['seatIndex'] as num).toInt() + 1;
    final name = (mapOf(m['user'])?['displayName'] ?? '').toString();
    return GestureDetector(
      onTap: () => _togglePerson(id),
      child: Padding(
        padding: const EdgeInsets.only(right: 8),
        child: SizedBox(
          width: 42,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: selected ? Pal.pink : Colors.transparent, width: 2.5)),
              child: UserAvatar(user: mapOf(m['user']), radius: 15),
            ),
            const SizedBox(height: 2),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              constraints: const BoxConstraints(maxWidth: 42),
              decoration: BoxDecoration(color: selected ? Pal.pink : Colors.white24, borderRadius: BorderRadius.circular(8)),
              child: Text(seat != null ? '$seat' : name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: Colors.white)),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _recipientRow() {
    final list = _expanded ? widget.members : _onMic;
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(
        child: list.isEmpty
            ? SizedBox(height: 52, child: Align(alignment: Alignment.centerLeft, child: Text(tx('Mikrofonda kimse yok. Ok ile odadakileri göster.'), style: TextStyle(color: Colors.white54, fontSize: 12))))
            : _expanded
                ? ConstrainedBox(
                    constraints: const BoxConstraints(maxHeight: 112),
                    child: SingleChildScrollView(child: Wrap(runSpacing: 6, children: [for (final m in list) _person(m)])),
                  )
                : SizedBox(height: 52, child: ListView(scrollDirection: Axis.horizontal, children: [for (final m in list) _person(m)])),
      ),
      const SizedBox(width: 4),
      InkWell(
        customBorder: const CircleBorder(),
        onTap: () => setState(() => _expanded = !_expanded),
        child: Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Pal.pink, width: 1.6)),
          child: Icon(_expanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, color: Colors.white),
        ),
      ),
    ]);
  }

  // ---------- Sekmeler ----------
  Widget _tabRow() {
    return Row(children: [
      for (final t in _tabs)
        Expanded(
          child: InkWell(
            onTap: () {
              setState(() {
                _stopCombo();
                _tab = t.$1;
                _page = 0;
                _gift = _tabGifts.isNotEmpty ? _tabGifts.first : null;
              });
              // Açılan sekmenin ilk hediyeleri önce iner.
              MediaCache.prefetch([for (final g in _tabGifts.take(16)) Api.absoluteUrl(g['animationUrl'] as String?)], first: true);
              if (_pages.hasClients) _pages.jumpToPage(0);
            },
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 6),
              decoration: BoxDecoration(border: Border(bottom: BorderSide(color: _tab == t.$1 ? Pal.pink : Colors.transparent, width: 2))),
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(t.$2, style: TextStyle(fontWeight: _tab == t.$1 ? FontWeight.w800 : FontWeight.w500, color: _tab == t.$1 ? Pal.pink : Colors.white70, fontSize: 14)),
              ),
            ),
          ),
        ),
      PopupMenuButton<String?>(
        tooltip: tx('Toplu seçim'),
        onSelected: (v) => setState(() {
          _stopCombo();
          _scope = v == _scope ? null : v;
        }),
        itemBuilder: (_) => [
          PopupMenuItem(value: 'mic', child: Text(tx('Tüm Koltuk'))),
          PopupMenuItem(value: 'room', child: Text(tx('Tüm Oda'))),
        ],
        child: Container(
          margin: const EdgeInsets.only(left: 6),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(border: Border.all(color: _scope == null ? Colors.white30 : Pal.pink), borderRadius: BorderRadius.circular(6)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Text(_scope == 'mic' ? tx('Tüm Koltuk') : (_scope == 'room' ? tx('Tüm Oda') : tx('Listele')), style: TextStyle(fontSize: 12, color: _scope == null ? Colors.white70 : Pal.pink)),
            const Icon(Icons.arrow_drop_down, size: 18, color: Colors.white70),
          ]),
        ),
      ),
    ]);
  }

  // ---------- Hediye ızgarası ----------
  Widget _giftPages() {
    final gifts = _tabGifts;
    final pageCount = (gifts.length / _perPage).ceil();
    return LayoutBuilder(builder: (context, box) {
      const gap = 8.0;
      final tileW = (box.maxWidth - gap * 3) / 4;
      // Kare görünüm; kalan yükseklik azsa (küçük ekran) satırlar sığacak kadar basıklaşır.
      final fitH = box.maxHeight.isFinite ? (box.maxHeight - 14 - gap) / 2 : tileW * _tileRatio;
      final tileH = math.min(tileW * _tileRatio, fitH).clamp(20.0, 400.0).toDouble();
      // Her sayfa ve sekme 2 satırlık yer kaplar (hediye az da olsa yok da olsa yükseklik aynı); sayfa noktaları için de yer ayrılır.
      if (gifts.isEmpty) {
        return SizedBox(height: tileH * 2 + gap + 14, child: Center(child: Text(tx('Bu sekmede hediye yok.'), style: TextStyle(color: Colors.white54))));
      }
      return Column(children: [
        SizedBox(
          height: tileH * 2 + gap,
          child: PageView.builder(
            controller: _pages,
            itemCount: pageCount,
            onPageChanged: (p) => setState(() => _page = p),
            itemBuilder: (_, p) {
              final slice = gifts.skip(p * _perPage).take(_perPage).toList();
              return Wrap(spacing: gap, runSpacing: gap, children: [for (final g in slice) SizedBox(width: tileW, height: tileH, child: _giftTile(g))]);
            },
          ),
        ),
        SizedBox(
          height: 14,
          child: pageCount > 1
              ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  for (var i = 0; i < pageCount; i++)
                    Container(margin: const EdgeInsets.symmetric(horizontal: 2.5), width: 6, height: 6, decoration: BoxDecoration(shape: BoxShape.circle, color: i == _page ? Colors.white : Colors.white30)),
                ])
              : null,
        ),
      ]);
    });
  }

  Widget _giftTile(Map<String, dynamic> g) {
    final selected = _gift?['id'] == g['id'];
    final price = BigInt.tryParse((g['coinPrice'] ?? '0').toString()) ?? BigInt.zero;
    final icon = Api.absoluteUrl(g['iconUrl'] as String?);
    final animated = (g['animationUrl'] ?? '').toString().isNotEmpty;
    return Semantics(
      button: true,
      selected: selected,
      label: '${g['name']} ${g['coinPrice']} Coin',
      child: GestureDetector(
        onTap: () => setState(() {
          if (_gift?['id'] != g['id']) _stopCombo();
          _gift = g;
        }),
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFF16233A),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: selected ? Pal.pink : Colors.transparent, width: 2),
          ),
          child: Stack(children: [
            Positioned.fill(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(6, 8, 6, 22),
                child: icon != null
                    ? NetImg(icon, fit: BoxFit.contain, errorBuilder: (_, __, ___) => _fallbackIcon(g))
                    : _fallbackIcon(g),
              ),
            ),
            Positioned(
              left: 5,
              top: 5,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (g['category'] == 'lucky') _badge(Icons.casino_outlined, const Color(0xFF00C853)),
                if (animated) _badge(Icons.auto_awesome, const Color(0xFF1FA2FF)),
                if (price >= _globalMin) ...[const SizedBox(height: 3), _badge(Icons.public, Pal.pink)],
              ]),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 4,
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const CircleAvatar(radius: 5.5, backgroundColor: Pal.amber),
                const SizedBox(width: 3),
                Flexible(child: FittedBox(fit: BoxFit.scaleDown, child: Text(_short(price), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white)))),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  /// Görseli olmayan hediye: şanslı hediyelerde çan/yonca, diğerlerinde hediye kutusu.
  Widget _fallbackIcon(Map<String, dynamic> g) {
    if (g['category'] != 'lucky') return const Icon(Icons.card_giftcard, color: Colors.white54, size: 34);
    final name = (g['name'] ?? '').toString().toLowerCase();
    final emoji = luckyEmojiOf(name);
    return FittedBox(child: Text(emoji, style: const TextStyle(fontSize: 40)));
  }

  Widget _badge(IconData icon, Color c) => Container(
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(5)),
        child: Icon(icon, size: 11, color: Colors.white),
      );

  String _short(BigInt v) {
    final million = BigInt.from(1000000);
    if (v >= million && v % million == BigInt.zero) return '${v ~/ million}M';
    return v.toString();
  }

  /// Combo düğmesi: kalan süre halkası + "COMBO xN" (dokununca aynı hediye tekrar gider).
  Widget _comboLabel() {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      SizedBox(
        width: 20,
        height: 20,
        child: AnimatedBuilder(
          animation: _comboCtl,
          builder: (_, __) => CircularProgressIndicator(value: 1 - _comboCtl.value, strokeWidth: 2.4, color: Colors.white, backgroundColor: Colors.white24),
        ),
      ),
      const SizedBox(width: 8),
      Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('COMBO', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 12, height: 1.0)),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 180),
          transitionBuilder: (child, anim) => ScaleTransition(scale: Tween<double>(begin: 1.6, end: 1).animate(anim), child: child),
          child: Text('x${_combo + _queued}', key: ValueKey(_combo + _queued), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15, height: 1.1)),
        ),
      ]),
    ]);
  }

  // ---------- Alt satır ----------
  Widget _bottomRow() {
    final n = _targets.length;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (n > 1 || _quantity > 1)
        SizedBox(
          height: 16,
          child: Text(tx('Toplam {v1} Coin · {n} kişi × {quantity} adet', {'v1': fmtNumber(_total.toString()), 'n': n, 'quantity': _quantity}), style: const TextStyle(fontSize: 11, color: Colors.white54)),
        ),
      Row(children: [
        Expanded(
          child: InkWell(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WalletScreen())),
            child: ValueListenableBuilder<Map<String, dynamic>?>(
              valueListenable: Session.me,
              builder: (_, me, __) => Row(children: [
                const CircleAvatar(radius: 11, backgroundColor: Pal.amber, child: Icon(Icons.star, size: 13, color: Colors.white)),
                const SizedBox(width: 6),
                Flexible(child: FittedBox(fit: BoxFit.scaleDown, child: Text('${fmtNumber(me?['coins'])}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)))),
                const Icon(Icons.chevron_right, size: 18),
              ]),
            ),
          ),
        ),
        Container(
          height: 36,
          decoration: BoxDecoration(border: Border.all(color: Pal.pink, width: 1.4), borderRadius: BorderRadius.circular(10)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            PopupMenuButton<int>(
              tooltip: tx('Adet'),
              onSelected: (v) => setState(() {
                if (v != _quantity) _stopCombo();
                _quantity = v;
              }),
              itemBuilder: (_) => [for (final q in _qtyOptions) PopupMenuItem(value: q, child: Text('$q'))],
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Row(mainAxisSize: MainAxisSize.min, children: [Text('$_quantity', style: const TextStyle(fontWeight: FontWeight.w700)), const Icon(Icons.keyboard_arrow_down, size: 18)]),
              ),
            ),
            InkWell(
              // Combo sürerken gönderim devam ederken de dokunulabilir (dokunuş sıraya alınır).
              onTap: (_gift == null || (_sending && _combo == 0)) ? null : _send,
              child: Container(
                height: 36,
                padding: EdgeInsets.symmetric(horizontal: _combo > 0 ? 12 : 22),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: _combo > 0 ? const [Pal.orange, Pal.pink] : const [Pal.purple, Pal.pink]),
                  borderRadius: const BorderRadius.horizontal(right: Radius.circular(9)),
                ),
                child: _combo > 0 ? _comboLabel() : (_sending
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(tx('Gönder'), style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15))),
              ),
            ),
          ]),
        ),
      ]),
    ]);
  }
}
