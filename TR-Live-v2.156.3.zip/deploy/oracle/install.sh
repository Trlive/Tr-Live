#!/usr/bin/env bash
# TR Live tek sunucu kurulumu (Oracle Cloud Always Free; Ubuntu 22.04/24.04 ya da Oracle Linux 9; ARM ya da x86).
# Kurar: Docker, güvenlik duvarı kuralları, PostgreSQL, uygulama sunucusu, LiveKit (ses/görüntü), Caddy (HTTPS),
# yönetim paneli (/panel), günlük yedek ve otomatik güncelleme (GitHub main dalı 5 dakikada bir kontrol edilir).
# Tekrar çalıştırmak güvenlidir: eksik olanı tamamlar, sırları ve veritabanını korur.
#
# Kullanım:  sudo PANEL_PASSWORD='harf-ve-rakam' bash install.sh   (ilk kurulum)
#            sudo bash install.sh --apply                          (ayarları uygula, yeniden başlat)
set -euo pipefail
export HOME=${HOME:-/root}
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

ROOT=/opt/trlive
SRC=$ROOT/src
ENVD=$ROOT/env
STATE=$ROOT/state
REPO=${TRLIVE_REPO:-https://github.com/Merdo2134/Tr-Live.git}
BRANCH=${TRLIVE_BRANCH:-main}
MODE=${1:-install}
PLACEHOLDER='BURAYA-EN-AZ-10-KARAKTER-SIFRE'
COMPOSE="docker compose -p trlive -f $SRC/deploy/oracle/compose.yml --env-file $ENVD/compose.env"

mkdir -p "$ENVD" "$STATE" "$ROOT/backups"
chmod 700 "$ENVD"
# Kayıt panelde de görünsün diye state/ altında.
exec > >(tee -a "$STATE/install.log") 2>&1
log() { echo "[trlive $(date '+%F %H:%M:%S')] $*"; }
console() { echo "$*" > /dev/console 2>/dev/null || true; echo "$*"; }
[ "$(id -u)" = 0 ] || { echo "root olarak çalıştırın (sudo)"; exit 1; }

# ---------- 1) Paketler (Ubuntu ya da Oracle Linux 9) ----------
if [ "$MODE" = install ]; then
  if command -v apt-get >/dev/null; then
    export DEBIAN_FRONTEND=noninteractive
    # İlk açılışta otomatik güncellemeler apt kilidini tutar: beklenir.
    echo 'DPkg::Lock::Timeout "900";' > /etc/apt/apt.conf.d/99trlive
    for _ in $(seq 1 180); do
      fuser /var/lib/dpkg/lock-frontend /var/lib/apt/lists/lock >/dev/null 2>&1 || break
      sleep 5
    done
    log "Paketler kuruluyor (Ubuntu)"
    apt-get update -qq
    apt-get install -y -qq git curl ca-certificates psmisc >/dev/null
    if ! command -v docker >/dev/null; then
      log "Docker kuruluyor"
      curl -fsSL --retry 5 https://get.docker.com | sh >/dev/null
    fi
  elif command -v dnf >/dev/null; then
    log "Paketler kuruluyor (Oracle Linux)"
    dnf -y -q install git curl ca-certificates psmisc dnf-plugins-core >/dev/null
    if ! command -v docker >/dev/null; then
      log "Docker kuruluyor"
      dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo >/dev/null
      dnf -y -q install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin >/dev/null
    fi
    # SELinux, konteynerlerin ayar dosyalarını okumasını engellemesin.
    if command -v setenforce >/dev/null; then
      setenforce 0 2>/dev/null || true
      sed -i 's/^SELINUX=enforcing/SELINUX=permissive/' /etc/selinux/config 2>/dev/null || true
    fi
  else
    log "HATA: desteklenmeyen işletim sistemi (Ubuntu ya da Oracle Linux 9 gerekli)"; exit 1
  fi
  systemctl enable --now docker >/dev/null
  # Derleme sırasında bellek yetmezse diye 2 GB takas alanı.
  if ! swapon --show | grep -q /swapfile; then
    { fallocate -l 2G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=2048 status=none; } && chmod 600 /swapfile && mkswap /swapfile >/dev/null && swapon /swapfile
    grep -q /swapfile /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
  fi
fi

# ---------- 2) Kaynak kod ----------
if [ "$MODE" = install ] || [ ! -d "$SRC/.git" ]; then
  if [ -d "$SRC/.git" ]; then
    git -C "$SRC" fetch -q --depth 1 origin "$BRANCH" && git -C "$SRC" reset -q --hard "origin/$BRANCH"
  else
    log "Kod indiriliyor: $REPO"
    git clone -q --depth 1 -b "$BRANCH" "$REPO" "$SRC"
  fi
fi

# ---------- 3) Güvenlik duvarı (her açılışta trlive-firewall servisi de çalıştırır) ----------
bash "$SRC/deploy/oracle/firewall.sh"

# ---------- 4) Sırlar (bir kez üretilir, sonra korunur) ----------
rnd() { tr -dc 'A-Za-z0-9' < /dev/urandom 2>/dev/null | head -c "$1" || true; }
if [ ! -f "$ENVD/secrets.env" ]; then
  log "Sırlar üretiliyor"
  cat > "$ENVD/secrets.env" <<EOF
POSTGRES_PASSWORD=$(rnd 32)
JWT_SECRET=$(rnd 48)
LIVEKIT_API_KEY=API$(rnd 12)
LIVEKIT_API_SECRET=$(rnd 40)
EOF
fi
if [ ! -f "$ENVD/panel.env" ]; then
  PW=${PANEL_PASSWORD:-}
  if [ ${#PW} -lt 10 ] || [ "$PW" = "$PLACEHOLDER" ] || ! [[ $PW =~ ^[A-Za-z0-9._@%+=:,!-]+$ ]]; then
    PW=$(rnd 16)
    console "=================================================================="
    console "TR LIVE PANEL SIFRESI (cloud-init sifresi uygun degildi): $PW"
    console "=================================================================="
  fi
  printf "PANEL_PASSWORD='%s'\n" "$PW" > "$ENVD/panel.env"
fi
touch "$ENVD/extra.env"
# Web panel kapıları (v2.153.1): her panelin kuruluma özel, tahmin edilemez giriş bağlantısı. Bağlantıyla gelmeyen kişiye
# /yonetim/admin, /yonetim/agency, /yonetim/dealer sayfaları "bulunamadı" (404) döner. Sunucu panelindeki "Bağlantıları
# yenile" dosyayı siler; burada yenileri üretilir (eski bağlantılar ve eski tarayıcı izinleri geçersiz olur).
gate_ok() { [[ ${1:-} =~ ^[A-Za-z0-9]{24,64}$ ]]; }
if [ -f "$ENVD/gates.env" ]; then
  # shellcheck disable=SC1091
  set -a; . "$ENVD/gates.env"; set +a
fi
if ! gate_ok "${GATE_ADMIN:-}" || ! gate_ok "${GATE_AGENCY:-}" || ! gate_ok "${GATE_DEALER:-}"; then
  log "Panel giriş bağlantıları üretiliyor"
  GATE_ADMIN=$(rnd 32); GATE_AGENCY=$(rnd 28); GATE_DEALER=$(rnd 28)
  printf "GATE_ADMIN='%s'\nGATE_AGENCY='%s'\nGATE_DEALER='%s'\n" "$GATE_ADMIN" "$GATE_AGENCY" "$GATE_DEALER" > "$ENVD/gates.env"
fi
gate_ok "$GATE_ADMIN" && gate_ok "$GATE_AGENCY" && gate_ok "$GATE_DEALER" || { log "HATA: panel giriş bağlantıları üretilemedi"; exit 1; }
chmod 600 "$ENVD"/*.env
# shellcheck disable=SC1091
set -a; . "$ENVD/secrets.env"; set +a

# ---------- 5) Alan adı ----------
# sslip.io adı her zaman sunulur (kendi alan adı eklense bile panel ve uygulama bu adresle de çalışır).
if [ ! -s "$ENVD/sslip" ]; then
  IP=""
  for u in https://api.ipify.org https://ifconfig.me/ip https://icanhazip.com; do
    IP=$(curl -fsS --max-time 10 "$u" 2>/dev/null | tr -d ' \n\r' || true)
    [[ $IP =~ ^[0-9]+(\.[0-9]+){3}$ ]] && break
    IP=""
  done
  [ -n "$IP" ] || { log "HATA: sunucunun genel IP adresi bulunamadı"; exit 1; }
  echo "$(echo "$IP" | tr . -).sslip.io" > "$ENVD/sslip"
fi
SSLIP=$(tr -d ' \n\r' < "$ENVD/sslip")
[ -s "$ENVD/domain" ] || echo "$SSLIP" > "$ENVD/domain"
DOMAIN=$(tr -d ' \n\r' < "$ENVD/domain")
log "Adres: https://$DOMAIN  (LiveKit: wss://lk.$DOMAIN)"

# Sunucu ayarları (her çalıştırmada yeniden yazılır; panelden girilenler extra.env'de kalır). Değerler tek tırnaklı:
# docker compose içlerindeki $ ve # işaretlerini yorumlamasın.
cat > "$ENVD/stack.env" <<EOF
NODE_ENV='production'
PORT='3000'
DATABASE_URL='postgresql://trlive:${POSTGRES_PASSWORD}@postgres:5432/trlive'
DATABASE_SSL='false'
# Tek sunucuda PostgreSQL max_connections=100: 5'lik varsayılan havuz canlı yayın yükünde sorguları sıraya sokar. extra.env'deki değer bunu ezer.
DATABASE_POOL_MAX='20'
JWT_SECRET='${JWT_SECRET}'
LIVEKIT_URL='wss://lk.${DOMAIN}'
LIVEKIT_API_URL='http://host.docker.internal:7880'
LIVEKIT_API_KEY='${LIVEKIT_API_KEY}'
LIVEKIT_API_SECRET='${LIVEKIT_API_SECRET}'
TRUST_PROXY='1'
# Tarayıcıdan API'ye istek atabilecek adresler. '*' üretimde kabul edilmiyor (denetim S-05).
CORS_ORIGIN='https://${DOMAIN}'
PUBLIC_BASE_URL='https://${DOMAIN}'
UPLOAD_DIR='/app/uploads'
# Ajans ve bayi giriş bağlantıları: yönetim panelinde "bağlantıyı kopyala" için. Yönetim bağlantısı YALNIZCA giriş yapmış süper
# yöneticiye (uygulamada Ayarlar → Web yönetim paneli) verilir: sunucu paneli şifresi unutulursa web paneline erişim kesilmesin.
PANEL_LINK_ADMIN='https://${DOMAIN}/${GATE_ADMIN}'
PANEL_LINK_AGENCY='https://${DOMAIN}/${GATE_AGENCY}'
PANEL_LINK_DEALER='https://${DOMAIN}/${GATE_DEALER}'
EOF
printf "POSTGRES_PASSWORD='%s'\nDOMAIN='%s'\nSSLIP='%s'\n" "$POSTGRES_PASSWORD" "$DOMAIN" "$SSLIP" > "$ENVD/compose.env"
chmod 600 "$ENVD"/*.env

# Sunucunun genel IP'si (sslip adından): LiveKit telefonlara bu adresi bildirir. Dış IP'yi her açılışta STUN ile
# aramak yerine sabit yazmak, "Ses/görüntü bağlanamadı (Timeout)" hatasının sık bir sebebini ortadan kaldırır.
PUBIP=$(echo "$SSLIP" | sed -e 's/\.sslip\.io$//' -e 's/-/./g')
LK_OLD=$(md5sum "$ENVD/livekit.yaml" 2>/dev/null | cut -d' ' -f1)
cat > "$ENVD/livekit.yaml" <<EOF
port: 7880
bind_addresses: ["0.0.0.0"]
rtc:
  tcp_port: 7881
  # Tüm medya tek UDP portundan (7882): güvenlik duvarında tek kural yeter.
  udp_port: 7882
  node_ip: ${PUBIP}
  use_external_ip: false
keys:
  ${LIVEKIT_API_KEY}: ${LIVEKIT_API_SECRET}
# Katılım ve yayın olayları uygulama sunucusuna bildirilir: izinsiz yayın (koltukta değil / susturulmuş) kesilir,
# odadan atılan katılımcı çıkarılır (backend/src/modules/rooms/livekit_webhook.routes.js). İstekler bu anahtarla imzalanır.
webhook:
  api_key: ${LIVEKIT_API_KEY}
  urls:
    - http://127.0.0.1:3000/livekit/webhook
logging:
  level: warn
EOF

# Ayrı Coin yükleme sitesi (v2.154.0, isteğe bağlı): sunucu panelinde PAY_DOMAIN (ör. odeme.alanadi.com) yazılırsa o adres
# YALNIZCA web yükleme sayfasını sunar (kök → /pay); panel, API ve diğer her şey orada 404. Alan adının DNS kaydı bu sunucuyu göstermeli.
PAY_DOMAIN=$( (grep -E "^PAY_DOMAIN=" "$ENVD/extra.env" 2>/dev/null || true) | tail -n 1 | cut -d= -f2- | tr -d "'\" \r\n" | tr 'A-Z' 'a-z')
if ! [[ $PAY_DOMAIN =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$ ]] || [ "$PAY_DOMAIN" = "$DOMAIN" ] || [ "$PAY_DOMAIN" = "$SSLIP" ]; then
  [ -n "$PAY_DOMAIN" ] && log "PAY_DOMAIN geçersiz ya da ana adresle aynı: $PAY_DOMAIN (yok sayıldı)"
  PAY_DOMAIN=""
fi
HOSTS="$SSLIP"; LKHOSTS="lk.$SSLIP"
if [ "$DOMAIN" != "$SSLIP" ]; then HOSTS="$SSLIP, $DOMAIN"; LKHOSTS="lk.$SSLIP, lk.$DOMAIN"; fi
cat > "$ENVD/Caddyfile" <<EOF
$HOSTS {
  encode gzip
  handle /panel* {
    reverse_proxy 127.0.0.1:8090
  }
  # ---- Web panel kapıları ----
  # Giriş bağlantısı (https://ALAN/<gizli>) tarayıcıya o panele özel bir izin çerezi bırakır ve giriş sayfasını açar.
  # Çerezi olmayan kişi panel sayfalarını göremez: 404 (panelin var olduğu bile anlaşılmaz). Çerez yalnızca o panelin
  # yoluna gider (Path), JavaScript okuyamaz (HttpOnly), başka siteden gönderilmez (SameSite). Asıl koruma yine şifre + sunucu yetkisidir.
  @gate_admin path /${GATE_ADMIN} /${GATE_ADMIN}/
  handle @gate_admin {
    header +Set-Cookie "trg_a=${GATE_ADMIN}; Path=/yonetim/admin; Max-Age=31536000; Secure; HttpOnly; SameSite=Lax"
    header Cache-Control "no-store"
    redir * /yonetim/admin/login/ 302
  }
  @gate_agency path /${GATE_AGENCY} /${GATE_AGENCY}/
  handle @gate_agency {
    header +Set-Cookie "trg_g=${GATE_AGENCY}; Path=/yonetim/agency; Max-Age=31536000; Secure; HttpOnly; SameSite=Lax"
    header Cache-Control "no-store"
    redir * /yonetim/agency/login/ 302
  }
  @gate_dealer path /${GATE_DEALER} /${GATE_DEALER}/
  handle @gate_dealer {
    header +Set-Cookie "trg_d=${GATE_DEALER}; Path=/yonetim/dealer; Max-Age=31536000; Secure; HttpOnly; SameSite=Lax"
    header Cache-Control "no-store"
    redir * /yonetim/dealer/login/ 302
  }
  @no_admin {
    path /yonetim/admin /yonetim/admin/*
    not header_regexp Cookie (^|;\s*)trg_a=${GATE_ADMIN}(;|$)
  }
  @no_agency {
    path /yonetim/agency /yonetim/agency/*
    not header_regexp Cookie (^|;\s*)trg_g=${GATE_AGENCY}(;|$)
  }
  @no_dealer {
    path /yonetim/dealer /yonetim/dealer/*
    not header_regexp Cookie (^|;\s*)trg_d=${GATE_DEALER}(;|$)
  }
  # Eski panel seçim sayfası kaldırıldı: /yonetim kökü de yok sayılır.
  @no_root path /yonetim /yonetim/ /yonetim/index.html /yonetim/index.txt
  handle @no_admin {
    respond 404
  }
  handle @no_agency {
    respond 404
  }
  handle @no_dealer {
    respond 404
  }
  handle @no_root {
    respond 404
  }
  # Yönetim / ajans / bayi paneli (yalnızca kapıdan gelenler) ve tanıtım sitesi. /yonetim/m/* uygulama içi sayfalardır, açık.
  @web path /yonetim /yonetim/* / /index.html /privacy.html /terms.html /kvkk.html /community.html /child-safety.html /contact.html /assets/*
  handle @web {
    reverse_proxy 127.0.0.1:8091
  }
  handle {
    reverse_proxy 127.0.0.1:3000
  }
}
$LKHOSTS {
  reverse_proxy 127.0.0.1:7880
}
EOF
if [ -n "$PAY_DOMAIN" ]; then
  cat >> "$ENVD/Caddyfile" <<EOF
$PAY_DOMAIN {
  encode gzip
  @root path /
  rewrite @root /pay
  @pay path /pay /pay/*
  handle @pay {
    reverse_proxy 127.0.0.1:3000
  }
  handle {
    respond 404
  }
}
EOF
  log "Ayrı yükleme sitesi: https://$PAY_DOMAIN"
fi

# ---------- Uzak yedek (isteğe bağlı) ----------
# Panelde "Uzak yedek" girildiyse gece yedeğinin uzak kopyası için rclone gerekir (backup.sh). Girilmediyse hiçbir şey yapılmaz.
if grep -qE "^BACKUP_REMOTE=.+" "$ENVD/extra.env" 2>/dev/null && ! command -v rclone >/dev/null 2>&1; then
  log "Uzak yedek için rclone kuruluyor"
  apt-get install -y rclone >/dev/null 2>&1 || log "UYARI: rclone kurulamadı; uzak yedek çalışmayacak (gece yedeği günlüğünde görünür)."
fi

# ---------- TURN (varsayılan AÇIK; kapatmak için extra.env'e TURN_ENABLED=0) ----------
# Bazı Wi-Fi ve operatör ağları ses/görüntünün kullandığı UDP kapısını (7882) keser. TURN, medyayı TLS ile sarılı ek bir
# yoldan (5349/tcp; yedek olarak 3478/udp) geçirir. Panelde ayar YOKTUR; sertifika alınabiliyorsa kendiliğinden devreye girer.
# Ad: turn.<ip-tireli>.sslip.io. sslip.io joker adı sunucunun IP'sine kendiliğinden çözüldüğü için, kendi alan adın olsun
# olmasın ek DNS kaydı GEREKMEZ. Sertifikayı Caddy alır; LiveKit onu salt okunur bağlanmış Caddy veri klasöründen okur.
# Güvence: sertifika yoksa TURN yazılmaz; TURN'lü ayarla ses sunucusu açılmazsa TURN'süz ayara dönülür ve (sonsuz yeniden
# başlatma olmasın diye) state/turn-failed dosyası silinene kadar bir daha denenmez.
# <turn-helpers>
turn_requested() {   # $1 = extra.env yolu; TURN açık mı? Varsayılan EVET; yalnızca TURN_ENABLED=0 yazılıysa hayır.
  ! grep -qE "^TURN_ENABLED=['\"]?0['\"]?[[:space:]]*\$" "$1" 2>/dev/null
}
turn_cert_path() {   # $1 = Caddy veri klasörünün ana makinedeki yolu, $2 = ad → LiveKit konteynerindeki .crt yolu (yoksa boş)
  local vol=$1 host=$2 crt
  [ -n "$vol" ] && [ -d "$vol/caddy/certificates" ] || return 0
  crt=$(find "$vol/caddy/certificates" -type f -path "*/$host/$host.crt" 2>/dev/null | head -n 1 || true)
  if [ -n "$crt" ] && [ -s "$crt" ] && [ -s "${crt%.crt}.key" ]; then echo "/caddy-data${crt#"$vol"}"; fi
  return 0
}
turn_block() {       # $1 = ad, $2 = konteynerdeki .crt yolu
  printf 'turn:\n  enabled: true\n  domain: %s\n  tls_port: 5349\n  udp_port: 3478\n  cert_file: %s\n  key_file: %s\n' "$1" "$2" "${2%.crt}.key"
}
# </turn-helpers>
caddy_vol() { docker volume inspect -f '{{.Mountpoint}}' trlive_caddy_data 2>/dev/null || true; }

TURN_HOST="turn.$SSLIP"
TURN_ON=0; TURN_ACTIVE=0; LK_RESTARTED=0; CERT=""
if turn_requested "$ENVD/extra.env"; then
  if [ -e "$STATE/turn-failed" ]; then
    log "TURN daha önce açılamadı, kapalı tutuluyor (yeniden denemek için sunucuda $STATE/turn-failed dosyasını silin; KURULUM.md 6)."
  else
    TURN_ON=1
  fi
else
  rm -f "$STATE/turn-failed" "$STATE/turn-cert.md5"
fi
cp "$ENVD/livekit.yaml" "$ENVD/livekit.yaml.noturn"   # geri dönüş kopyası: TURN'süz ayar
if [ "$TURN_ON" = 1 ]; then
  printf '%s {\n  respond "TURN" 200\n}\n' "$TURN_HOST" >> "$ENVD/Caddyfile"   # Caddy bu ad için sertifika alsın
  CERT=$(turn_cert_path "$(caddy_vol)" "$TURN_HOST")
  if [ -n "$CERT" ]; then
    turn_block "$TURN_HOST" "$CERT" >> "$ENVD/livekit.yaml"; TURN_ACTIVE=1
  else
    log "TURN: sertifika henüz yok (Caddy $TURN_HOST için alıyor); kurulum sonunda beklenecek."
  fi
fi

# ---------- 6) Başlat ----------
FREE_KB=$(df -Pk / | awk 'NR==2{print $4}')
log "Boş disk: $((FREE_KB / 1024)) MB"
if [ "${FREE_KB:-0}" -lt 5000000 ]; then
  log "Disk az: eski derleme artıkları temizleniyor"
  docker builder prune -af >/dev/null 2>&1 || true
  docker image prune -af >/dev/null 2>&1 || true
  log "Temizlikten sonra boş disk: $(( $(df -Pk / | awk 'NR==2{print $4}') / 1024 )) MB"
fi
mkdir -p "$STATE"
[ -e "$STATE/git-token" ] || install -m 622 /dev/null "$STATE/git-token" 2>/dev/null || true
[ "$(stat -c %a "$STATE/update" 2>/dev/null)" = 666 ] || { systemctl stop trlive-apply.path 2>/dev/null; touch "$STATE/update" && chmod 666 "$STATE/update"; systemctl start trlive-apply.path 2>/dev/null; } || true
# Caddy ayarı devreye girmeden ÖNCE doğrulanır (panel kapıları v2.153.1 ile ayar büyüdü): geçersizse son çalışan ayar
# geri konur, site kapanmaz. İlk kurulumda doğrulanmış kopya yoksa ayar olduğu gibi denenir.
if docker run --rm -v "$ENVD/Caddyfile:/etc/caddy/Caddyfile:ro" caddy:2 caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile >"$STATE/caddy-validate.log" 2>&1; then
  cp "$ENVD/Caddyfile" "$ENVD/Caddyfile.ok"
else
  log "HATA: yeni Caddy ayarı geçersiz (ayrıntı: $STATE/caddy-validate.log); son çalışan ayar kullanılıyor"
  tail -n 5 "$STATE/caddy-validate.log" 2>/dev/null | sed 's/^/    /' || true
  [ -f "$ENVD/Caddyfile.ok" ] && cp "$ENVD/Caddyfile.ok" "$ENVD/Caddyfile"
fi
log "Servisler derleniyor ve başlatılıyor (ilk seferde birkaç dakika sürer)"
$COMPOSE up -d --build --remove-orphans
if [ "$MODE" = --apply ]; then
  # Ayar dosyası değişince Caddy yeniden okusun. Uygulama sunucusu yalnızca panelden "Kaydet ve uygula" ile yeniden
  # başlatılır; GitHub güncellemesinde imaj değiştiyse compose zaten yeniler (her yüklemede gereksiz kesinti olmasın).
  $COMPOSE exec -T caddy caddy reload --config /etc/caddy/Caddyfile --adapter caddyfile >/dev/null 2>&1 || $COMPOSE restart caddy
  if [ "${TRLIVE_FROM_PANEL:-0}" = 1 ]; then $COMPOSE restart backend; fi
fi
# LiveKit ayarı değiştiyse ses sunucusu yeniden okusun.
if [ -n "$LK_OLD" ] && [ "$(md5sum "$ENVD/livekit.yaml" | cut -d' ' -f1)" != "$LK_OLD" ]; then
  log "LiveKit ayarı değişti, ses sunucusu yeniden başlatılıyor"
  $COMPOSE restart livekit
  LK_RESTARTED=1
fi

# TURN: sertifika, Caddy yeni ada göre yeniden okuyunca gelir. İlk açılışta en çok 90 sn beklenir, gelirse etkinleştirilir.
if [ "$TURN_ON" = 1 ] && [ "$TURN_ACTIVE" = 0 ]; then
  if [ -n "$(find "$STATE/turn-cert-timeout" -mmin -360 2>/dev/null)" ]; then
    # Sertifika yakın zamanda alınamadıysa her güncellemede 90 sn bekleyip kurulumu yavaşlatma.
    log "TURN: sertifika son 6 saatte alınamamıştı; bu turda beklenmiyor."
  else
    for _ in $(seq 1 18); do
      CERT=$(turn_cert_path "$(caddy_vol)" "$TURN_HOST")
      if [ -n "$CERT" ]; then break; fi
      sleep 5
    done
    if [ -n "$CERT" ]; then
      rm -f "$STATE/turn-cert-timeout"
      turn_block "$TURN_HOST" "$CERT" >> "$ENVD/livekit.yaml"; TURN_ACTIVE=1
      log "TURN etkinleştiriliyor (ses sunucusu yeniden başlatılıyor)"
      $COMPOSE restart livekit
      LK_RESTARTED=1
    else
      touch "$STATE/turn-cert-timeout"
      log "TURN sertifikası 90 sn içinde alınamadı; TURN kapalı kaldı (80/443 portlarını kontrol edin; 6 saat sonra yeniden denenir)."
    fi
  fi
fi
# Sertifika yenilenince (Caddy yaklaşık 60 günde bir) LiveKit eskisini bellekte tutar: değiştiyse yeniden başlat.
if [ "$TURN_ACTIVE" = 1 ] && [ "$LK_RESTARTED" = 0 ] && [ -n "$CERT" ]; then
  CRT_MD5=$(md5sum "$(caddy_vol)${CERT#/caddy-data}" 2>/dev/null | cut -d' ' -f1 || true)
  if [ -n "$CRT_MD5" ] && [ -f "$STATE/turn-cert.md5" ] && [ "$(cat "$STATE/turn-cert.md5")" != "$CRT_MD5" ]; then
    log "TURN sertifikası yenilendi; ses sunucusu yeniden başlatılıyor"
    $COMPOSE restart livekit
    LK_RESTARTED=1
  fi
  if [ -n "$CRT_MD5" ]; then echo "$CRT_MD5" > "$STATE/turn-cert.md5"; echo "$(caddy_vol)${CERT#/caddy-data}" > "$STATE/turn-cert.host"; fi
fi
# Güvence: TURN'lü ayarla ses sunucusu açılmadıysa TURN'süz ayara dön (ses/görüntü kesintide kalmasın).
if [ "$TURN_ACTIVE" = 1 ] && [ "$LK_RESTARTED" = 1 ]; then
  sleep 10
  LKID=$($COMPOSE ps -q livekit 2>/dev/null | head -n 1 || true)
  LKSTATE=$(docker inspect -f '{{.State.Running}} {{.State.Restarting}}' "$LKID" 2>/dev/null || echo "false true")
  if [ "$LKSTATE" != "true false" ]; then
    log "UYARI: TURN'lü ayarla ses sunucusu açılmadı; TURN'süz ayara dönülüyor. TURN kapalı kaldı."
    cp "$ENVD/livekit.yaml.noturn" "$ENVD/livekit.yaml"
    $COMPOSE restart livekit
    touch "$STATE/turn-failed"
    TURN_ACTIVE=0
  fi
fi
docker image prune -f >/dev/null 2>&1 || true

# ---------- 7) Otomatik güncelleme, panel istekleri, yedek, güvenlik duvarı ----------
if [ "$MODE" = install ]; then
  unit() { cat > "/etc/systemd/system/$1"; }
  unit trlive-firewall.service <<EOF
[Unit]
Description=TR Live güvenlik duvarı kuralları
After=docker.service firewalld.service netfilter-persistent.service
Wants=docker.service
[Service]
Type=oneshot
ExecStart=/bin/bash $SRC/deploy/oracle/firewall.sh
[Install]
WantedBy=multi-user.target
EOF
  unit trlive-update.service <<EOF
[Unit]
Description=TR Live güncelleme kontrolü
After=docker.service
[Service]
Type=oneshot
Environment=HOME=/root
ExecStart=/bin/bash $SRC/deploy/oracle/update.sh
EOF
  unit trlive-update.timer <<'EOF'
[Unit]
Description=TR Live güncellemeyi 5 dakikada bir kontrol et
[Timer]
OnBootSec=3min
OnUnitActiveSec=5min
[Install]
WantedBy=timers.target
EOF
  # Panelden gelen istekler ("Kaydet ve uygula", "Şimdi güncelle") bu dosyalarla gelir.
  unit trlive-apply.path <<EOF
[Path]
PathModified=$STATE/apply
PathModified=$STATE/update
[Install]
WantedBy=multi-user.target
EOF
  unit trlive-apply.service <<EOF
[Unit]
Description=TR Live panel isteği
[Service]
Type=oneshot
Environment=HOME=/root
ExecStart=/bin/bash $SRC/deploy/oracle/update.sh --from-panel
EOF
  unit trlive-import.path <<EOF
[Path]
PathModified=$STATE/import-request
[Install]
WantedBy=multi-user.target
EOF
  unit trlive-import.service <<EOF
[Unit]
Description=TR Live eski veritabanını aktarma
[Service]
Type=oneshot
Environment=HOME=/root
ExecStart=/bin/bash $SRC/deploy/oracle/import.sh
EOF
  unit trlive-backup.service <<EOF
[Unit]
Description=TR Live veritabanı yedeği
[Service]
Type=oneshot
ExecStart=/bin/bash $SRC/deploy/oracle/backup.sh
EOF
  unit trlive-backup.timer <<'EOF'
[Unit]
Description=TR Live günlük yedek
[Timer]
OnCalendar=*-*-* 04:30:00
Persistent=true
[Install]
WantedBy=timers.target
EOF
  systemctl daemon-reload
  systemctl enable trlive-firewall.service >/dev/null
  systemctl enable --now trlive-update.timer trlive-apply.path trlive-import.path trlive-backup.timer >/dev/null
fi

# Ses/görüntü yük testi (sunucu panelinden): her kurulum/güncellemede yazılır (eski sunuculara da gelsin).
cat > /etc/systemd/system/trlive-loadtest.path <<EOF
[Path]
PathModified=$STATE/loadtest-request
[Install]
WantedBy=multi-user.target
EOF
cat > /etc/systemd/system/trlive-loadtest.service <<EOF
[Unit]
Description=TR Live ses/görüntü yük testi
[Service]
Type=oneshot
Environment=HOME=/root
TimeoutStartSec=3h
ExecStart=/bin/bash $SRC/deploy/oracle/loadtest.sh
EOF
systemctl daemon-reload || true
systemctl enable --now trlive-loadtest.path >/dev/null 2>&1 || true

log "Bitti. Adres: https://${DOMAIN}  ·  Panel: https://${DOMAIN}/panel"
console "TR LIVE KURULUM TAMAM: https://${DOMAIN}/panel"
echo "$(date -Is) ok $DOMAIN" > "$STATE/installed"
