import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'common.dart';
import 'image_crop.dart';

export 'image_crop.dart' show CropSpec;

class PickedImage {
  final Uint8List bytes;
  final String mime;
  const PickedImage(this.bytes, this.mime);
}

String? sniffImageMime(Uint8List b) {
  if (b.length > 12 && b[0] == 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47) return 'image/png';
  if (b.length > 3 && b[0] == 0xFF && b[1] == 0xD8) return 'image/jpeg';
  if (b.length > 12 && b[0] == 0x52 && b[1] == 0x49 && b[8] == 0x57 && b[9] == 0x45) return 'image/webp';
  return null;
}

/// Galeriden görsel seçer; biçim ve boyut denetimini yapar. İptal veya hata durumunda null döner.
/// [crop] verilirse seçimden sonra kırpma ekranı açılır (kullanıcı kaydırıp büyüterek kadrajı ayarlar);
/// sonuç o oranda, en fazla [CropSpec.outWidth] genişliğinde JPEG olur.
Future<PickedImage?> pickImage(BuildContext context, {double maxWidth = 1280, CropSpec? crop}) async {
  // Gönderi / mesaj görselleri 1280 px ve %80 kalite: telefonda net görünür, dosya ~yarı (gönderen de görenler de daha az
  // internet harcar).
  final picked = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: crop == null ? maxWidth : 2048, imageQuality: crop == null ? 80 : 95);
  if (picked == null) return null;
  var bytes = await picked.readAsBytes();
  var mime = sniffImageMime(bytes);
  if (!context.mounted) return null;
  if (mime == null) {
    toast(context, 'Yalnızca png, jpeg veya webp yüklenebilir.', error: true);
    return null;
  }
  if (crop != null) {
    final cut = await cropImage(context, bytes, crop);
    if (cut == null || !context.mounted) return null;
    bytes = cut;
    mime = 'image/jpeg';
  }
  if (bytes.length > 3 * 1024 * 1024) {
    toast(context, 'Görsel 3 MB’tan küçük olmalı.', error: true);
    return null;
  }
  return PickedImage(bytes, mime);
}
