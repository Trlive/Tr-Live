import 'dart:io';
import 'package:flutter/foundation.dart' show defaultTargetPlatform, TargetPlatform;
import 'package:flutter/services.dart';
import 'api.dart';

/// Hediye/çerçeve dosyalarını kullanıcının telefonuna (uygulama önbelleği) bir kez indirir; sonra internetsiz oynatır.
/// Dosya adı sunucudaki benzersiz adrese bağlıdır, aynı dosya ikinci kez indirilmez.
class MediaCache {
  static final Map<String, Future<File>> _inflight = {};
  static Directory? _dir;
  static const int maxBytes = 400 * 1024 * 1024;

  static Future<Directory> _root() async {
    final d = _dir ?? Directory('${Directory.systemTemp.path}/trlive_media');
    if (!await d.exists()) await d.create(recursive: true);
    return _dir = d;
  }

  static String _name(String url) {
    final path = url.split('?').first;
    final last = path.split('/').last;
    final safe = last.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
    final h = path.hashCode.toUnsigned(32).toRadixString(16);
    return '${h}_$safe';
  }

  /// Dosya telefonda varsa onu, yoksa indirip kaydederek döndürür.
  static Future<File> get(String url) {
    return _inflight.putIfAbsent(url, () async {
      try {
        final dir = await _root();
        final f = File('${dir.path}/${_name(url)}');
        if (await f.exists() && await f.length() > 0) {
          f.setLastModified(DateTime.now()).catchError((_) => null);
          return f;
        }
        final r = await Api.client.get(Uri.parse(url)).timeout(const Duration(minutes: 2));
        if (r.statusCode != 200 || r.bodyBytes.isEmpty) throw Exception('indirilemedi (${r.statusCode})');
        final tmp = File('${f.path}.part');
        await tmp.writeAsBytes(r.bodyBytes, flush: true);
        await tmp.rename(f.path);
        _trim(dir);
        return f;
      } finally {
        _inflight.remove(url);
      }
    });
  }

  static final List<String> _queue = [];
  static final Set<String> _queued = {};
  static int _running = 0;
  static const int _parallel = 3;

  /// Arka planda önceden indirir (hediye paneli açılınca); hatalar yutulur.
  /// Aynı anda en fazla 3 dosya indirilir (çok sayıda hediye telefonu ve interneti boğmasın).
  /// [first] true: sıranın başına eklenir (hediye paneli açıkken o hediyeler önce insin).
  static void prefetch(Iterable<String?> urls, {bool first = false}) {
    // Mobil veride (kotalı bağlantı) önceden indirme yapılmaz: hediye gönderilince / gelince o an iner.
    final list = urls.toList();
    unmetered().then((ok) {
      if (ok) _enqueue(list, first);
    });
  }

  static DateTime _meterAt = DateTime.fromMillisecondsSinceEpoch(0);
  static bool _unmetered = true;

  /// Bağlantı kotasız mı (Wi-Fi). Mobil veride false. Sonuç 1 dk saklanır (her çağrıda Android'e sorulmaz).
  static Future<bool> unmetered() async {
    if (defaultTargetPlatform != TargetPlatform.android) return true;
    if (DateTime.now().difference(_meterAt) < const Duration(minutes: 1)) return _unmetered;
    try {
      _unmetered = !(await const MethodChannel('trlive/device').invokeMethod<bool>('isMetered') ?? false);
    } catch (_) {
      _unmetered = true; // eski derleme: eskisi gibi indir
    }
    _meterAt = DateTime.now();
    return _unmetered;
  }

  static void _enqueue(List<String?> urls, bool first) {
    final add = <String>[];
    for (final u in urls) {
      if (u == null || u.isEmpty) continue;
      if (_queued.contains(u)) {
        if (first && _queue.remove(u)) add.add(u);
        continue;
      }
      _queued.add(u);
      add.add(u);
    }
    if (first) {
      _queue.insertAll(0, add);
    } else {
      _queue.addAll(add);
    }
    _pump();
  }

  static void _pump() {
    while (_running < _parallel && _queue.isNotEmpty) {
      final u = _queue.removeAt(0);
      _running++;
      get(u).then((_) {}, onError: (_) {}).whenComplete(() {
        _running--;
        _queued.remove(u);
        _pump();
      });
    }
  }

  static bool _giftsWarmed = false;

  /// En ucuz (en sık gönderilen) 24 hediyenin animasyonunu (bir kez) telefona indirir; hediye gelince anında oynar.
  /// Hepsi indirilmez: yüksek kaliteli hediyeler büyüktür, diğerleri gelince / panelde görününce iner.
  static Future<void> warmGifts({bool force = false}) async {
    if (_giftsWarmed && !force) return;
    if (!await unmetered()) return; // mobil veride toplu indirme yok; Wi-Fi'de bir sonraki oda girişinde iner
    try {
      final r = await Api.get('/api/gifts');
      final list = r['gifts'];
      if (list is! List) return;
      _giftsWarmed = true;
      final gifts = [for (final g in list) if (g is Map) g]
        ..sort((a, b) => (num.tryParse('${a['coinPrice']}') ?? 0).compareTo(num.tryParse('${b['coinPrice']}') ?? 0));
      prefetch([for (final g in gifts.take(24)) Api.absoluteUrl(g['animationUrl'] as String?)]);
    } catch (_) {/* internet yoksa sonra denenir */}
  }

  static DateTime _trimAt = DateTime.fromMillisecondsSinceEpoch(0);

  /// Önbellek sınırı aşıldıysa en eski dosyaları siler. Klasörü taramak pahalı: en fazla 2 dk'da bir.
  static Future<void> _trim(Directory dir) async {
    if (DateTime.now().difference(_trimAt) < const Duration(minutes: 2)) return;
    _trimAt = DateTime.now();
    try {
      final files = <File>[];
      var total = 0;
      await for (final e in dir.list()) {
        if (e is File && !e.path.endsWith('.part')) {
          files.add(e);
          total += await e.length();
        }
      }
      if (total <= maxBytes) return;
      files.sort((a, b) => a.lastModifiedSync().compareTo(b.lastModifiedSync()));
      for (final f in files) {
        if (total <= maxBytes * 0.8) break;
        total -= await f.length();
        await f.delete();
      }
    } catch (_) {/* temizlik başarısızsa yoksay */}
  }
}
