import 'dart:io' show File;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import '../services/api.dart';
import '../services/session.dart';
import '../widgets/anim_asset.dart';
import '../widgets/common.dart';
import '../widgets/id_badge.dart';
import '../widgets/wip_items.dart';
import 'admin_events.dart';
import 'admin_content.dart';
import 'admin_dashboard.dart';
import 'admin_payouts.dart';
import 'support_screens.dart';

/// Telefondan dosya seçip sunucuya yükler. Sunucu türü dosyanın içinden anlar (svga, mp4, Lottie, webp, gif, png).
/// [alpha]: yan yana şeffaf mp4'te şeffaflık maskesinin yeri ('auto' / 'left' / 'right'). 'auto': sunucu anlar;
/// düz (siyah arka planlı) videoyu da kendisi şeffaf yapar ve küçük resmi (iconUrl) çıkarır.
/// [frame] true: çerçeve (kare, 360x360); false: hediye / efekt (540x960).
Future<Map<String, dynamic>?> pickAndUploadMedia(BuildContext context, {String alpha = 'auto', bool frame = false}) async {
  final r = await FilePicker.platform.pickFiles(type: FileType.any, withData: true);
  if (r == null || r.files.isEmpty || !context.mounted) return null;
  final Uint8List? bytes = r.files.first.bytes;
  if (bytes == null || bytes.isEmpty) {
    toast(context, 'Dosya okunamadı.', error: true);
    return null;
  }
  if (bytes.length > 40 * 1024 * 1024) {
    toast(context, 'Dosya 40 MB sınırını aşıyor.', error: true);
    return null;
  }
  toast(context, 'Yükleniyor ve hazırlanıyor (${(bytes.length / 1048576).toStringAsFixed(1)} MB)… Video ise 1 dakika kadar sürebilir.');
  return guard(context, () => Api.postBytes('/api/admin/media', bytes, 'application/octet-stream', query: {'alpha': alpha, if (frame) 'purpose': 'frame'}));
}


/// Animasyonun ilk karesini (şeffaf PNG) alıp sunucuya yükler; hediye ikonu için. Başarısızsa null.
Future<String?> autoIconFromAnimation(BuildContext context, String animUrl) async {
  final abs = Api.absoluteUrl(animUrl);
  if (abs == null) return null;
  final key = GlobalKey();
  final overlay = Overlay.of(context, rootOverlay: true);
  final entry = OverlayEntry(
    builder: (_) => Positioned(
      left: -2000,
      top: 0,
      width: 256,
      height: 256,
      child: IgnorePointer(child: RepaintBoundary(key: key, child: AnimAsset(url: abs, repeat: false, fit: BoxFit.contain))),
    ),
  );
  overlay.insert(entry);
  try {
    await Future<void>.delayed(const Duration(milliseconds: 1400));
    final obj = key.currentContext?.findRenderObject();
    if (obj is! RenderRepaintBoundary) return null;
    final img = await obj.toImage(pixelRatio: 1.5);
    final raw = await img.toByteData(format: ui.ImageByteFormat.rawRgba);
    final png = await img.toByteData(format: ui.ImageByteFormat.png);
    if (raw == null || png == null) return null;
    var visible = false;
    for (var i = 3; i < raw.lengthInBytes; i += 4 * 17) {
      if (raw.getUint8(i) > 8) {
        visible = true;
        break;
      }
    }
    if (!visible) return null;
    final r = await Api.postBytes('/api/admin/media', png.buffer.asUint8List(), 'application/octet-stream', query: {'alpha': 'left'});
    return r['url']?.toString();
  } catch (_) {
    return null;
  } finally {
    entry.remove();
  }
}

/// Hediye / çerçeve / mağaza ürünü düzenleme penceresi. [price] null ise fiyat alanı, [category] null ise sekme seçimi,
/// [days] null ise süre alanı, [forSale] null ise "mağazada satılsın" anahtarı gösterilmez. Değişen alanları döndürür.
Future<Map<String, dynamic>?> editItemDialog(BuildContext context, {required String title, required String name, String? price, String? category, int? days, bool? forSale, String? playMode}) async {
  final nameC = TextEditingController(text: name);
  final priceC = TextEditingController(text: price ?? '');
  final daysC = TextEditingController(text: days?.toString() ?? '');
  var cat = category;
  var sale = forSale;
  var mode = playMode;
  final ok = await showDialog<bool>(
    context: context,
    builder: (c) => StatefulBuilder(
      builder: (c, setS) => AlertDialog(
        title: Text(title),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: nameC, maxLength: 80, decoration: const InputDecoration(labelText: 'Ad', counterText: '')),
            if (price != null)
              TextField(controller: priceC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Fiyat (coin)')),
            if (days != null)
              TextField(controller: daysC, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Süre (gün)')),
            if (cat != null)
              DropdownButtonFormField<String>(
                value: cat,
                decoration: const InputDecoration(labelText: 'Hediye sekmesi'),
                items: const [
                  DropdownMenuItem(value: 'popular', child: Text('Popüler')),
                  DropdownMenuItem(value: 'event', child: Text('Etkinlik')),
                  DropdownMenuItem(value: 'private', child: Text('Kişiye Özel')),
                  DropdownMenuItem(value: 'vip', child: Text('Vip (WIP 3+)')),
                  DropdownMenuItem(value: 'lucky', child: Text('Şanslı')),
                  DropdownMenuItem(value: 'cp', child: Text('CP (yakınlık 1,5 kat)')),
                ],
                onChanged: (v) => setS(() => cat = v ?? cat),
              ),
            if (mode != null)
              DropdownButtonFormField<String>(
                value: mode,
                decoration: const InputDecoration(labelText: 'Nerede oynasın'),
                items: const [
                  DropdownMenuItem(value: 'full', child: Text('Tam ekran')),
                  DropdownMenuItem(value: 'seat', child: Text('Alıcının mikindeki dairede')),
                ],
                onChanged: (v) => setS(() => mode = v ?? mode),
              ),
            if (sale != null)
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Mağazada satılsın'),
                value: sale!,
                onChanged: (v) => setS(() => sale = v),
              ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Kaydet')),
        ],
      ),
    ),
  );
  final out = <String, dynamic>{
    'name': nameC.text.trim(),
    if (price != null) 'price': priceC.text.trim(),
    if (days != null) 'days': daysC.text.trim(),
    if (cat != null) 'category': cat,
    if (sale != null) 'forSale': sale,
    if (mode != null) 'playMode': mode,
  };
  // Pencere kapanış animasyonu bitince bırakılır (kapanırken alanlar hâlâ çiziliyor olabilir).
  WidgetsBinding.instance.addPostFrameCallback((_) {
    nameC.dispose();
    priceC.dispose();
    daysC.dispose();
  });
  return ok == true ? out : null;
}

/// Yüklenen dosyanın canlı önizlemesi (hediye animasyonu veya çerçeve).
Widget mediaPreview(String? url, {bool frame = false, double size = 170}) {
  final u = Api.absoluteUrl(url != null && url.trim().isNotEmpty ? url.trim() : null);
  return Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF0B3C5D), Color(0xFF061A2B)]),
      borderRadius: BorderRadius.circular(12),
    ),
    child: u == null
        ? const Center(child: Text('Önizleme', style: TextStyle(color: Colors.white38)))
        : Stack(alignment: Alignment.center, children: [
            if (frame) Icon(Icons.person, size: size * 0.45, color: Colors.white24),
            Positioned.fill(child: AnimAsset(key: ValueKey(u), url: u, repeat: true, fit: BoxFit.contain, cache: !frame)),
          ]),
  );
}

/// Hediyenin küçük resmi (png); dokununca animasyon ayrı pencerede oynar (listede hepsi birden oynayıp donmasın).
Widget giftThumb(BuildContext context, Map<String, dynamic> g, double size) {
  final icon = Api.absoluteUrl((g['iconUrl'] as String?)?.trim().isNotEmpty == true ? g['iconUrl'] as String : null);
  return GestureDetector(
    onTap: () => previewAnimation(context, g['name']?.toString() ?? '', g['animationUrl'] as String?, format: g['animationFormat'] as String?),
    child: Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF0B3C5D), Color(0xFF061A2B)]),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Stack(alignment: Alignment.center, children: [
        if (icon != null)
          Padding(
            padding: EdgeInsets.all(size * 0.08),
            child: NetImg(icon, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.card_giftcard, color: Colors.white38, size: 40)),
          )
        else
          const Icon(Icons.card_giftcard, color: Colors.white38, size: 40),
        Positioned(
          right: 6,
          bottom: 6,
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: const BoxDecoration(color: Color(0x99000000), shape: BoxShape.circle),
            child: const Icon(Icons.play_arrow, size: 18, color: Colors.white),
          ),
        ),
      ]),
    ),
  );
}

/// Animasyonu ayrı pencerede oynatır (önizleme).
void previewAnimation(BuildContext context, String name, String? url, {String? format}) {
  final u = Api.absoluteUrl(url != null && url.trim().isNotEmpty ? url.trim() : null);
  if (u == null) {
    toast(context, 'Bu hediyenin animasyon dosyası yok.', error: true);
    return;
  }
  showDialog<void>(
    context: context,
    builder: (c) => Dialog(
      backgroundColor: const Color(0xFF15151A),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          SizedBox(width: 270, height: 420, child: AnimAsset(url: u, format: format, repeat: true, fit: BoxFit.contain)),
          const SizedBox(height: 10),
          FilledButton(onPressed: () => Navigator.pop(c), child: const Text('Kapat')),
        ]),
      ),
    ),
  );
}

/// Katalogdaki tüm hediye ve çerçeveleri önizlemeyle listeler; açıp kapatma ve "bana ver" burada.
class CatalogListPage extends StatefulWidget {
  const CatalogListPage({super.key});

  @override
  State<CatalogListPage> createState() => _CatalogListPageState();
}

class _CatalogListPageState extends State<CatalogListPage> {
  List<Map<String, dynamic>> _gifts = [];
  List<Map<String, dynamic>> _frames = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await guard(context, () => Api.get('/api/admin/catalog'));
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (r != null) {
        _gifts = [for (final g in (r['gifts'] as List? ?? [])) if (g is Map) Map<String, dynamic>.from(g)];
        _frames = [for (final f in (r['frames'] as List? ?? [])) if (f is Map) Map<String, dynamic>.from(f)];
      }
    });
  }

  Future<void> _toggle(String kind, Map<String, dynamic> it, bool v) async {
    final r = await guard(context, () => Api.post('/api/admin/catalog/$kind/${it['id']}/active', {'isActive': v}));
    if (r != null) setState(() => it['isActive'] = v);
  }

  Future<void> _delete(String kind, Map<String, dynamic> it) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Silinsin mi?'),
        content: Text('"${it['name']}" kalıcı olarak silinecek. Geçmişte kullanıldıysa silinmez, gizlenir.'),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Sil'))],
      ),
    );
    if (ok != true || !mounted) return;
    final r = await guard(context, () => Api.delete('/api/admin/$kind/${it['id']}'));
    if (r != null && mounted) {
      toast(context, r['hidden'] == true ? (r['note'] ?? 'Gizlendi.').toString() : 'Silindi.');
      _load();
    }
  }

  Future<void> _edit(Map<String, dynamic> it, {required bool frame}) async {
    final v = frame
        ? await editItemDialog(context, title: 'Çerçeveyi düzenle', name: it['name'].toString())
        : await editItemDialog(context,
            title: 'Hediyeyi düzenle',
            name: it['name'].toString(),
            price: it['coinPrice']?.toString() ?? '',
            category: (it['category'] ?? 'popular').toString(),
            playMode: it['playMode'] == 'seat' ? 'seat' : 'full');
    if (v == null || !mounted) return;
    final price = (v['price'] ?? '').toString();
    final body = <String, dynamic>{
      'name': v['name'],
      if (!frame && price.isNotEmpty) 'coinPrice': price,
      if (!frame) 'category': v['category'],
      if (!frame) 'playMode': v['playMode'],
    };
    final r = await guard(context, () => Api.post('/api/admin/${frame ? 'frames' : 'gifts'}/${it['id']}/edit', body));
    if (r != null && mounted) {
      toast(context, 'Kaydedildi.');
      _load();
    }
  }

  Future<void> _grantSelf(Map<String, dynamic> f) async {
    final r = await guard(context, () => Api.post('/api/admin/users/${Session.id}/inventory', {'itemType': 'frame', 'itemKey': f['id'], 'itemName': f['name']}));
    if (r != null && mounted) toast(context, '"${f['name']}" envanterine eklendi.');
  }

  Widget _card(String kind, Map<String, dynamic> it, {required bool frame}) {
    final active = it['isActive'] == true;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(children: [
          Expanded(
            child: LayoutBuilder(
              builder: (c, box) => Center(
                child: frame
                    ? mediaPreview(it['imageUrl'] as String?, frame: true, size: box.biggest.shortestSide)
                    : giftThumb(context, it, box.biggest.shortestSide),
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(it['name'].toString(), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
          if (!frame) Text('${fmtNumber(it['coinPrice'])} coin · ${it['category']}${it['playMode'] == 'seat' ? ' · mikte' : ''}', style: const TextStyle(color: Colors.white54, fontSize: 12)),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(active ? 'Açık' : 'Kapalı', style: TextStyle(color: active ? Colors.greenAccent : Colors.white38)),
            Switch(value: active, onChanged: (v) => _toggle(kind, it, v)),
          ]),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            if (frame) TextButton(onPressed: () => _grantSelf(it), child: const Text('Bana ver')),
            TextButton(onPressed: () => _edit(it, frame: frame), child: const Text('Düzenle')),
            TextButton(style: TextButton.styleFrom(foregroundColor: Colors.redAccent), onPressed: () => _delete(frame ? 'frames' : 'gifts', it), child: const Text('Sil')),
          ]),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Katalog önizleme'), actions: [
        IconButton(
          tooltip: 'Küçük resmi olmayan hediyelere otomatik küçük resim',
          icon: const Icon(Icons.auto_fix_high),
          onPressed: () async {
            toast(context, 'Küçük resimler hazırlanıyor…');
            var added = 0;
            var skip = 0;
            // Sunucu her seferde birkaç hediye işler; yapılamayanlar atlanır, kalan bitene kadar devam edilir.
            for (var i = 0; i < 100; i++) {
              final r = await guard(context, () => Api.post('/api/admin/gifts/fill-icons', {'skip': skip}));
              if (r == null || !mounted) break;
              added += (r['done'] as num?)?.toInt() ?? 0;
              skip += (r['failed'] as num?)?.toInt() ?? 0;
              final total = (r['total'] as num?)?.toInt() ?? 0;
              final left = (r['left'] as num?)?.toInt() ?? 0;
              if (total == 0 || left <= skip) break;
              toast(context, '$added hediyeye küçük resim eklendi, devam ediyor…');
            }
            if (!mounted) return;
            toast(context, '$added hediyeye küçük resim eklendi.');
            _load();
          },
        ),
      ]),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(padding: const EdgeInsets.all(12), children: [
                Text('Hediyeler (${_gifts.length})', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                GridView.count(
                  crossAxisCount: 2,
                  childAspectRatio: 0.72,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  children: [for (final g in _gifts) _card('gifts', g, frame: false)],
                ),
                const SizedBox(height: 16),
                Text('Çerçeveler (${_frames.length})', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                GridView.count(
                  crossAxisCount: 2,
                  childAspectRatio: 0.72,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  children: [for (final f in _frames) _card('frames', f, frame: true)],
                ),
              ]),
            ),
    );
  }
}

class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Yönetici: tüm paneller. Yardımcı admin: yalnızca kullanıcı (nick, fotoğraf, ban).
    final admin = Session.isAdmin;
    final tabs = <Tab>[
      if (admin) const Tab(text: 'Panel'),
      const Tab(text: 'Kullanıcı'),
      const Tab(text: 'Destek'),
      if (admin) const Tab(text: 'Yetkililer'),
      if (admin) const Tab(text: 'Ajans/Yayıncı'),
      if (admin) const Tab(text: 'Maaş/Dönem'),
      if (admin) const Tab(text: 'Şikâyetler'),
      if (admin) const Tab(text: 'Güvenlik'),
      if (admin) const Tab(text: 'Bayi'),
      if (admin) const Tab(text: 'Katalog'),
      if (admin) const Tab(text: 'Banner/Duyuru'),
    ];
    return DefaultTabController(
      length: tabs.length,
      child: Scaffold(
        appBar: AppBar(
          title: Text(admin ? 'Yönetim paneli' : 'Yardımcı admin paneli'),
          bottom: TabBar(isScrollable: true, tabs: tabs),
        ),
        body: TabBarView(children: [
          if (admin) const DashboardTab(),
          const _UsersTab(),
          const SupportAdminTab(),
          if (admin) const _StaffTab(),
          if (admin) const _AgenciesTab(),
          if (admin) const PayoutsTab(),
          if (admin) const _ReportsTab(),
          if (admin) const _SecurityTab(),
          if (admin) const _DealersTab(),
          if (admin) const _CatalogTab(),
          if (admin) const ContentTab(),
        ]),
      ),
    );
  }
}

// ------------------------------------------------------------------ Yetkililer (yalnızca yönetici)
class _StaffTab extends StatefulWidget {
  const _StaffTab();

  @override
  State<_StaffTab> createState() => _StaffTabState();
}

class _StaffTabState extends State<_StaffTab> {
  List<Map<String, dynamic>> _staff = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await guard(context, () => Api.get('/api/admin/staff'));
    if (!mounted) return;
    setState(() {
      _staff = listOf(r?['staff']);
      _loading = false;
    });
  }

  Future<void> _set(String userId, String role, String done) async {
    final r = await guard(context, () => Api.post('/api/admin/users/$userId/staff-role', {'role': role}));
    if (r == null || !mounted) return;
    toast(context, done);
    await _load();
  }

  Future<void> _add() async {
    final u = await pickUser(context, admin: true);
    if (u == null || !mounted) return;
    if (u['systemRole'] == 'admin') return toast(context, 'Bu kişi zaten yönetici.', error: true);
    await _set(u['id'].toString(), 'support', 'Yardımcı admin yetkisi verildi.');
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text(
        'Yardımcı admin yalnızca: kullanıcının adını ve profil fotoğrafını değiştirebilir, süreli veya süresiz ban atabilir. '
        'Para, WIP, ajans, maaş, katalog ve güvenlik ayarlarına erişemez.',
      ),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: _add, icon: const Icon(Icons.person_add), label: const Text('Yardımcı admin ekle')),
      const SizedBox(height: 8),
      for (final u in _staff)
        Card(
          child: ListTile(
            leading: Icon(u['systemRole'] == 'admin' ? Icons.shield : Icons.support_agent),
            title: Text((u['displayName'] ?? '').toString()),
            subtitle: Text('@${u['username']} · ${u['systemRole'] == 'admin' ? 'Yönetici' : 'Yardımcı admin'}'),
            trailing: u['systemRole'] == 'support'
                ? TextButton(onPressed: () async {
                    if (await confirm(context, '@${u['username']} yetkisi alınsın mı?', action: 'Yetkiyi al') && mounted) {
                      await _set(u['id'].toString(), 'user', 'Yetki alındı.');
                    }
                  }, child: const Text('Yetkiyi al'))
                : null,
          ),
        ),
    ]);
  }
}

// ------------------------------------------------------------------ Kullanıcı
class _UsersTab extends StatefulWidget {
  const _UsersTab();

  @override
  State<_UsersTab> createState() => _UsersTabState();
}

class _UsersTabState extends State<_UsersTab> {
  Map<String, dynamic>? _user;

  Future<void> _pick() async {
    final u = await pickUser(context, admin: true);
    if (u != null && mounted) setState(() => _user = u);
  }

  Future<void> _run(Future<Map<String, dynamic>> Function() action, String done) async {
    final r = await guard(context, action);
    if (r == null || !mounted) return;
    toast(context, done);
    await _refreshUser();
  }

  Future<void> _refreshUser() async {
    final id = _user?['id'];
    if (id == null) return;
    try {
      final r = await Api.get('/api/admin/users', query: {'q': id.toString()});
      final list = listOf(r['users']);
      if (list.isNotEmpty && mounted) setState(() => _user = list.first);
    } catch (_) {/* eski bilgi kalsın */}
  }

  /// Yönetici: sınırsız ekler / düşer. Yardımcı admin: tek seferde en fazla 100.000 Coin yükler, düşemez.
  Future<void> _coins() async {
    final admin = Session.isAdmin;
    final lAmount = admin ? 'Miktar (çıkarmak için - ile)' : 'Miktar (en fazla 100.000)';
    final f = await formDialog(context, admin ? 'Coin düzenle' : 'Coin yükle', [lAmount, 'Neden']);
    if (f == null || !mounted) return;
    final amount = int.tryParse((f[lAmount] ?? '').replaceAll('.', '').trim());
    if (amount == null || amount == 0) return toast(context, 'Geçerli bir miktar girin.', error: true);
    if (!admin && (amount < 0 || amount > 100000)) return toast(context, 'Yardımcı admin tek seferde 1 ile 100.000 arası Coin yükleyebilir.', error: true);
    await _run(() => Api.postOnce('/api/admin/users/${_user!['id']}/coins', {'amount': amount, 'reason': f['Neden']}), 'Coin güncellendi.');
  }

  /// Seviye ver: yönetici 1-300 (düşürebilir de), yardımcı admin en fazla 100 ve yalnızca yükseltir.
  Future<void> _level() async {
    final admin = Session.isAdmin;
    final max = admin ? 300 : 100;
    var kind = 'user';
    final ctl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setS) => AlertDialog(
          title: const Text('Seviye ver'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            DropdownButtonFormField<String>(
              // ignore: deprecated_member_use
              value: kind,
              decoration: const InputDecoration(labelText: 'Tür'),
              items: const [
                DropdownMenuItem(value: 'user', child: Text('Kullanıcı seviyesi')),
                DropdownMenuItem(value: 'host', child: Text('Yayıncı seviyesi')),
              ],
              onChanged: (v) => setS(() => kind = v ?? kind),
            ),
            TextField(controller: ctl, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Seviye (1-$max)')),
            const SizedBox(height: 8),
            Text(admin ? 'Yönetici her seviyeyi verebilir.' : 'En fazla $max. seviye; seviye düşürülemez.', style: const TextStyle(fontSize: 12)),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Ver')),
          ],
        ),
      ),
    );
    final n = int.tryParse(ctl.text.trim());
    // Pencerenin kapanış animasyonu bitince bırakılır (hemen bırakılırsa "kullanılan denetleyici" hatası olur).
    WidgetsBinding.instance.addPostFrameCallback((_) => ctl.dispose());
    if (ok != true || !mounted) return;
    if (n == null || n < 1 || n > max) return toast(context, 'Seviye 1-$max arasında olmalı.', error: true);
    await _run(() => Api.post('/api/admin/users/${_user!['id']}/level', {'kind': kind, 'level': n}), 'Seviye verildi.');
  }

  Future<void> _wip() async {
    const lvlLabel = 'Seviye (1-10, SWIP = 11)';
    final f = await formDialog(context, 'WIP ver', [lvlLabel, 'Gün'], initial: {lvlLabel: '1', 'Gün': '30'});
    if (f == null || !mounted) return;
    final level = int.tryParse(f[lvlLabel] ?? '');
    final days = int.tryParse(f['Gün'] ?? '');
    if (level == null || days == null) return toast(context, 'Seviye ve gün sayı olmalı.', error: true);
    await _run(() => Api.post('/api/admin/users/${_user!['id']}/wip', {'level': level, 'days': days}), 'WIP verildi.');
  }

  /// Özel ID: numara boş bırakılırsa göz alıcı 6 haneli numara otomatik verilir. Var olan özel ID'nin süresi uzar.
  Future<void> _specialId() async {
    const lId = 'Özel ID (2-7 hane; boş = otomatik)';
    const lDays = 'Gün';
    final f = await formDialog(context, 'Özel ID ver', [lId, lDays], initial: {lId: '', lDays: '30'});
    if (f == null || !mounted) return;
    final days = int.tryParse(f[lDays] ?? '');
    final id = (f[lId] ?? '').trim();
    if (days == null || days < 1) return toast(context, 'Gün sayı olmalı.', error: true);
    if (id.isNotEmpty && !RegExp(r'^[1-9]\d{1,6}$').hasMatch(id)) return toast(context, 'Özel ID 2-7 haneli olmalı ve 0 ile başlamamalı.', error: true);
    final r = await guard(context, () => Api.post('/api/admin/users/${_user!['id']}/special-id', {'days': days, if (id.isNotEmpty) 'specialId': id}));
    if (r != null && mounted) toast(context, 'Özel ID verildi: ${r['specialId']}');
  }

  Future<void> _hostBadge() async {
    var badge = 'altin';
    final days = TextEditingController(text: '30');
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setS) => AlertDialog(
          title: const Text('Yayıncı rozeti ver'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            DropdownButtonFormField<String>(
              // ignore: deprecated_member_use
              value: badge,
              decoration: const InputDecoration(labelText: 'Rozet'),
              items: const [
                DropdownMenuItem(value: 'bronz', child: Text('Bronz Yayıncı')),
                DropdownMenuItem(value: 'gumus', child: Text('Gümüş Yayıncı')),
                DropdownMenuItem(value: 'altin', child: Text('Altın Yayıncı')),
                DropdownMenuItem(value: 'super', child: Text('Süper Yayıncı')),
                DropdownMenuItem(value: 'ozel', child: Text('Özel Yayıncı')),
              ],
              onChanged: (v) => setS(() => badge = v ?? badge),
            ),
            TextField(controller: days, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Gün')),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Ver')),
          ],
        ),
      ),
    );
    final d = int.tryParse(days.text.trim());
    days.dispose();
    if (ok != true || !mounted) return;
    if (d == null || d < 1) return toast(context, 'Gün sayı olmalı.', error: true);
    await _run(() => Api.post('/api/admin/users/${_user!['id']}/host-badge', {'badge': badge, 'days': d}), 'Rozet verildi.');
  }

  Future<void> _removeMark(String what) async {
    final label = what == 'special-id' ? 'Özel ID' : 'Yayıncı rozeti';
    if (!await confirm(context, '$label kaldırılsın mı?', action: 'Kaldır', destructive: true)) return;
    if (!mounted) return;
    await _run(() => Api.delete('/api/admin/users/${_user!['id']}/$what'), '$label kaldırıldı.');
  }

  Future<void> _inventory() async {
    final u = _user;
    if (u == null) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => GrantItemPage(user: u)));
  }

  Future<void> _ban() async {
    final f = await formDialog(context, 'Ban', ['Süre (saat; boş bırakırsanız süresiz)', 'Neden'], initial: {'Süre (saat; boş bırakırsanız süresiz)': ''});
    if (f == null || !mounted) return;
    final raw = f['Süre (saat; boş bırakırsanız süresiz)'] ?? '';
    final hours = raw.isEmpty ? null : num.tryParse(raw.replaceAll(',', '.'));
    if (raw.isNotEmpty && (hours == null || hours <= 0)) return toast(context, 'Süre geçerli bir sayı olmalı.', error: true);
    await _run(() => Api.post('/api/admin/users/${_user!['id']}/ban', {if (hours != null) 'hours': hours, 'reason': f['Neden']}),
        hours == null ? 'Süresiz banlandı.' : 'Banlandı.');
  }

  Future<void> _rename() async {
    final f = await formDialog(context, 'Görünen adı değiştir', ['Yeni ad'], initial: {'Yeni ad': (_user?['displayName'] ?? '').toString()});
    if (f == null || !mounted) return;
    await _run(() => Api.post('/api/admin/users/${_user!['id']}/display-name', {'displayName': f['Yeni ad']}), 'Ad değiştirildi.');
  }

  /// Giriş bilgileri: kullanıcı adı, telefon ve yeni şifre (yalnızca yönetici). Şifre gösterilmez, yenisi verilir.
  Future<void> _credentials() async {
    final id = _user?['id'];
    if (id == null) return;
    final cur = await guard(context, () => Api.get('/api/admin/users/$id/credentials'));
    if (cur == null || !mounted) return;
    const lUser = 'Kullanıcı adı (giriş)';
    const lPhone = 'Telefon (boş bırakılırsa kaldırılır)';
    const lPass = 'Yeni şifre (boş = değişmez, en az 6)';
    final f = await formDialog(context, 'Giriş bilgileri', [lUser, lPhone, lPass], initial: {
      lUser: (cur['username'] ?? '').toString(),
      lPhone: (cur['phone'] ?? '').toString(),
      lPass: '',
    });
    if (f == null || !mounted) return;
    final pass = f[lPass] ?? '';
    if (pass.isNotEmpty && pass.length < 6) return toast(context, 'Şifre en az 6 karakter olmalı.', error: true);
    if (pass.isNotEmpty &&
        !await confirm(context, 'Şifre değişince kullanıcının tüm cihazlardaki oturumları kapanır; yeni şifreyle giriş yapar. Devam edilsin mi?', action: 'Değiştir')) {
      return;
    }
    if (!mounted) return;
    await _run(
      () => Api.post('/api/admin/users/$id/credentials', {
        'username': f[lUser] ?? '',
        'phone': f[lPhone] ?? '',
        if (pass.isNotEmpty) 'password': pass,
      }),
      pass.isNotEmpty ? 'Giriş bilgileri ve şifre güncellendi.' : 'Giriş bilgileri güncellendi.',
    );
  }

  Future<void> _restrict() async {
    final f = await formDialog(context, 'Sohbet kısıtı', ['Süre (dakika; 0 = kısıtı kaldır)'], initial: {'Süre (dakika; 0 = kısıtı kaldır)': '60'});
    if (f == null || !mounted) return;
    final minutes = int.tryParse(f['Süre (dakika; 0 = kısıtı kaldır)'] ?? '');
    if (minutes == null || minutes < 0 || minutes > 10080) return toast(context, 'Süre 0-10080 dakika olmalı.', error: true);
    await _run(() => Api.post('/api/admin/users/${_user!['id']}/chat-restriction', {'minutes': minutes}), minutes == 0 ? 'Sohbet kısıtı kaldırıldı.' : 'Sohbet kısıtlandı.');
  }

  Future<void> _revokeSessions() async {
    if (!await confirm(context, 'Bu kullanıcının tüm cihazlardaki oturumları kapatılsın mı? Yeniden giriş yapması gerekir.', action: 'Oturumları kapat', destructive: true)) return;
    if (!mounted) return;
    await _run(() => Api.post('/api/admin/users/${_user!['id']}/sessions/revoke-all'), 'Tüm oturumlar kapatıldı.');
  }

  String _restrictLine(Map<String, dynamic> u) {
    final until = DateTime.tryParse((u['chatRestrictedUntil'] ?? '').toString())?.toLocal();
    if (until == null) return '';
    return '\nSohbet kısıtı: ${until.toString().substring(0, 16)} kadar';
  }

  String _banLine(Map<String, dynamic> u) {
    if (u['accountStatus'] != 'banned') return '';
    final until = u['bannedUntil'];
    final when = until == null ? 'süresiz' : 'bitiş: ${DateTime.parse(until.toString()).toLocal().toString().substring(0, 16)}';
    final why = (u['banReason'] ?? '').toString();
    return '\nBan ($when)${why.isEmpty ? '' : ' · $why'}';
  }

  @override
  Widget build(BuildContext context) {
    final u = _user;
    final admin = Session.isAdmin;
    // Yardımcı admin bu işlemleri yalnızca normal kullanıcılara yapabilir (sunucu da denetler).
    final staffOk = admin || (u != null && u['systemRole'] == 'user');
    return ListView(padding: const EdgeInsets.all(16), children: [
      FilledButton.icon(onPressed: _pick, icon: const Icon(Icons.search), label: const Text('Kullanıcı bul (ID, ad)')),
      if (u != null) ...[
        const SizedBox(height: 12),
        Card(
          child: ListTile(
            leading: UserAvatar(user: u),
            title: Text((u['displayName'] ?? '').toString()),
            subtitle: Text('ID: ${u['publicId'] ?? '-'} · @${u['username']} · ${u['systemRole']} · ${u['accountStatus']}'
                '${u['coinLevel'] != null ? '\nSeviye: ${u['coinLevel']} · Yayıncı seviyesi: ${u['giftLevel'] ?? 1}' : ''}'
                '${admin ? '\nCoin: ${fmtNumber(u['coins'])} · Diamond: ${fmtNumber(u['diamonds'])}' : ''}${_banLine(u)}${_restrictLine(u)}'),
            isThreeLine: true,
          ),
        ),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          // Yardımcı admin + yönetici
          OutlinedButton.icon(onPressed: _rename, icon: const Icon(Icons.edit), label: const Text('Nick değiştir')),
          OutlinedButton.icon(
            onPressed: () async {
              if (await confirm(context, 'Profil fotoğrafı kaldırılsın mı?', action: 'Kaldır') && mounted) {
                await _run(() => Api.post('/api/admin/users/${u['id']}/avatar', {'avatarUrl': null}), 'Fotoğraf kaldırıldı.');
              }
            },
            icon: const Icon(Icons.hide_image_outlined),
            label: const Text('Fotoğrafı kaldır'),
          ),
          if (u['accountStatus'] == 'active')
            OutlinedButton.icon(style: OutlinedButton.styleFrom(foregroundColor: Colors.redAccent), onPressed: _ban, icon: const Icon(Icons.gavel), label: const Text('Banla'))
          else if (u['accountStatus'] == 'banned')
            OutlinedButton.icon(onPressed: () => _run(() => Api.post('/api/admin/users/${u['id']}/unban', {}), 'Ban kaldırıldı.'), icon: const Icon(Icons.lock_open), label: const Text('Banı kaldır')),
          OutlinedButton.icon(onPressed: _restrict, icon: const Icon(Icons.speaker_notes_off_outlined), label: Text(u['chatRestrictedUntil'] != null ? 'Sohbet kısıtını değiştir' : 'Sohbet kısıtı')),
          // Yalnızca yönetici
          if (admin) OutlinedButton.icon(onPressed: _credentials, icon: const Icon(Icons.key), label: const Text('Giriş bilgileri / şifre')),
          if (admin) OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => UserDevicesScreen(user: u))), icon: const Icon(Icons.devices), label: const Text('Cihazlar')),
          if (admin) OutlinedButton.icon(style: OutlinedButton.styleFrom(foregroundColor: Colors.redAccent), onPressed: _revokeSessions, icon: const Icon(Icons.logout), label: const Text('Oturumları kapat')),
          // Yönetici + yardımcı admin (yardımcı admin: yalnızca normal kullanıcıya; Coin en fazla 100.000, seviye en fazla 100).
          if (staffOk) OutlinedButton.icon(onPressed: _coins, icon: const Icon(Icons.monetization_on), label: Text(admin ? 'Coin düzenle' : 'Coin yükle')),
          if (staffOk) OutlinedButton.icon(onPressed: _level, icon: const Icon(Icons.trending_up), label: const Text('Seviye ver')),
          if (staffOk) OutlinedButton.icon(onPressed: _wip, icon: const Icon(Icons.workspace_premium), label: const Text('WIP ver')),
          if (staffOk) OutlinedButton.icon(onPressed: () => _run(() => Api.delete('/api/admin/users/${u['id']}/wip'), 'WIP kaldırıldı.'), icon: const Icon(Icons.remove_circle_outline), label: const Text('WIP al')),
          if (staffOk) OutlinedButton.icon(onPressed: _inventory, icon: const Icon(Icons.inventory_2), label: const Text('Öğe ver (çerçeve, rozet…)')),
          if (staffOk)
            OutlinedButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GrantItemPage(user: u, initialCategory: 'colored_id'))),
              icon: const Icon(Icons.format_color_text),
              label: const Text('Renkli ID ver'),
            ),
          if (admin) OutlinedButton.icon(onPressed: _specialId, icon: const Icon(Icons.badge_outlined), label: const Text('Özel ID ver')),
          if (admin) OutlinedButton.icon(onPressed: () => _removeMark('special-id'), icon: const Icon(Icons.remove_circle_outline), label: const Text('Özel ID al')),
          if (admin) OutlinedButton.icon(onPressed: _hostBadge, icon: const Icon(Icons.military_tech), label: const Text('Yayıncı rozeti ver')),
          if (admin) OutlinedButton.icon(onPressed: () => _removeMark('host-badge'), icon: const Icon(Icons.remove_circle_outline), label: const Text('Rozeti al')),
        ]),
      ],
    ]);
  }
}

// ------------------------------------------------------------ Ajans / yayıncı
class _AgenciesTab extends StatefulWidget {
  const _AgenciesTab();

  @override
  State<_AgenciesTab> createState() => _AgenciesTabState();
}

class _AgenciesTabState extends State<_AgenciesTab> {
  int _v = 0;

  Future<Map<String, dynamic>> _load() async {
    final a = await Api.get('/api/admin/agencies');
    final b = await Api.get('/api/admin/broadcasters');
    return {'agencies': listOf(a['agencies']), 'broadcasters': listOf(b['broadcasters'])};
  }

  Future<void> _run(Future<Map<String, dynamic>> Function() action, {String? done}) async {
    final r = await guard(context, action);
    if (r == null || !mounted) return;
    if (done != null) toast(context, done);
    setState(() => _v++);
  }

  /// Ajansı yönetici açar: kullanıcı ID ya da kullanıcı adıyla seçilir, o kişi ajans sahibi olur.
  Future<void> _createAgency() async {
    final u = await pickUser(context, admin: true);
    if (u == null || !mounted) return;
    final name = await askText(context, 'Ajans adı (@${u['username']} sahibi olacak)');
    if (name == null || name.trim().length < 3 || !mounted) {
      if (name != null && mounted) toast(context, 'Ajans adı en az 3 karakter olmalı.', error: true);
      return;
    }
    if (!mounted) return;
    final ref = await askText(context, 'Davet eden ajans kodu (isteğe bağlı)', hint: '8 haneli ajans kodu; yoksa boş bırakın', keyboard: TextInputType.number);
    if (!mounted) return;
    await _run(() => Api.post('/api/admin/agencies', {'userId': u['id'], 'name': name.trim(), if (ref != null && ref.isNotEmpty) 'referrerCode': ref}),
        done: '${u['displayName'] ?? u['username']} artık "${name.trim()}" ajansının sahibi.');
  }

  Future<void> _setReferrer(Map<String, dynamic> a) async {
    const label = 'Davet eden ajansın kodu (boş = kaldır)';
    final f = await formDialog(context, 'Davet eden ajans', [label], initial: {label: (mapOf(a['referrer'])?['agencyCode'] ?? '').toString()});
    if (f == null || !mounted) return; // Vazgeç: değişiklik yok
    final code = (f[label] ?? '').trim();
    await _run(() => Api.post('/api/admin/agencies/${a['id']}/referrer', {'code': code.isEmpty ? null : code}), done: code.isEmpty ? 'Davet eden ajans kaldırıldı.' : 'Güncellendi.');
  }

  @override
  Widget build(BuildContext context) {
    return AsyncBody<Map<String, dynamic>>(
      version: _v,
      load: _load,
      builder: (context, data, reload) {
        final agencies = listOf(data['agencies']);
        final broadcasters = listOf(data['broadcasters']);
        return RefreshIndicator(
          onRefresh: reload,
          child: ListView(padding: const EdgeInsets.all(12), children: [
            if (Session.isAdmin) ...[
              FilledButton.icon(onPressed: _createAgency, icon: const Icon(Icons.add_business), label: const Text('Ajans aç (kullanıcı ID / adı ile)')),
              const SizedBox(height: 12),
            ],
            Text('Ajanslar (${agencies.length})', style: Theme.of(context).textTheme.titleMedium),
            for (final a in agencies)
              Card(
                child: ListTile(
                  title: Text(a['name'].toString()),
                  subtitle: Text('Sahip: @${a['ownerUsername']} · ${a['status']} · kod: ${a['agencyCode'] ?? '-'} · ${a['broadcasterCount']} yayıncı · ${a['assistantCount'] ?? 0} asistan'
                      '${mapOf(a['referrer']) != null ? '\nDavet eden: ${mapOf(a['referrer'])?['name']}' : ''}'),
                  trailing: !Session.isAdmin
                      ? null
                      : PopupMenuButton<String>(
                          onSelected: (s) {
                            if (s == 'referrer') _setReferrer(a);
                            if (s == 'active' || s == 'suspended' || s == 'rejected') _run(() => Api.post('/api/admin/agencies/${a['id']}/status', {'status': s}), done: 'Güncellendi.');
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'active', child: Text('Onayla / aktif et')),
                            PopupMenuItem(value: 'suspended', child: Text('Askıya al')),
                            PopupMenuItem(value: 'rejected', child: Text('Reddet')),
                            PopupMenuItem(value: 'referrer', child: Text('Davet eden ajansı ayarla')),
                          ],
                        ),
                ),
              ),
            const SizedBox(height: 16),
            Text('Yayıncılar (${broadcasters.length})', style: Theme.of(context).textTheme.titleMedium),
            for (final b in broadcasters)
              Card(
                child: ListTile(
                  title: Text('${b['displayName']} (@${b['username']})'),
                  subtitle: Text('${b['status']}${b['agencyName'] != null ? ' · ${b['agencyName']}' : ''}'),
                  trailing: PopupMenuButton<String>(
                    onSelected: (s) => _run(() => Api.post('/api/admin/broadcasters/${b['userId']}/status', {'status': s}), done: 'Güncellendi.'),
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'approved', child: Text('Onayla')),
                      PopupMenuItem(value: 'rejected', child: Text('Reddet')),
                      PopupMenuItem(value: 'suspended', child: Text('Askıya al')),
                    ],
                  ),
                ),
              ),
          ]),
        );
      },
    );
  }
}

// ------------------------------------------------------------------------ Bayi
class _DealersTab extends StatefulWidget {
  const _DealersTab();

  @override
  State<_DealersTab> createState() => _DealersTabState();
}

class _DealersTabState extends State<_DealersTab> {
  int _v = 0;

  Future<void> _run(Future<Map<String, dynamic>> Function() action, {String? done}) async {
    final r = await guard(context, action);
    if (r == null || !mounted) return;
    if (done != null) toast(context, done);
    setState(() => _v++);
  }

  Future<void> _create() async {
    final f = await formDialog(context, 'Bayi oluştur', ['Bayi adı']);
    if (f == null || !mounted) return;
    final owner = await pickUser(context, admin: true);
    if (!mounted) return;
    await _run(() => Api.post('/api/admin/dealers', {'name': f['Bayi adı'], if (owner != null) 'ownerUserId': owner['id']}), done: 'Bayi oluşturuldu.');
  }

  Future<void> _credit(Map<String, dynamic> d) async {
    final f = await formDialog(context, 'Bayiye Coin yükle', ['Miktar']);
    final amount = int.tryParse(f?['Miktar'] ?? '');
    if (amount == null || !mounted) return;
    await _run(() => Api.post('/api/admin/dealers/${d['id']}/coins', {'amount': amount}), done: 'Bayi bakiyesi güncellendi.');
  }

  Future<void> _sell(Map<String, dynamic> d) async {
    final u = await pickUser(context, admin: true);
    if (u == null || !mounted) return;
    final f = await formDialog(context, '${u['displayName']} için Coin sat', ['Miktar']);
    final amount = int.tryParse(f?['Miktar'] ?? '');
    if (amount == null || !mounted) return;
    await _run(() => Api.post('/api/admin/dealers/${d['id']}/sell', {'userId': u['id'], 'amount': amount}), done: 'Satış tamamlandı.');
  }

  @override
  Widget build(BuildContext context) {
    return AsyncBody<List<Map<String, dynamic>>>(
      version: _v,
      load: () async => listOf((await Api.get('/api/admin/dealers'))['dealers']),
      builder: (context, dealers, reload) => RefreshIndicator(
        onRefresh: reload,
        child: ListView(padding: const EdgeInsets.all(12), children: [
          FilledButton.icon(onPressed: _create, icon: const Icon(Icons.add_business), label: const Text('Bayi oluştur')),
          for (final d in dealers)
            Card(
              child: ListTile(
                title: Text(d['name'].toString()),
                subtitle: Text('Sahip: ${d['ownerUsername'] != null ? '@${d['ownerUsername']}' : '-'} · Bakiye: ${fmtNumber(d['coinBalance'])}'),
                trailing: PopupMenuButton<String>(
                  onSelected: (a) => a == 'credit' ? _credit(d) : _sell(d),
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'credit', child: Text('Bayiye Coin yükle')),
                    PopupMenuItem(value: 'sell', child: Text('Kullanıcıya Coin sat')),
                  ],
                ),
              ),
            ),
        ]),
      ),
    );
  }
}

// --------------------------------------------------------------------- Katalog
class _CatalogTab extends StatelessWidget {
  const _CatalogTab();

  Future<void> _giftForm(BuildContext context) async {
    final name = TextEditingController();
    final price = TextEditingController();
    final icon = TextEditingController();
    final anim = TextEditingController();
    var format = 'auto';
    var alphaSide = 'auto';
    var category = 'popular';
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setS) => AlertDialog(
          title: const Text('Hediye ekle'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Ad')),
              TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Coin fiyatı')),
              TextField(controller: icon, decoration: const InputDecoration(labelText: 'İkon adresi (https veya yüklenen dosya)')),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  icon: const Icon(Icons.upload_file),
                  label: const Text('İkonu telefondan yükle'),
                  onPressed: () async {
                    final m = await pickAndUploadMedia(c);
                    if (m != null && c.mounted) setS(() => icon.text = (m['iconUrl'] ?? m['url']).toString());
                  },
                ),
              ),
              if (icon.text.trim().isNotEmpty)
                Padding(padding: const EdgeInsets.only(top: 4), child: Container(width: 72, height: 72, decoration: BoxDecoration(color: const Color(0xFF0B3C5D), borderRadius: BorderRadius.circular(10)), child: NetImg(Api.absoluteUrl(icon.text.trim()) ?? '', fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white38)))),
              if (anim.text.trim().isNotEmpty)
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton.icon(
                    icon: const Icon(Icons.auto_fix_high),
                    label: const Text('İkonu animasyonun ilk karesinden yap'),
                    onPressed: () async {
                      final u = await autoIconFromAnimation(c, anim.text);
                      if (u != null) {
                        setS(() => icon.text = u);
                      } else if (c.mounted) {
                        toast(c, 'İlk kare alınamadı.', error: true);
                      }
                    },
                  ),
                ),
              TextField(controller: anim, decoration: const InputDecoration(labelText: 'Animasyon adresi (https veya yüklenen dosya)')),
              Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: mediaPreview(anim.text)),
              Row(children: [
                const Text('Şeffaflık:  ', style: TextStyle(color: Colors.white70)),
                DropdownButton<String>(
                  value: alphaSide,
                  items: const [
                    DropdownMenuItem(value: 'auto', child: Text('Otomatik')),
                    DropdownMenuItem(value: 'left', child: Text('Sol yarıda (siyah-beyaz)')),
                    DropdownMenuItem(value: 'right', child: Text('Sağ yarıda (siyah-beyaz)')),
                  ],
                  onChanged: (v) => setS(() => alphaSide = v ?? 'auto'),
                ),
              ]),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  icon: const Icon(Icons.upload_file),
                  label: const Text('Animasyonu telefondan yükle'),
                  onPressed: () async {
                    final m = await pickAndUploadMedia(c, alpha: alphaSide);
                    if (m == null) return;
                    setS(() {
                      anim.text = m['url'].toString();
                      format = 'auto';
                    });
                    if (c.mounted) toast(c, 'Yüklendi: ${m['kind']} (${(((m['size'] as num?) ?? 0) / 1048576).toStringAsFixed(1)} MB). ${m['note'] ?? ''}');
                    final serverIcon = m['iconUrl']?.toString();
                    if (!c.mounted) return;
                    if (icon.text.trim().isEmpty && serverIcon != null && serverIcon.isNotEmpty) {
                      setS(() => icon.text = serverIcon);
                      if (c.mounted) toast(c, 'Küçük resim otomatik oluşturuldu.');
                    } else if (icon.text.trim().isEmpty && c.mounted) {
                      final u = await autoIconFromAnimation(c, anim.text);
                      if (u != null) {
                        setS(() => icon.text = u);
                        if (c.mounted) toast(c, 'İkon animasyonun ilk karesinden otomatik oluşturuldu.');
                      } else if (c.mounted) {
                        toast(c, 'Küçük resim şimdi alınamadı; boş bırakırsan sunucu kaydederken kendisi oluşturur.', error: true);
                      }
                    }
                  },
                ),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: format,
                decoration: const InputDecoration(labelText: 'Animasyon biçimi'),
                items: const [
                  DropdownMenuItem(value: 'auto', child: Text('Otomatik (uzantıdan)')),
                  DropdownMenuItem(value: 'mp4', child: Text('Şeffaf MP4 (VAP)')),
                  DropdownMenuItem(value: 'lottie', child: Text('Lottie (.json)')),
                  DropdownMenuItem(value: 'svga', child: Text('SVGA')),
                  DropdownMenuItem(value: 'webp', child: Text('WebP')),
                  DropdownMenuItem(value: 'gif', child: Text('GIF')),
                  DropdownMenuItem(value: 'png', child: Text('PNG')),
                ],
                onChanged: (v) => setS(() => format = v ?? 'auto'),
              ),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'Hediye sekmesi'),
                items: const [
                  DropdownMenuItem(value: 'popular', child: Text('Popüler')),
                  DropdownMenuItem(value: 'event', child: Text('Etkinlik')),
                  DropdownMenuItem(value: 'private', child: Text('Kişiye Özel')),
                  DropdownMenuItem(value: 'vip', child: Text('Vip (WIP 3+)')),
                  DropdownMenuItem(value: 'lucky', child: Text('Şanslı')),
                  DropdownMenuItem(value: 'cp', child: Text('CP (yakınlık 1,5 kat)')),
                ],
                onChanged: (v) => setS(() => category = v ?? 'popular'),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Ekle')),
          ],
        ),
      ),
    );
    final body = {
      'name': name.text.trim(),
      'coinPrice': price.text.trim(),
      'iconUrl': icon.text.trim().isEmpty ? null : icon.text.trim(),
      'animationUrl': anim.text.trim().isEmpty ? null : anim.text.trim(),
      if (format != 'auto') 'animationFormat': format,
      'category': category,
    };
    name.dispose();
    price.dispose();
    icon.dispose();
    anim.dispose();
    if (ok != true || !context.mounted) return;
    final r = await guard(context, () => Api.post('/api/admin/gifts', body));
    if (r != null && context.mounted) toast(context, 'Hediye eklendi. Kimlik: ${r['id']}');
  }

  Future<void> _storeForm(BuildContext context) async {
    final name = TextEditingController();
    final url = TextEditingController();
    final price = TextEditingController(text: '500000');
    final days = TextEditingController(text: '14');
    var category = 'frame';
    var forSale = true;
    var alphaSide = 'auto';
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setS) => AlertDialog(
          title: const Text('Mağaza ürünü ekle'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButton<String>(
                isExpanded: true,
                value: category,
                items: const [
                  DropdownMenuItem(value: 'frame', child: Text('Çerçeve')),
                  DropdownMenuItem(value: 'chat_bubble', child: Text('Sohbet Balonu')),
                  DropdownMenuItem(value: 'entrance_effect', child: Text('Özel Giriş')),
                  DropdownMenuItem(value: 'mini_card', child: Text('Profil Kartı')),
                  DropdownMenuItem(value: 'room_card', child: Text('Oda Kartı')),
                  DropdownMenuItem(value: 'mic_wave', child: Text('Mikrofon Dalgası')),
                  DropdownMenuItem(value: 'vehicle', child: Text('Araç')),
                  DropdownMenuItem(value: 'badge', child: Text('Rozet (yalnızca yönetici verir)')),
                ],
                onChanged: (v) => setS(() => category = v ?? 'frame'),
              ),
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Ad')),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Mağazada satılsın'), subtitle: const Text('Kapalıysa yalnızca sen kullanıcıya verirsin'), value: forSale && category != 'badge', onChanged: category == 'badge' ? null : (v) => setS(() => forSale = v)),
              TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Fiyat (coin)')),
              TextField(controller: days, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Süre (gün)')),
              TextField(controller: url, decoration: const InputDecoration(labelText: 'Görsel/animasyon adresi')),
              Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: mediaPreview(url.text, frame: category == 'frame')),
              Row(children: [
                const Text('MP4 şeffaflık:  ', style: TextStyle(color: Colors.white70)),
                DropdownButton<String>(
                  value: alphaSide,
                  items: const [
                    DropdownMenuItem(value: 'auto', child: Text('Otomatik')),
                    DropdownMenuItem(value: 'left', child: Text('Sol yarıda')),
                    DropdownMenuItem(value: 'right', child: Text('Sağ yarıda')),
                  ],
                  onChanged: (v) => setS(() => alphaSide = v ?? 'auto'),
                ),
              ]),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  icon: const Icon(Icons.upload_file),
                  label: const Text('Telefondan yükle'),
                  onPressed: () async {
                    final m = await pickAndUploadMedia(c, alpha: alphaSide, frame: category == 'frame');
                    if (m == null) return;
                    setS(() => url.text = m['url'].toString());
                  },
                ),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Ekle')),
          ],
        ),
      ),
    );
    final body = {
      'category': category,
      'name': name.text.trim(),
      'imageUrl': url.text.trim(),
      'priceCoins': price.text.trim(),
      'durationDays': int.tryParse(days.text.trim()) ?? 14,
      'forSale': forSale,
    };
    name.dispose();
    url.dispose();
    price.dispose();
    days.dispose();
    if (ok != true || !context.mounted) return;
    final r = await guard(context, () => Api.post('/api/admin/store/items', body));
    if (r != null && context.mounted) toast(context, 'Mağazaya eklendi.');
  }

  Future<void> _frameForm(BuildContext context) async {
    final name = TextEditingController();
    final url = TextEditingController();
    var alphaSide = 'auto';
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setS) => AlertDialog(
          title: const Text('Çerçeve ekle'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Ad')),
              TextField(controller: url, decoration: const InputDecoration(labelText: 'Görsel adresi (https veya yüklenen dosya)')),
              Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: mediaPreview(url.text, frame: true)),
              Row(children: [
                const Text('MP4 şeffaflık:  ', style: TextStyle(color: Colors.white70)),
                DropdownButton<String>(
                  value: alphaSide,
                  items: const [
                    DropdownMenuItem(value: 'auto', child: Text('Otomatik')),
                    DropdownMenuItem(value: 'left', child: Text('Sol yarıda')),
                    DropdownMenuItem(value: 'right', child: Text('Sağ yarıda')),
                  ],
                  onChanged: (v) => setS(() => alphaSide = v ?? 'auto'),
                ),
              ]),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton.icon(
                  icon: const Icon(Icons.upload_file),
                  label: const Text('Telefondan yükle (svga, mp4, webp, gif, json)'),
                  onPressed: () async {
                    final m = await pickAndUploadMedia(c, alpha: alphaSide, frame: true);
                    if (m == null) return;
                    setS(() => url.text = m['url'].toString());
                    if (c.mounted && m['note'] != null) toast(c, m['note'].toString());
                  },
                ),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Ekle')),
          ],
        ),
      ),
    );
    final body = {'name': name.text.trim(), 'imageUrl': url.text.trim()};
    name.dispose();
    url.dispose();
    if (ok != true || !context.mounted) return;
    final r = await guard(context, () => Api.post('/api/admin/frames', body));
    if (r != null && context.mounted) toast(context, 'Çerçeve eklendi. Kimlik: ${r['id']}');
  }

  /// Birçok dosyayı bir seferde yükler; her dosya için ad (dosya adından), fiyat ve sekme aynı olur.
  Future<void> _bulk(BuildContext context, {required bool frames}) async {
    final price = TextEditingController(text: '100');
    var category = 'popular';
    var alpha = 'auto';
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setS) => AlertDialog(
          title: Text(frames ? 'Toplu çerçeve yükle' : 'Toplu hediye yükle'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Sonraki ekranda birden fazla dosya seçersin. Ad dosya adından alınır.', style: TextStyle(color: Colors.white70)),
              if (!frames) TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Hepsi için coin fiyatı')),
              if (!frames)
                DropdownButtonFormField<String>(
                  value: category,
                  decoration: const InputDecoration(labelText: 'Hediye sekmesi'),
                  items: const [
                    DropdownMenuItem(value: 'popular', child: Text('Popüler')),
                    DropdownMenuItem(value: 'event', child: Text('Etkinlik')),
                    DropdownMenuItem(value: 'private', child: Text('Kişiye Özel')),
                    DropdownMenuItem(value: 'vip', child: Text('Vip (WIP 3+)')),
                    DropdownMenuItem(value: 'lucky', child: Text('Şanslı')),
                    DropdownMenuItem(value: 'cp', child: Text('CP (yakınlık 1,5 kat)')),
                  ],
                  onChanged: (v) => setS(() => category = v ?? 'popular'),
                ),
              DropdownButtonFormField<String>(
                value: alpha,
                decoration: const InputDecoration(labelText: 'MP4 şeffaflık maskesi'),
                items: const [
                  DropdownMenuItem(value: 'auto', child: Text('Otomatik')),
                  DropdownMenuItem(value: 'left', child: Text('Sol yarıda')),
                  DropdownMenuItem(value: 'right', child: Text('Sağ yarıda')),
                ],
                onChanged: (v) => setS(() => alpha = v ?? 'auto'),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Dosyaları seç')),
          ],
        ),
      ),
    );
    final priceText = price.text.trim();
    price.dispose();
    if (ok != true || !context.mounted) return;
    final r = await FilePicker.platform.pickFiles(type: FileType.any, allowMultiple: true);
    if (r == null || r.files.isEmpty || !context.mounted) return;
    final log = <String>[];
    var done = 0;
    for (final f in r.files) {
      final path = f.path;
      final base = f.name.contains('.') ? f.name.substring(0, f.name.lastIndexOf('.')) : f.name;
      final name = base.length < 2 ? '$base ' : (base.length > 80 ? base.substring(0, 80) : base);
      if (path == null) {
        log.add('✗ ${f.name}: dosya okunamadı');
        continue;
      }
      if (context.mounted) toast(context, 'Yükleniyor ${done + log.length + 1}/${r.files.length}: ${f.name}');
      try {
        final bytes = await File(path).readAsBytes();
        final m = await Api.postBytes('/api/admin/media', bytes, 'application/octet-stream', query: {'alpha': alpha, if (frames) 'purpose': 'frame'});
        if (frames) {
          await Api.post('/api/admin/frames', {'name': name, 'imageUrl': m['url']});
        } else {
          await Api.post('/api/admin/gifts', {
            'name': name,
            'coinPrice': priceText,
            'animationUrl': m['url'],
            if (m['iconUrl'] != null) 'iconUrl': m['iconUrl'],
            'animationFormat': m['format'],
            'category': category,
          });
        }
        done++;
      } catch (e) {
        log.add('✗ ${f.name}: ${errorText(e)}');
      }
    }
    if (!context.mounted) return;
    await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('$done / ${r.files.length} eklendi'),
        content: SingleChildScrollView(child: Text(log.isEmpty ? 'Hepsi eklendi.' : log.join('\n'))),
        actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Tamam'))],
      ),
    );
  }

  Future<void> _create(BuildContext context, String title, List<String> labels, String path, Map<String, dynamic> Function(Map<String, String>) body) async {
    final f = await formDialog(context, title, labels);
    if (f == null || !context.mounted) return;
    final r = await guard(context, () => Api.post(path, body(f)));
    if (r != null && context.mounted) toast(context, 'Oluşturuldu. Kimlik: ${r['id']}');
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Adresler https:// ile başlamalıdır. Oluşan kimlik, envanterde "Anahtar" olarak kullanılır.', style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 12),
      FilledButton.icon(
        icon: const Icon(Icons.emoji_events),
        label: const Text('Haftalık etkinlikler (Çift, Kral/Kraliçe, Yıldız)'),
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AdminWeeklyEventsPage())),
      ),
      const SizedBox(height: 8),
      FilledButton.icon(
        icon: const Icon(Icons.inventory_2_outlined),
        label: const Text('Hazır hediye paketi yükle / durum'),
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AssetPackPage())),
      ),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        icon: const Icon(Icons.grid_view),
        label: const Text('Katalog listesi (önizleme)'),
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CatalogListPage())),
      ),
      const SizedBox(height: 8),
      FilledButton.icon(
        icon: const Icon(Icons.card_giftcard),
        label: const Text('Hediye ekle'),
        onPressed: () => _giftForm(context),
      ),
      const SizedBox(height: 8),
      FilledButton.icon(
        icon: const Icon(Icons.library_add),
        label: const Text('Toplu hediye yükle (çok dosya)'),
        onPressed: () => _bulk(context, frames: false),
      ),
      const SizedBox(height: 8),
      FilledButton.icon(
        icon: const Icon(Icons.library_add),
        label: const Text('Toplu çerçeve yükle (çok dosya)'),
        onPressed: () => _bulk(context, frames: true),
      ),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        icon: const Icon(Icons.monetization_on),
        label: const Text('Coin paketleri (Yükleme Merkezi)'),
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CoinPackagesPage())),
      ),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        icon: const Icon(Icons.list_alt),
        label: const Text('Mağaza ürünleri (aç/kapat/sil)'),
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StoreItemsPage())),
      ),
      const SizedBox(height: 8),
      // Deneme: her türden birer örnek (araç, balon, mikrofon dalgası, çerçeve, profil/oda kartı) yöneticinin kendisine
      // 30 günlüğüne verilip takılır; mağazada satılmaz.
      FilledButton.tonalIcon(
        icon: const Icon(Icons.science_outlined),
        label: const Text('Test örneklerini bana ekle ve tak'),
        onPressed: () async {
          final r = await guard(context, () => Api.post('/api/admin/store/samples'));
          if (r != null && context.mounted) {
            toast(context, 'Takıldı: ${((r['items'] as List?) ?? const []).join(', ')}. Bir odaya girip dene (araç girişte oynar).');
          }
        },
      ),
      const SizedBox(height: 8),
      FilledButton.icon(
        icon: const Icon(Icons.storefront),
        label: const Text('Mağaza ürünü ekle'),
        onPressed: () => _storeForm(context),
      ),
      const SizedBox(height: 8),
      FilledButton.icon(
        icon: const Icon(Icons.filter_frames),
        label: const Text('Avatar çerçevesi ekle'),
        onPressed: () => _frameForm(context),
      ),
      const SizedBox(height: 8),
      FilledButton.icon(
        icon: const Icon(Icons.auto_awesome),
        label: const Text('Giriş efekti ekle'),
        onPressed: () => _create(context, 'Giriş efekti ekle', ['Ad', 'Animasyon adresi (Lottie json)'], '/api/admin/entrance-effects',
            (f) => {'name': f['Ad'], 'animationUrl': f['Animasyon adresi (Lottie json)']}),
      ),
    ]);
  }
}

// ------------------------------------------------------------------ Şikâyetler
class _ReportsTab extends StatefulWidget {
  const _ReportsTab();

  @override
  State<_ReportsTab> createState() => _ReportsTabState();
}

class _ReportsTabState extends State<_ReportsTab> {
  int _v = 0;

  Future<void> _resolve(Map<String, dynamic> r, String status) async {
    final note = await askText(context, status == 'resolved' ? 'Çözüm notu (isteğe bağlı)' : 'Reddetme notu (isteğe bağlı)');
    if (!mounted) return;
    final res = await guard(context, () => Api.post('/api/admin/reports/${r['id']}/resolve', {'status': status, if (note != null) 'note': note}));
    if (res != null && mounted) setState(() => _v++);
  }

  Future<void> _ban(Map<String, dynamic> r) async {
    final id = r['targetUserId'];
    if (id == null || !await confirm(context, '@${r['target']} hesabı yasaklansın mı?', action: 'Yasakla')) return;
    if (!mounted) return;
    final res = await guard(context, () => Api.post('/api/admin/users/$id/ban', {'reason': 'Şikâyet: ${r['reason']}'}));
    if (res != null && mounted) toast(context, 'Hesap yasaklandı.');
  }

  @override
  Widget build(BuildContext context) {
    return AsyncBody<List<Map<String, dynamic>>>(
      version: _v,
      load: () async => listOf((await Api.get('/api/admin/reports'))['reports']),
      builder: (context, reports, reload) => reports.isEmpty
          ? const Center(child: Text('Açık şikâyet yok.'))
          : RefreshIndicator(
              onRefresh: reload,
              child: ListView(padding: const EdgeInsets.all(12), children: [
                for (final r in reports)
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${r['kind']} · ${r['reason']}', style: Theme.of(context).textTheme.titleSmall),
                        Text('Şikâyet eden: @${r['reporter']}${r['target'] != null ? '  →  @${r['target']}' : ''}'),
                        if ((r['details'] ?? '').toString().isNotEmpty) Text(r['details'].toString(), style: const TextStyle(color: Colors.white70)),
                        if (r['roomId'] != null) Text('Oda: ${r['roomId']}', style: const TextStyle(color: Colors.white54, fontSize: 11)),
                        const SizedBox(height: 8),
                        Wrap(spacing: 8, children: [
                          FilledButton.tonal(onPressed: () => _resolve(r, 'resolved'), child: const Text('Çözüldü')),
                          OutlinedButton(onPressed: () => _resolve(r, 'dismissed'), child: const Text('Reddet')),
                          if (Session.isStaff && r['targetUserId'] != null)
                            OutlinedButton(style: OutlinedButton.styleFrom(foregroundColor: Colors.redAccent), onPressed: () => _ban(r), child: const Text('Hesabı yasakla')),
                        ]),
                      ]),
                    ),
                  ),
              ]),
            ),
    );
  }
}

// ------------------------------------------------------------------- Güvenlik
class _SecurityTab extends StatefulWidget {
  const _SecurityTab();

  @override
  State<_SecurityTab> createState() => _SecurityTabState();
}

class _SecurityTabState extends State<_SecurityTab> {
  int _v = 0;

  Future<Map<String, dynamic>> _load() async {
    final e = await Api.get('/api/admin/security/events', query: {'limit': '60'});
    final b = await Api.get('/api/admin/security/blocks');
    return {'events': listOf(e['events']), 'stats': mapOf(e['stats']), 'blocks': listOf(b['blocks'])};
  }

  Future<void> _addBlock() async {
    final f = await formDialog(context, 'IP engelle', ['IP adresi', 'Süre (dakika, boş = süresiz)', 'Neden']);
    if (f == null || !mounted) return;
    final minutes = int.tryParse(f['Süre (dakika, boş = süresiz)'] ?? '');
    final r = await guard(context, () => Api.post('/api/admin/security/blocks', {'ip': f['IP adresi'], if (minutes != null) 'minutes': minutes, 'reason': f['Neden']}));
    if (r != null && mounted) setState(() => _v++);
  }

  Future<void> _unblock(String ip) async {
    final r = await guard(context, () => Api.delete('/api/admin/security/blocks/${Uri.encodeComponent(ip)}'));
    if (r != null && mounted) setState(() => _v++);
  }

  @override
  Widget build(BuildContext context) {
    return AsyncBody<Map<String, dynamic>>(
      version: _v,
      load: _load,
      builder: (context, data, reload) {
        final events = listOf(data['events']);
        final blocks = listOf(data['blocks']);
        final stats = mapOf(data['stats']) ?? {};
        return RefreshIndicator(
          onRefresh: reload,
          child: ListView(padding: const EdgeInsets.all(12), children: [
            Card(child: ListTile(leading: const Icon(Icons.shield), title: const Text('Güvenlik duvarı'), subtitle: Text('Aktif yasak: ${stats['bans'] ?? 0} · Kaydedilen olay: ${stats['eventsLogged'] ?? 0}'))),
            Row(children: [
              Text('Engelli IP\'ler (${blocks.length})', style: Theme.of(context).textTheme.titleMedium),
              const Spacer(),
              TextButton.icon(onPressed: _addBlock, icon: const Icon(Icons.add), label: const Text('Ekle')),
            ]),
            for (final b in blocks)
              ListTile(
                dense: true,
                leading: const Icon(Icons.block, color: Colors.redAccent),
                title: Text(b['ip'].toString()),
                subtitle: Text('${b['reason'] ?? ''}${b['until'] != null ? '\nBitiş: ${b['until']}' : '\nSüresiz'}'),
                trailing: IconButton(icon: const Icon(Icons.lock_open), tooltip: 'Engeli kaldır', onPressed: () => _unblock(b['ip'].toString())),
              ),
            const Divider(),
            Text('Son güvenlik olayları', style: Theme.of(context).textTheme.titleMedium),
            for (final e in events)
              ListTile(
                dense: true,
                leading: Icon(e['event_type'].toString().startsWith('ip_') ? Icons.gavel : Icons.warning_amber, size: 20),
                title: Text(e['event_type'].toString()),
                subtitle: Text('${e['ip'] ?? '-'} · ${e['created_at']}'),
              ),
          ]),
        );
      },
    );
  }
}


/// Öğe ver: kategori seç, listeden öğeyi seç, gün yaz, gönder (WIP verme gibi tek ekranda).
class GrantItemPage extends StatefulWidget {
  final Map<String, dynamic> user;
  final String initialCategory;
  const GrantItemPage({super.key, required this.user, this.initialCategory = 'frame'});

  @override
  State<GrantItemPage> createState() => _GrantItemPageState();
}

class _GrantItemPageState extends State<GrantItemPage> {
  static const _cats = [
    ['frame', 'Çerçeve'],
    ['colored_id', 'Renkli ID'],
    ['badge', 'Rozet'],
    ['chat_bubble', 'Sohbet Balonu'],
    ['entrance_effect', 'Giriş Efekti'],
    ['mini_card', 'Profil Kartı'],
    ['room_card', 'Oda Kartı'],
    ['mic_wave', 'Mikrofon Dalgası'],
    ['vehicle', 'Araç'],
  ];
  late String _cat = widget.initialCategory;
  String? _selected;
  final _days = TextEditingController(text: '30');
  bool _sending = false;

  @override
  void dispose() {
    _days.dispose();
    super.dispose();
  }

  Future<void> _send(List<Map<String, dynamic>> items) async {
    final item = items.where((i) => i['key'] == _selected).firstOrNull;
    if (item == null) return toast(context, 'Önce bir öğe seç.', error: true);
    final d = _days.text.trim();
    final days = d.isEmpty || d == '0' ? null : int.tryParse(d);
    if (d.isNotEmpty && d != '0' && days == null) return toast(context, 'Gün sayı olmalı.', error: true);
    setState(() => _sending = true);
    final r = await guard(context, () => Api.post('/api/admin/users/${widget.user['id']}/grant', {'category': _cat, 'itemKey': item['key'], if (days != null) 'days': days}));
    if (!mounted) return;
    setState(() => _sending = false);
    if (r != null) toast(context, '"${item['name']}" ${widget.user['displayName']} kullanıcısına verildi.');
  }

  /// WIP öğelerinin önizlemesi (kodla çizilir): çerçeve, rozet, sohbet balonu, giriş efekti, araç.
  Widget _wipPreview(int level, double size) => wipItemArt(_cat, level, size);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Öğe ver · ${widget.user['displayName']}')),
      body: Column(children: [
        SizedBox(
          height: 48,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6), children: [
            for (final c in _cats)
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: ChoiceChip(label: Text(c[1]), selected: _cat == c[0], onSelected: (_) => setState(() {
                      _cat = c[0];
                      _selected = null;
                    })),
              ),
          ]),
        ),
        Expanded(
          child: AsyncBody<List<Map<String, dynamic>>>(
            key: ValueKey(_cat),
            load: () async => listOf((await Api.get('/api/admin/grantables', query: {'category': _cat}))['items']),
            builder: (context, items, reload) => Column(children: [
              Expanded(
                child: items.isEmpty
                    ? const Center(child: Text('Bu kategoride öğe yok. Katalog sekmesinden ekle.'))
                    : GridView.builder(
                        padding: const EdgeInsets.all(10),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: 0.85),
                        itemCount: items.length,
                        itemBuilder: (_, i) {
                          final it = items[i];
                          final sel = it['key'] == _selected;
                          return InkWell(
                            onTap: () => setState(() => _selected = it['key'].toString()),
                            child: Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: sel ? Colors.greenAccent : Colors.white24, width: sel ? 2.5 : 1)),
                              child: Column(children: [
                                Expanded(
                                  child: LayoutBuilder(
                                    builder: (c, box) => Center(
                                      child: _cat == 'colored_id'
                                          ? FittedBox(
                                              child: ColoredIdText(
                                                text: 'ID: ${widget.user['publicId'] ?? '12345678'}',
                                                tier: (it['idColor'] ?? it['key'].toString().split(':').last).toString(),
                                                fontSize: 13,
                                              ),
                                            )
                                          : it['wip'] == true
                                              ? _wipPreview(int.tryParse(it['key'].toString().split(':').last) ?? 1, box.biggest.shortestSide)
                                              : mediaPreview(it['imageUrl'] as String?, frame: _cat == 'frame', size: box.biggest.shortestSide),
                                    ),
                                  ),
                                ),
                                Text(it['name'].toString(), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                              ]),
                            ),
                          );
                        },
                      ),
              ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
                  child: Row(children: [
                    SizedBox(width: 110, child: TextField(controller: _days, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Gün (0 = süresiz)', isDense: true, border: OutlineInputBorder()))),
                    const SizedBox(width: 10),
                    Expanded(child: FilledButton.icon(onPressed: _sending || _selected == null ? null : () => _send(items), icon: const Icon(Icons.send), label: Text(_sending ? 'Gönderiliyor…' : 'Gönder'))),
                  ]),
                ),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}

/// Mağaza ürünlerini listele; aç/kapat (kapalı ürün mağazada ve "öğe ver" listesinde görünmez).
class StoreItemsPage extends StatefulWidget {
  const StoreItemsPage({super.key});

  @override
  State<StoreItemsPage> createState() => _StoreItemsPageState();
}

class _StoreItemsPageState extends State<StoreItemsPage> {
  int _v = 0;

  Future<void> _edit(Map<String, dynamic> it) async {
    final badge = it['category'] == 'badge';
    final v = await editItemDialog(
      context,
      title: 'Ürünü düzenle',
      name: it['name'].toString(),
      price: it['priceCoins']?.toString() ?? '',
      days: (it['durationDays'] as num?)?.toInt() ?? 14,
      forSale: badge ? null : it['forSale'] != false,
    );
    if (v == null || !mounted) return;
    final price = (v['price'] ?? '').toString();
    final days = (v['days'] ?? '').toString();
    final body = <String, dynamic>{
      'name': v['name'],
      if (price.isNotEmpty) 'priceCoins': price,
      if (days.isNotEmpty) 'durationDays': days,
      if (!badge) 'forSale': v['forSale'],
    };
    final r = await guard(context, () => Api.post('/api/admin/store/items/${it['id']}/edit', body));
    if (r != null && mounted) {
      toast(context, 'Kaydedildi.');
      setState(() => _v++);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mağaza ürünleri (dokun: düzenle · sola kaydır: sil)')),
      body: AsyncBody<List<Map<String, dynamic>>>(
        version: _v,
        load: () async => listOf((await Api.get('/api/admin/store/items'))['items']),
        builder: (context, items, reload) => items.isEmpty
            ? const Center(child: Text('Henüz ürün yok.'))
            : ListView(children: [
                for (final it in items)
                  Dismissible(
                    key: ValueKey(it['id']),
                    direction: DismissDirection.endToStart,
                    background: Container(color: Colors.red, alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20), child: const Icon(Icons.delete, color: Colors.white)),
                    confirmDismiss: (_) async {
                      final ok = await showDialog<bool>(
                        context: context,
                        builder: (c) => AlertDialog(
                          title: const Text('Ürün silinsin mi?'),
                          content: Text('"${it['name']}" silinecek. Daha önce alındıysa silinmez, gizlenir.'),
                          actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Sil'))],
                        ),
                      );
                      if (ok != true || !context.mounted) return false;
                      final r = await guard(context, () => Api.delete('/api/admin/store/items/${it['id']}'));
                      if (r != null && context.mounted) {
                        toast(context, r['hidden'] == true ? (r['note'] ?? 'Gizlendi.').toString() : 'Silindi.');
                        setState(() => _v++);
                      }
                      return false;
                    },
                    child: ListTile(
                    leading: SizedBox(width: 48, height: 48, child: mediaPreview(it['imageUrl'] as String?, frame: it['category'] == 'frame', size: 48)),
                    title: Text(it['name'].toString()),
                    subtitle: Text('${it['category']} · ${fmtNumber(it['priceCoins'])} coin · ${it['durationDays']} gün${it['forSale'] == false ? ' · mağazada değil' : ''}'),
                    onTap: () => _edit(it),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(tooltip: 'Düzenle', icon: const Icon(Icons.edit_outlined), onPressed: () => _edit(it)),
                      Switch(
                        value: it['isActive'] == true,
                        onChanged: (v) async {
                          final r = await guard(context, () => Api.post('/api/admin/store/items/${it['id']}/active', {'isActive': v}));
                          if (r != null && mounted) setState(() => _v++);
                        },
                      ),
                    ]),
                  ),
                  ),
              ]),
      ),
    );
  }
}


/// Hazır hediye / çerçeve paketi: TR-Live-paket-N.zip dosyaları telefondan doğrudan sunucuya yüklenir ve hemen uygulanır
/// (GitHub gerekmez). Üstte sunucu sürümü ve kurulu paket durumu görünür.
class AssetPackPage extends StatefulWidget {
  const AssetPackPage({super.key});

  @override
  State<AssetPackPage> createState() => _AssetPackPageState();
}

class _AssetPackPageState extends State<AssetPackPage> {
  Map<String, dynamic>? _status;
  Map<String, dynamic>? _server;
  String? _error;
  bool _busy = false;
  bool _showLogs = false;
  final List<String> _log = [];

  @override
  void initState() {
    super.initState();
    _load();
    _loadServer();
  }

  Future<void> _loadServer() async {
    try {
      final r = await Api.get('/api/admin/server/status');
      if (mounted) setState(() => _server = r);
    } catch (_) {
      // Eski sunucuda bu bilgi yok.
    }
  }

  /// Depo gizliyken sunucunun güncellemeyi indirebilmesi için GitHub erişim anahtarı (yalnızca okuma).
  Future<void> _gitToken() async {
    final ctl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('GitHub erişim anahtarı'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text(
              'Depo gizliyken sunucu güncellemeleri bu anahtarla indirir.\n\n'
              'GitHub → sağ üstte profil → Settings → Developer settings → Personal access tokens → Fine-grained tokens → '
              'Generate new token:\n'
              '• Repository access: Only select repositories → Tr-Live\n'
              '• Permissions → Contents: Read-only\n'
              '• Expiration: en uzun süre\n\n'
              'Anahtarı deponun sahibi olan hesapta (Merdo2134) oluştur. Oluşan anahtarı (github_pat_ ile başlar) buraya yapıştır. Anahtar yalnızca sunucuya kaydedilir, uygulamada '
              'görünmez. Boş bırakıp kaydedersen silinir.',
              style: TextStyle(color: Colors.white70, fontSize: 13),
            ),
            const SizedBox(height: 10),
            TextField(controller: ctl, obscureText: true, autocorrect: false, enableSuggestions: false, decoration: const InputDecoration(labelText: 'Anahtar')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Kaydet')),
        ],
      ),
    );
    final token = ctl.text.trim();
    WidgetsBinding.instance.addPostFrameCallback((_) => ctl.dispose());
    if (ok != true || !mounted) return;
    final r = await guard(context, () => Api.post('/api/admin/server/git-token', {'token': token}));
    if (r == null || !mounted) return;
    toast(context, r['saved'] == true ? 'Anahtar kaydedildi. Sunucu birkaç dakika içinde güncellemeyi dener.' : 'Anahtar silindi.');
    _loadServer();
  }

  Future<void> _updateServer() async {
    final r = await guard(context, () => Api.post('/api/admin/server/update'));
    if (r == null || !mounted) return;
    toast(context, 'Güncelleme istendi. Sunucu birkaç dakika içinde yeni sürümü kurar; bu sayfayı sonra yenileyin.');
  }

  Future<void> _load() async {
    try {
      final r = await Api.get('/api/admin/asset-pack/status');
      if (!mounted) return;
      setState(() {
        _status = r;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e is ApiException && e.statusCode == 404
          ? 'Sunucu bu özelliği tanımıyor: sunucu henüz bu sürüme güncellenmemiş. Sunucu panelinde "Şimdi güncelle"ye basın; '
              'olmazsa paneldeki "Kurulum kaydı" bölümünün ekran görüntüsünü gönderin.'
          : errorText(e));
    }
  }

  static const _statusText = {
    'added': 'eklendi',
    'updated': 'yenilendi',
    'same': 'zaten güncel',
    'deleted': 'silinmiş (eklenmedi)',
    'error': 'HATA',
    'incomplete': 'eksik dosya',
    'unknown': 'tanınmadı',
  };

  Future<void> _upload() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.any, allowMultiple: true);
    if (r == null || r.files.isEmpty || !mounted) return;
    setState(() {
      _busy = true;
      _log.clear();
    });
    var i = 0;
    for (final f in r.files) {
      i++;
      final path = f.path;
      if (path == null) {
        setState(() => _log.add('✗ ${f.name}: dosya okunamadı'));
        continue;
      }
      setState(() => _log.add('… ${f.name} yükleniyor ($i/${r.files.length})'));
      try {
        final bytes = await File(path).readAsBytes();
        if (bytes.length > 40 * 1024 * 1024) throw Exception('40 MB sınırını aşıyor');
        final res = await Api.postBytes('/api/admin/asset-pack', bytes, 'application/zip');
        if (!mounted) return;
        final items = listOf(res['results']);
        final bad = [for (final it in items) if (it['status'] == 'error' || it['status'] == 'incomplete' || it['status'] == 'unknown') '${it['name']}: ${_statusText[it['status']] ?? it['status']}'];
        setState(() {
          _log.removeLast();
          _log.add('✓ ${f.name}: ${res['added']} eklendi, ${res['updated']} yenilendi, ${res['same']} zaten güncel'
              '${(res['deleted'] ?? 0) != 0 ? ', ${res['deleted']} silinmiş' : ''}${(res['failed'] ?? 0) != 0 ? ', ${res['failed']} hatalı' : ''}');
          for (final b in bad) {
            _log.add('   ✗ $b');
          }
        });
      } catch (e) {
        if (!mounted) return;
        setState(() {
          _log.removeLast();
          _log.add('✗ ${f.name}: ${errorText(e)}');
        });
      }
    }
    if (!mounted) return;
    setState(() => _busy = false);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final st = _status;
    final versions = mapOf(st?['versions']) ?? const {};
    final missing = listOf(st?['missing']);
    final deleted = listOf(st?['deleted']);
    return Scaffold(
      appBar: AppBar(title: const Text('Hazır hediye paketi')),
      body: RefreshIndicator(
        onRefresh: () async {
          await _load();
          await _loadServer();
        },
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: _error != null
                  ? Text(_error!, style: const TextStyle(color: Colors.redAccent))
                  : st == null
                      ? const Center(child: CircularProgressIndicator())
                      : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('Sunucu sürümü: ${st['serverVersion'] ?? '?'}', style: const TextStyle(fontWeight: FontWeight.w700)),
                          const SizedBox(height: 6),
                          Text('Kurulu: ${st['installed']} / ${(st['gifts'] as num? ?? 0) + (st['frames'] as num? ?? 0)} (hediye ${st['gifts']}, çerçeve ${st['frames']})'),
                          if (versions.isNotEmpty)
                            Text('Sürümler: ${[for (final e in versions.entries) 'paket ${e.key}: ${e.value}'].join(' · ')}', style: const TextStyle(color: Colors.white70)),
                          if (missing.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child: Text('Henüz kurulmayan ${missing.length}: ${missing.take(12).map((m) => m['name']).join(', ')}${missing.length > 12 ? '…' : ''}',
                                  style: const TextStyle(color: Colors.amberAccent)),
                            ),
                          if (deleted.isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child: Text('Silindiği için eklenmeyen ${deleted.length}: ${deleted.take(12).map((m) => m['name']).join(', ')}',
                                  style: const TextStyle(color: Colors.white54)),
                            ),
                        ]),
            ),
          ),
          if (_server != null) ...[
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Sunucu', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _server?['available'] == true ? _updateServer : null,
                        icon: const Icon(Icons.system_update_alt),
                        label: const Text('Şimdi güncelle'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => setState(() => _showLogs = !_showLogs),
                        icon: Icon(_showLogs ? Icons.expand_less : Icons.receipt_long),
                        label: Text(_showLogs ? 'Kayıtları gizle' : 'Kayıtlar'),
                      ),
                    ),
                  ]),
                  const SizedBox(height: 8),
                  Row(children: [
                    Icon(_server?['gitToken'] == true ? Icons.key : Icons.key_off, size: 18, color: _server?['gitToken'] == true ? Colors.greenAccent : Colors.white54),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(_server?['gitToken'] == true ? 'GitHub erişim anahtarı kayıtlı' : 'GitHub erişim anahtarı yok (depo gizliyse gerekli)',
                          style: const TextStyle(color: Colors.white70, fontSize: 13)),
                    ),
                    TextButton(onPressed: _gitToken, child: Text(_server?['gitToken'] == true ? 'Değiştir' : 'Gir')),
                  ]),
                  if (_showLogs) ...[
                    const SizedBox(height: 8),
                    const Text('Güncelleme kaydı', style: TextStyle(color: Colors.white70)),
                    SelectableText((_server?['updateLog'] ?? '-').toString(), style: const TextStyle(fontSize: 11, fontFamily: 'monospace')),
                    const SizedBox(height: 8),
                    const Text('Kurulum kaydı', style: TextStyle(color: Colors.white70)),
                    SelectableText((_server?['installLog'] ?? '-').toString(), style: const TextStyle(fontSize: 11, fontFamily: 'monospace')),
                  ],
                ]),
              ),
            ),
          ],
          const SizedBox(height: 12),
          const Text(
            'TR-Live-paket-1.zip, TR-Live-paket-2.zip … dosyalarını seç (birden fazla seçebilirsin). Her biri sunucuya yüklenir ve '
            'hemen uygulanır: pakette olup sunucuda olmayan hediyeler eklenir, var olanların yalnızca görüntüsü yenilenir '
            '(ad, fiyat, sekme korunur). Yönetimden sildiğin hediye yeniden eklenmez.',
            style: TextStyle(color: Colors.white70),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _busy ? null : _upload,
            icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.upload_file),
            label: Text(_busy ? 'Yükleniyor…' : 'Paket zip dosyalarını seç ve yükle'),
          ),
          const SizedBox(height: 12),
          for (final l in _log) Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: Text(l)),
        ]),
      ),
    );
  }
}
