import test from 'node:test';
import assert from 'node:assert/strict';
import { supportMayCall, banEnd, banExpired, banMessage, mayActOnUser } from '../src/staff_logic.js';
import { canManage } from '../src/room_permissions.js';

test('yardımcı admin yalnızca dar yetkilere erişir', () => {
  assert.ok(supportMayCall('GET', '/users'));
  assert.ok(supportMayCall('POST', '/users/abc/ban'));
  assert.ok(supportMayCall('POST', '/users/abc/unban'));
  assert.ok(supportMayCall('POST', '/users/abc/display-name'));
  assert.ok(supportMayCall('POST', '/users/abc/avatar'));
  // v2.70 web paneli: liste / ayrıntı / bekleyen işler okunabilir; geçmiş, odalar ve hareketler yöneticiye aittir.
  assert.ok(supportMayCall('GET', '/users/list'));
  assert.ok(supportMayCall('GET', '/users/abc/detail'));
  assert.ok(supportMayCall('GET', '/overview/pending'));
  for (const [m, p] of [['GET', '/users/abc/history'], ['GET', '/rooms'], ['GET', '/rooms/abc/detail'], ['POST', '/rooms/abc/close'],
    ['POST', '/rooms/abc/members/x/kick'], ['GET', '/gift-transactions'], ['GET', '/wallet-transactions'], ['GET', '/stats/daily'],
    ['GET', '/families'], ['POST', '/users/abc/detail'], ['GET', '/users/abc/devices']]) assert.equal(supportMayCall(m, p), false, `${m} ${p}`);
  for (const [m, p] of [['POST', '/users/abc/coins'], ['POST', '/users/abc/wip'], ['POST', '/users/abc/staff-role'], ['GET', '/staff'],
    ['POST', '/gifts'], ['PUT', '/agency-config'], ['POST', '/payouts/close'], ['GET', '/finance/audit'], ['POST', '/security/blocks'],
    ['POST', '/users/abc/kyc'], ['POST', '/dealers']]) assert.equal(supportMayCall(m, p), false, `${m} ${p}`);
});

test('ban süresi', () => {
  const now = new Date('2026-10-04T10:00:00Z');
  assert.equal(banEnd(null, now), null);
  assert.equal(banEnd(0, now), null);
  assert.equal(banEnd(24, now).toISOString(), '2026-10-05T10:00:00.000Z');
  assert.equal(banEnd(-1, now), undefined);
  assert.equal(banEnd('abc', now), undefined);
  assert.equal(banEnd(24 * 400, now), undefined);
});

test('süresi dolan ban', () => {
  const now = new Date('2026-10-04T10:00:00Z');
  assert.equal(banExpired({ account_status: 'banned', banned_until: '2026-10-04T09:00:00Z' }, now), true);
  assert.equal(banExpired({ account_status: 'banned', banned_until: '2026-10-04T11:00:00Z' }, now), false);
  assert.equal(banExpired({ account_status: 'banned', banned_until: null }, now), false);
  assert.equal(banExpired({ account_status: 'active', banned_until: null }, now), false);
  assert.match(banMessage({ banned_until: '2026-10-04T11:00:00Z', ban_reason: 'spam' }), /14:00.*spam/);
});

test('yardımcı admin yöneticiyi ve diğer yardımcıyı yönetemez', () => {
  assert.equal(mayActOnUser('support', 'user'), true);
  assert.equal(mayActOnUser('support', 'support'), false);
  assert.equal(mayActOnUser('support', 'admin'), false);
  assert.equal(mayActOnUser('admin', 'support'), true);
  assert.equal(mayActOnUser('admin', 'admin'), false, 'yönetici hesabına kimse dokunamaz');
  assert.equal(mayActOnUser('user', 'user'), false);
});

test('moderatör yetkileri oda sahibine dokunamaz, normal kullanıcıya uygulanır', () => {
  assert.equal(canManage('moderator', 'user', 'moderate'), true);
  assert.equal(canManage('moderator', 'moderator', 'moderate'), false);
  assert.equal(canManage('moderator', 'owner', 'moderate'), false);
  assert.equal(canManage('moderator', 'user', 'role', 'moderator'), false); // moderatör atayamaz
  assert.equal(canManage('owner', 'user', 'role', 'moderator'), true);
  assert.equal(canManage('user', 'user', 'moderate'), false);
});

import { pickNext, hasFreeSeat } from '../src/mic_queue_logic.js';
test('mikrofon sırası: ilk uygun kişi seçilir, uygun olmayanlar düşer', () => {
  const q = [{ user_id: 'a' }, { user_id: 'b' }, { user_id: 'c' }];
  assert.deepEqual(pickNext(q, new Set(['b', 'c'])), { next: 'b', drop: ['a'] });
  assert.deepEqual(pickNext(q, new Set()), { next: null, drop: ['a', 'b', 'c'] });
  assert.deepEqual(pickNext([], new Set(['a'])), { next: null, drop: [] });
});
test('boş koltuk hesabı (0. koltuk sahibin, kilitliler sayılmaz)', () => {
  assert.equal(hasFreeSeat(4, [], [0, 1, 2, 3]), false);
  assert.equal(hasFreeSeat(4, [3], [0, 1, 2]), false);
  assert.equal(hasFreeSeat(4, [], [0, 1, 2]), true);
  assert.equal(hasFreeSeat(2, [], [0]), true);
});

test('oda komutları: yönetim ve yardımcı admin dokunulmazlığı', async () => {
  const { roomStaffShield } = await import('../src/staff_logic.js');
  assert.ok(roomStaffShield('user', 'admin'));
  assert.ok(roomStaffShield('admin', 'admin'));
  assert.ok(roomStaffShield('support', 'support'));
  assert.ok(roomStaffShield('user', 'support'));
  assert.equal(roomStaffShield('admin', 'support'), null);
  assert.equal(roomStaffShield('user', 'user'), null);
});
