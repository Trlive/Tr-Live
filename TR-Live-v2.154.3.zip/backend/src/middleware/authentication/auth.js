import jwt from 'jsonwebtoken';
import { hashInPool, compareInPool } from '../../infrastructure/crypto/password_pool.js';
import { query } from '../../infrastructure/database/database.js';
import { jwtSecret } from '../../config.js';
import { fail } from '../../shared/errors/http.js';
import { banExpired, banMessage } from '../../modules/agencies/staff.rules.js';
import { touchSession } from '../../modules/users/sessions.service.js';
import { passwordRules } from './password_policy.js';

// bcrypt ana iş parçacığının dışında (infrastructure/crypto/password_pool.js): tek işlem ~290 ms işlemci harcar ve ana
// iş parçacığında çalışınca o süre boyunca tüm istekler (canlı odalar dahil) beklerdi. Özet biçimi değişmedi.
export const hashPassword = (p) => hashInPool(p, 12);
export const checkPassword = (p, h) => compareInPool(p, h);

// Şifre kuralları password_policy.js'te (bağımlılıksız, birim testli); eski içe aktarmalar bozulmasın diye buradan da dışa aktarılır.
export { passwordRules };

// Eski uygulama sürümleri (cihaz bilgisi göndermeyen) için 30 günlük tek token. Yeni sürümler cihaz oturumu
// (services/sessions.js: 1 saatlik erişim + yenileme token'ı) kullanır.
export const signToken = (u) => jwt.sign({ sub: u.id, tv: u.token_version ?? 0 }, jwtSecret(), { expiresIn: '30d', algorithm: 'HS256' });

export async function loadUser(id) {
  const r = await query('SELECT * FROM users WHERE id = $1', [id]);
  return r.rows[0] || null;
}

// Süresi dolan banı kaldırır (otomatik).
export async function liftBan(user) {
  const r = await query(
    `UPDATE users SET account_status = 'active', banned_until = NULL, ban_reason = NULL, banned_by = NULL, updated_at = NOW()
     WHERE id = $1 AND account_status = 'banned' RETURNING *`, [user.id]);
  return r.rows[0] || user;
}

// Token'ı doğrular; hesabın aktif ve token sürümünün güncel olduğunu denetler.
export async function authenticateToken(token) {
  if (!token) throw fail('Yetkisiz erişim.', 401);
  let payload;
  try { payload = jwt.verify(token, jwtSecret(), { algorithms: ['HS256'] }); } catch { throw fail('Yetkisiz erişim.', 401); }
  let user;
  if (payload.sid) {
    // Cihaz oturumlu token: oturum kapatılmışsa (uzaktan çıkış, şifre değişimi) token süresi dolmamış olsa da geçersiz.
    const r = await query(
      `SELECT u.*, s.revoked_at AS session_revoked_at FROM users u JOIN user_sessions s ON s.id = $2 AND s.user_id = u.id WHERE u.id = $1`,
      [payload.sub, payload.sid],
    );
    user = r.rows[0] || null;
    if (user) {
      const revoked = user.session_revoked_at;
      delete user.session_revoked_at;
      if (revoked) throw fail('Bu cihazdaki oturum kapatıldı. Lütfen yeniden giriş yapın.', 401);
      user.session_id = payload.sid;
    }
  } else {
    user = await loadUser(payload.sub);
  }
  if (user && banExpired(user)) user = { ...(await liftBan(user)), session_id: user.session_id };
  if (user && user.account_status === 'banned') throw fail(banMessage(user), 401);
  if (!user || user.account_status !== 'active' || (user.token_version ?? 0) !== (payload.tv ?? 0)) {
    throw fail('Hesap aktif değil veya oturum sona erdi.', 401);
  }
  touchSession(user.session_id);
  return user;
}

const bearer = (req) => {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : '';
};

export async function requireAuth(req, res, next) {
  try {
    req.user = await authenticateToken(bearer(req));
    req.auth = { sub: req.user.id };
    next();
  } catch (error) { next(error); }
}

export async function optionalAuth(req, res, next) {
  try {
    const t = bearer(req);
    if (t) { req.user = await authenticateToken(t); req.auth = { sub: req.user.id }; }
  } catch (_) { /* misafir olarak devam */ }
  next();
}

// requireAuth'tan SONRA kullanılır.
export const requireRole = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.system_role)) return next(fail('Bu işlem için yetkiniz yok.', 403));
  next();
};
// Yönetici = uygulama sahibi (tam yetki). Yardımcı admin ('support') yalnızca staff_logic.js'teki dar yetkilere sahiptir.
export const requireStaff = requireRole('admin', 'support');
export const requireSuperAdmin = requireRole('admin');
export const requireAdmin = requireSuperAdmin;
