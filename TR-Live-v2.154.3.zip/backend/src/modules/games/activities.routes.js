import crypto from 'node:crypto';
import express, { Router } from 'express';
import { query, tx } from '../../infrastructure/database/database.js';
import { requireAuth, requireSuperAdmin } from '../../middleware/authentication/auth.js';
import { userLimit, ipLimit } from '../../middleware/security/firewall.js';
import { allowlistOf, hostAllowed } from '../system/webview_policy.service.js';
import { getConfig } from '../system/app_config.service.js';
import { fail, text, uuid, assetUrl, oneOf } from '../../shared/errors/http.js';
import { jwtSecret } from '../../config.js';
import { hub } from '../../infrastructure/websocket/realtime.js';
import { installGame, removeGame, gameLink, getGameFile, gameInfo, SDK_JS, injectSdk, GAME_LIMITS } from './activity_games.service.js';

// ---------------------------------------------------------------------------------------------------------------
// Etkinlikler (v2.124): yönetici yalnızca BAĞLANTI yapıştırır; uygulama o bağlantıyı açar.
//
// Bağlantıda kullanılabilecek yer tutucular (açılırken doldurulur):
//   {uid} iç kullanıcı kimliği · {publicId} uygulamadaki ID · {name} ad · {avatar} fotoğraf adresi · {lang} dil (tr/en/ar/hi)
//   {roomId} açıldığı oda · {token} 2 saatlik oyun bileti (yalnızca bu etkinlik için) · {ts} zaman (sn)
//
// Coin'li H5 oyun sağlayıcısı için sunucu-sunucu API'si (etkinlikte "imza anahtarı" doluysa açık):
//   POST /api/activity-provider/:activityId/user     { token, ts, sign }
//   POST /api/activity-provider/:activityId/balance  { token, orderId, amount, reason?, ts, sign }
//     sign = hex( HMAC-SHA256( imzaAnahtarı, `${activityId}|${ts}|${token}|${orderId ?? ''}|${amount ?? ''}` ) )
//     ts: saniye; ±5 dk geçerli. amount: tam sayı Coin (+ kazanç, − harcama). Aynı orderId ikinci kez uygulanmaz
//     (ilk sonucun aynısı döner). Yanıt: { code: 0, data: { uid, publicId, name, avatar, balance } } ya da
//     { code: <hata>, message }. Hata kodları: 1001 imza, 1002 zaman, 1003 bilet, 1004 bakiye yetersiz, 1005 geçersiz.
// ---------------------------------------------------------------------------------------------------------------

export const router = Router();
export const providerRouter = Router();
export const adminRouter = Router();

const TOKEN_TTL_SEC = 2 * 3600;
const b64u = (buf) => Buffer.from(buf).toString('base64url');
const hmac = (key, s) => crypto.createHmac('sha256', key).update(s).digest();

/** Etkinliğe özel kısa ömürlü oyun bileti (oturum bileti DEĞİL; yalnızca sağlayıcı API'sinde ve yalnızca bu etkinlikte geçer). */
export function issueGameToken(userId, activityId, now = Math.floor(Date.now() / 1000)) {
  const body = b64u(JSON.stringify({ u: userId, a: activityId, e: now + TOKEN_TTL_SEC }));
  return `${body}.${b64u(hmac(jwtSecret(), `game|${body}`))}`;
}

/** Bileti doğrular; etkinliği bilmeden {userId, activityId} döner (gömülü oyunların WebSocket girişi için). */
export function readGameTokenAny(token, now = Math.floor(Date.now() / 1000)) {
  if (typeof token !== 'string' || token.length > 600) return null;
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  const want = b64u(hmac(jwtSecret(), `game|${body}`));
  if (want.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(want), Buffer.from(sig))) return null;
  let p;
  try { p = JSON.parse(Buffer.from(body, 'base64url').toString()); } catch { return null; }
  if (!p || typeof p.a !== 'string' || typeof p.u !== 'string' || !(p.e > now)) return null;
  return { userId: p.u, activityId: p.a };
}

export function readGameToken(token, activityId, now = Math.floor(Date.now() / 1000)) {
  if (typeof token !== 'string' || token.length > 600) return null;
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  const want = b64u(hmac(jwtSecret(), `game|${body}`));
  if (want.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(want), Buffer.from(sig))) return null;
  let p;
  try { p = JSON.parse(Buffer.from(body, 'base64url').toString()); } catch { return null; }
  if (!p || p.a !== activityId || typeof p.u !== 'string' || !(p.e > now)) return null;
  return p.u;
}

export function providerSign(secret, { activityId, ts, token, orderId, amount }) {
  return hmac(secret, `${activityId}|${ts}|${token}|${orderId ?? ''}|${amount ?? ''}`).toString('hex');
}

/** Bağlantıdaki yer tutucuları doldurur (değerler adres için kodlanır). */
export function fillLink(link, values) {
  return link.replace(/\{(base|uid|publicId|name|avatar|lang|roomId|token|ts)\}/g, (_, k) => (k === 'base' ? String(values.base ?? '') : encodeURIComponent(values[k] ?? '')));
}

const itemView = (r, { admin = false } = {}) => ({
  id: r.id,
  title: r.title,
  subtitle: r.subtitle,
  icon: r.icon,
  openMode: r.open_mode,
  ready: !!r.link_url,
  sortOrder: r.sort_order,
  ...(admin ? { linkUrl: r.link_url, enabled: r.enabled, hasSecret: !!r.app_secret, updatedAt: r.updated_at } : {}),
});

// ---------------- Kullanıcı ----------------

/** Etkinlikleri görme izni: yalnızca yönetimin izin verdiği kişiler (yönetici hesapları da dahil, istisna yok). Karar tamamen sunucuda. */
export async function canSeeActivities(userId) {
  const r = await query(
    `SELECT EXISTS (SELECT 1 FROM activity_access a WHERE a.user_id = u.id) AS ok
       FROM users u WHERE u.id = $1 AND u.account_status = 'active'`, [userId],
  ).catch(() => ({ rows: [] }));
  return r.rows[0]?.ok === true;
}

router.get('/access', requireAuth, async (req, res) => {
  res.json({ allowed: await canSeeActivities(req.user.id) });
});


router.get('/', requireAuth, async (req, res) => {
  if (!(await canSeeActivities(req.user.id))) return res.json({ items: [] });
  const rows = (await query(`SELECT * FROM activity_items WHERE enabled ORDER BY sort_order, created_at`)).rows;
  res.json({ items: rows.map((r) => itemView(r)) });
});

router.post('/:id/launch', requireAuth, userLimit('activity_launch', 60, 60e3), async (req, res) => {
  if (!(await canSeeActivities(req.user.id))) throw fail('Etkinlikler için izniniz yok.', 403);
  const id = uuid(req.params.id, 'Etkinlik');
  const item = (await query(`SELECT * FROM activity_items WHERE id = $1 AND enabled`, [id])).rows[0];
  if (!item) throw fail('Etkinlik bulunamadı.', 404);
  if (!item.link_url) throw fail('Bu etkinlik yakında açılacak.', 409);
  const u = (await query(`SELECT id, public_id, display_name, username, avatar_url FROM users WHERE id = $1`, [req.user.id])).rows[0];
  const roomId = typeof req.body?.roomId === 'string' && /^[0-9a-f-]{36}$/i.test(req.body.roomId) ? req.body.roomId : '';
  const lang = ['tr', 'en', 'ar', 'hi'].includes(req.body?.lang) ? req.body.lang : 'tr';
  const base = `${req.protocol}://${req.get('host')}`;
  const avatar = u.avatar_url ? (u.avatar_url.startsWith('http') ? u.avatar_url : base + u.avatar_url) : '';
  const url = fillLink(item.link_url, {
    base, uid: u.id, publicId: u.public_id ?? '', name: u.display_name || u.username, avatar, lang, roomId,
    token: issueGameToken(u.id, item.id), ts: String(Math.floor(Date.now() / 1000)),
  });
  res.json({ url, openMode: item.open_mode, title: item.title });
});

// ---------------- Oyun sağlayıcısı (sunucu → sunucu) ----------------
async function providerContext(req) {
  // Yönetici "Etkinlikler"i kapattıysa sağlayıcı API'si de (Coin hareketi dahil) durur; eskiden yalnızca sayfa gizleniyordu.
  if ((await getConfig()).roomActivitiesEnabled === false) return { err: [1005, 'Etkinlikler şu an kapalı.'] };
  const id = String(req.params.id ?? '');
  if (!/^[0-9a-f-]{36}$/i.test(id)) return { err: [1005, 'Etkinlik geçersiz.'] };
  const item = (await query(`SELECT id, app_secret FROM activity_items WHERE id = $1 AND enabled`, [id])).rows[0];
  if (!item || !item.app_secret) return { err: [1005, 'Etkinlik bulunamadı ya da Coin API kapalı.'] };
  const b = req.body ?? {};
  const ts = Number(b.ts);
  if (!Number.isFinite(ts) || Math.abs(Date.now() / 1000 - ts) > 300) return { err: [1002, 'Zaman damgası geçersiz.'] };
  const want = providerSign(item.app_secret, { activityId: id, ts: b.ts, token: b.token, orderId: b.orderId, amount: b.amount });
  const got = String(b.sign ?? '');
  if (got.length !== want.length || !crypto.timingSafeEqual(Buffer.from(got), Buffer.from(want))) return { err: [1001, 'İmza geçersiz.'] };
  const userId = readGameToken(b.token, id);
  if (!userId) return { err: [1003, 'Oyun bileti geçersiz ya da süresi doldu.'] };
  return { id, userId };
}

const userData = (u) => ({ uid: u.id, publicId: u.public_id, name: u.display_name || u.username, avatar: u.avatar_url, balance: String(u.coins) });

providerRouter.post('/:id/user', ipLimit('activity_provider', 6000, 60e3), async (req, res) => {
  const ctx = await providerContext(req);
  if (ctx.err) return res.json({ code: ctx.err[0], message: ctx.err[1] });
  const u = (await query(`SELECT id, public_id, display_name, username, avatar_url, coins FROM users WHERE id = $1 AND account_status = 'active'`, [ctx.userId])).rows[0];
  if (!u) return res.json({ code: 1003, message: 'Kullanıcı bulunamadı.' });
  res.json({ code: 0, data: userData(u) });
});

providerRouter.post('/:id/balance', ipLimit('activity_provider', 6000, 60e3), async (req, res) => {
  const ctx = await providerContext(req);
  if (ctx.err) return res.json({ code: ctx.err[0], message: ctx.err[1] });
  const orderId = String(req.body?.orderId ?? '').trim();
  const amountStr = String(req.body?.amount ?? '').trim();
  if (!orderId || orderId.length > 80 || !/^-?\d{1,15}$/.test(amountStr) || amountStr === '0' || amountStr === '-0') {
    return res.json({ code: 1005, message: 'Sipariş numarası ya da miktar geçersiz.' });
  }
  const amount = BigInt(amountStr);
  const reason = typeof req.body?.reason === 'string' ? req.body.reason.slice(0, 120) : null;
  const out = await tx(async (c) => {
    const done = (await c.query(`SELECT balance_after, amount FROM activity_orders WHERE activity_id = $1 AND order_id = $2`, [ctx.id, orderId])).rows[0];
    const u = (await c.query(`SELECT id, public_id, display_name, username, avatar_url, coins FROM users WHERE id = $1 AND account_status = 'active' FOR UPDATE`, [ctx.userId])).rows[0];
    if (!u) return { code: 1003, message: 'Kullanıcı bulunamadı.' };
    if (done) return { code: 0, data: { ...userData(u), balance: String(done.balance_after) }, duplicate: true };
    const before = BigInt(u.coins);
    const after = before + amount;
    if (after < 0n) return { code: 1004, message: 'Bakiye yetersiz.' };
    await c.query(`UPDATE users SET coins = $1, updated_at = NOW() WHERE id = $2`, [after.toString(), u.id]);
    await c.query(
      `INSERT INTO activity_orders(activity_id, order_id, user_id, amount, balance_after, reason) VALUES($1,$2,$3,$4,$5,$6)`,
      [ctx.id, orderId, u.id, amount.toString(), after.toString(), reason],
    );
    await c.query(
      `INSERT INTO wallet_transactions(user_id, transaction_type, coin_amount, reference_id, description) VALUES($1,$2,$3,$4,$5)`,
      [u.id, amount > 0n ? 'activity_win' : 'activity_spend', amount.toString(), `${ctx.id}:${orderId}`,
       `${amount > 0n ? 'Etkinlik kazancı' : 'Etkinlik kaybı'}${reason ? `: ${reason}` : ''}`.slice(0, 200)],
    );
    await c.query(
      `INSERT INTO financial_audit_logs(user_id, action, reference_type, reference_id, amount_coins, balance_before, balance_after, metadata)
       VALUES($1,'activity_balance','activity',$2,$3,$4,$5,$6)`,
      [u.id, ctx.id, amount.toString(), before.toString(), after.toString(), JSON.stringify({ orderId, reason })],
    );
    return { code: 0, data: { ...userData(u), balance: after.toString() }, userId: u.id };
  });
  if (out.code === 0 && out.userId) hub.sendToUser(out.userId, { type: 'wallet', coins: out.data.balance });
  res.json({ code: out.code, ...(out.data ? { data: out.data } : { message: out.message }) });
});

// ---------------- Oyun sayfası bilgi ucu (salt okunur) ----------------
// Barındırılan HTML oyun sayfası, kendi `{token}` bileti ile oyuncunun adını ve bakiyesini okur:
//   POST /api/activity-play/:id/me  { token }  → { uid, name, avatar, balance }
//
// Coin hareketi BU YOLDAN YAPILMAZ. v2.131.0'da istemci çarpanıyla çalışan tur uçları kaldırıldı: sonucu oyunun
// (yani istemcinin) bildirdiği bir çarpan belirliyordu ve bileti eline geçiren oyuncu her turda azami
// çarpanı göndererek kasayı boşaltabilirdi. Coin hareketi olan bir oyunun sonucu sunucuda üretilmelidir:
//   • Oyun paketi (Sistem → Oyun Paketleri): motor sunucuda çalışır, cüzdana paket API'si ile erişir.
//   • İmzalı sağlayıcı API'si (/api/activity-provider): oyun kendi sunucusunda çalışır, istekleri
//     `app_secret` ile HMAC imzalar.
export const playRouter = Router();

async function playContext(req) {
  const id = String(req.params.id ?? '');
  if (!/^[0-9a-f-]{36}$/i.test(id)) return { err: [1005, 'Etkinlik geçersiz.'] };
  const item = (await query(`SELECT * FROM activity_items WHERE id = $1 AND enabled`, [id])).rows[0];
  if (!item) return { err: [1005, 'Etkinlik bulunamadı ya da kapalı.'] };
  const userId = readGameToken(req.body?.token, id);
  if (!userId) return { err: [1003, 'Oyun bileti geçersiz ya da süresi doldu.'] };
  if (!(await canSeeActivities(userId))) return { err: [1003, 'Etkinlikler için izniniz yok.'] };
  return { id, item, userId };
}

playRouter.post('/:id/me', ipLimit('activity_play', 6000, 60e3), async (req, res) => {
  const ctx = await playContext(req);
  if (ctx.err) return res.json({ code: ctx.err[0], message: ctx.err[1] });
  const u = (await query(`SELECT id, public_id, display_name, username, avatar_url, coins FROM users WHERE id = $1 AND account_status = 'active'`, [ctx.userId])).rows[0];
  if (!u) return res.json({ code: 1003, message: 'Kullanıcı bulunamadı.' });
  res.json({ code: 0, data: userData(u) });
});

// ---------------- Barındırılan oyunlar (herkese açık dosya sunumu) ----------------
// /games/_sdk.js  → TRGame SDK;  /games/<etkinlik>/v<N>/<yol>  → zip'ten yüklenen oyun dosyaları.
export const hostedGamesRouter = Router();
const GAME_CSP = "default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' 'wasm-unsafe-eval' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; media-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; worker-src 'self' blob:; base-uri 'self'; form-action 'none'; frame-ancestors 'none'";

hostedGamesRouter.get('/_sdk.js', (_req, res) => {
  res.set({ 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'public, max-age=300', 'X-Content-Type-Options': 'nosniff' }).send(SDK_JS);
});

async function serveGame(req, res) {
  const id = String(req.params.id ?? '');
  const ver = /^v(\d{1,6})$/.exec(String(req.params.ver ?? ''));
  if (!/^[0-9a-f-]{36}$/i.test(id) || !ver) return res.status(404).end();
  const raw = Array.isArray(req.params.path) ? req.params.path.join('/') : String(req.params.path ?? '');
  const path = raw === '' ? 'index.html' : raw;
  if (path.includes('..') || path.startsWith('/')) return res.status(404).end();
  const f = await getGameFile(id, Number(ver[1]), path);
  if (!f) return res.status(404).type('text/plain').send('Bulunamadı.');
  const headers = { 'Content-Type': f.mime, 'Cache-Control': 'public, max-age=31536000, immutable', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' };
  if (f.mime.startsWith('text/html')) {
    // Sayfa her açılışta biletle gelir; önbellekte yeni bilet olmasın diye HTML önbelleklenmez.
    res.set({ ...headers, 'Cache-Control': 'no-store', 'Content-Security-Policy': GAME_CSP });
    return res.send(injectSdk(f.data.toString('utf8')));
  }
  res.set(headers).send(f.data);
}
hostedGamesRouter.get('/:id/:ver', ipLimit('game_files', 60000, 3600e3), serveGame);
hostedGamesRouter.get('/:id/:ver/*path', ipLimit('game_files', 60000, 3600e3), serveGame);

// ---------------- Yönetim ----------------
adminRouter.use(requireAuth, requireSuperAdmin);


// İzinli kişiler: ID (public_id) ya da kullanıcı adıyla ekle, listele, kaldır.
adminRouter.get('/access', async (_req, res) => {
  const rows = (await query(
    `SELECT u.id, u.username, u.display_name, u.public_id, u.avatar_url, a.created_at
       FROM activity_access a JOIN users u ON u.id = a.user_id ORDER BY a.created_at DESC LIMIT 500`)).rows;
  res.json({ users: rows.map((u) => ({ id: u.id, username: u.username, displayName: u.display_name, publicId: u.public_id, avatarUrl: u.avatar_url, grantedAt: u.created_at })) });
});

adminRouter.post('/access', async (req, res) => {
  const q = text(req.body?.q, 'Kullanıcı', { max: 60 })?.replace(/^@/, '');
  if (!q) throw fail('Kullanıcı ID\'si ya da adı girin.');
  const u = (await query(`SELECT id, username, display_name, public_id FROM users WHERE public_id = $1 OR lower(username) = lower($1) LIMIT 1`, [q])).rows[0];
  if (!u) throw fail('Kullanıcı bulunamadı.', 404);
  await query(`INSERT INTO activity_access(user_id, granted_by) VALUES($1,$2) ON CONFLICT (user_id) DO NOTHING`, [u.id, req.user.id]);
  res.json({ ok: true, user: { id: u.id, username: u.username, displayName: u.display_name, publicId: u.public_id } });
});

adminRouter.delete('/access/:userId', async (req, res) => {
  await query(`DELETE FROM activity_access WHERE user_id = $1`, [uuid(req.params.userId, 'Kullanıcı')]);
  res.json({ ok: true });
});

adminRouter.get('/', async (req, res) => {
  const rows = (await query(`SELECT * FROM activity_items ORDER BY sort_order, created_at`)).rows;
  const games = await gameInfo(rows.map((r) => r.id));
  res.json({ items: rows.map((r) => ({ ...itemView(r, { admin: true }), game: games.get(r.id) ?? null })) });
});

async function readItem(b, partial) {
  const out = {};
  if (!partial || b.title !== undefined) out.title = text(b.title, 'Başlık', { required: true, max: 80 });
  if (b.subtitle !== undefined) out.subtitle = text(b.subtitle, 'Açıklama', { max: 160 }) ?? '';
  if (b.icon !== undefined) {
    const ic = String(b.icon ?? '').trim();
    out.icon = !ic ? '🎮' : (/^(https:|\/media\/)/.test(ic) ? assetUrl(ic, 'Simge') : text(ic, 'Simge', { max: 16 }));
  }
  if (b.linkUrl !== undefined) {
    const l = String(b.linkUrl ?? '').trim();
    if (l) {
      let u;
      try { u = new URL(l.replace(/^\{base\}/, 'https://x.test').replace(/\{[a-zA-Z]+\}/g, 'x')); } catch { throw fail('Bağlantı geçersiz.'); }
      if (u.protocol !== 'https:') throw fail('Bağlantı https:// ile başlamalı.');
      if (l.length > 1000) throw fail('Bağlantı çok uzun.');
      // İzin listesi doluysa yabancı alan adı KAYDEDİLEMEZ. Yanlış yazılmış bir adres
      // (trlve.app gibi), kullanıcıyı uygulamanın içinde yabancı bir sayfaya götürür ve
      // adres çubuğu görünmediği için kullanıcı farkı anlayamaz.
      const list = allowlistOf(await getConfig());
      if (list.length && !u.hostname.endsWith('.test') && !hostAllowed(u.toString(), list)) {
        throw fail(`Bu alan adı izin listesinde yok: ${u.hostname}. Ayarlar → WebView izin listesine ekleyin.`);
      }
    }
    out.link_url = l;
  }
  if (b.openMode !== undefined) out.open_mode = oneOf(b.openMode, ['sheet', 'full', 'browser'], 'Açılış biçimi');
  if (b.enabled !== undefined) out.enabled = b.enabled === true;
  if (b.sortOrder !== undefined) out.sort_order = Math.max(-1000, Math.min(1000, Number.parseInt(b.sortOrder, 10) || 0));
  if (b.appSecret !== undefined) out.app_secret = text(b.appSecret, 'İmza anahtarı', { max: 200 }) ?? '';
  return out;
}

adminRouter.post('/', async (req, res) => {
  const v = await readItem(req.body ?? {}, false);
  const cols = Object.keys(v);
  const r = await query(
    `INSERT INTO activity_items(${cols.join(',')}) VALUES(${cols.map((_, i) => `$${i + 1}`).join(',')}) RETURNING *`,
    cols.map((k) => v[k]),
  );
  res.json({ item: itemView(r.rows[0], { admin: true }) });
});

adminRouter.patch('/:id', async (req, res) => {
  const id = uuid(req.params.id, 'Etkinlik');
  const v = await readItem(req.body ?? {}, true);
  // Zip ile yüklenmiş oyun varken bağlantı boş gönderilirse (eski form) oyunun bağlantısı korunur.
  if (v.link_url === '') {
    const g = (await query(`SELECT version FROM activity_games WHERE activity_id = $1`, [id])).rows[0];
    if (g) v.link_url = gameLink(id, g.version);
  }
  const cols = Object.keys(v);
  if (!cols.length) throw fail('Değişiklik yok.');
  const r = await query(
    `UPDATE activity_items SET ${cols.map((k, i) => `${k} = $${i + 2}`).join(', ')}, updated_at = NOW() WHERE id = $1 RETURNING *`,
    [id, ...cols.map((k) => v[k])],
  );
  if (!r.rows[0]) throw fail('Etkinlik bulunamadı.', 404);
  res.json({ item: itemView(r.rows[0], { admin: true }) });
});


// Oyun zip'i yükle: sunucu güvenle açar, /games/<id>/v<N>/ altında yayınlar, bağlantıyı kendisi yazar.
adminRouter.post('/:id/game', express.raw({ type: () => true, limit: GAME_LIMITS.totalBytes }), async (req, res) => {
  const id = uuid(req.params.id, 'Etkinlik');
  if (!Buffer.isBuffer(req.body) || !req.body.length) throw fail('Zip dosyası gönderilmedi.');
  const out = await installGame(id, req.body);
  res.json({ ok: true, ...out });
});

adminRouter.delete('/:id/game', async (req, res) => {
  await removeGame(uuid(req.params.id, 'Etkinlik'));
  res.json({ ok: true });
});

adminRouter.delete('/:id', async (req, res) => {
  const id = uuid(req.params.id, 'Etkinlik');
  await query(`DELETE FROM activity_items WHERE id = $1`, [id]);
  res.json({ ok: true });
});
